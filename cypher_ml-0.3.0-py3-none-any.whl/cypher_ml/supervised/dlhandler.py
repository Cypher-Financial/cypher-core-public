import json
import re
import traceback

from typing import Any, List, Tuple
from datetime import datetime
from utils import current_time
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
from pyspark.sql.functions import col, when, lit, date_format


class DeltaLakeHandler:
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _create_dataframe(self, data: tuple, schema: StructType) -> DataFrame:
        return self.spark.createDataFrame([data], schema)

    def create_metadata_deploy(self, **kwargs):
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Rename ticker for deploy
        ticker = re.sub(r'-PERP|-', '', kwargs['ticker'])
        timeframe = kwargs['timeframe']
        strategy_type = kwargs['strategy_type']

        strategy_name = f"{ticker}_{timeframe}_{strategy_type}"

        if strategy_type == "long_only":
            kwargs['min_cutoff'] = -1000

        if strategy_type == "short_only":
            kwargs['max_cutoff'] = 1000

        data_to_save = {
            'DATETIME': current_datetime,
            'TICKER': ticker,
            'TIMEFRAME': timeframe,
            'MODEL_TYPE': kwargs['model_type'],
            'BACKTEST_ID': kwargs['backtest_id'],
            'SCALER_KEY': kwargs['scaler_key'],
            'MODEL_ID': kwargs['model_id'],
            'SELECTION_METHOD': kwargs['selection'],
            'PROB_OPT_METHOD': kwargs['optimize_method'],
            'MIN_CUTOFF': float(kwargs['min_cutoff']),
            'MAX_CUTOFF': float(kwargs['max_cutoff']),
            'STRATEGY_TYPE': strategy_type,
            'STRATEGY_NAME': strategy_name
        }

        return data_to_save

    def _get_delta_path_by_env(self, deploy_env: str, storage_account_name: str) -> str:
        if deploy_env == 'production':
            print("Deploying to production environment")
            table_name = "metadata_deploy"
        elif deploy_env == 'sandbox':
            print("Deploying to sandbox environment")
            table_name = "metadata_deploy_sandbox"
        else:
            raise ValueError("Deploy environment should be 'production' or 'sandbox'")

        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/{table_name}"

        return delta_table_path

    def save_metadata_strategy(self,
                               data: dict,
                               deploy_env: str,
                               storage_account_name: str):
        schema = StructType(
            [
                StructField("DATETIME", StringType(), nullable=False),
                StructField("TICKER", StringType(), nullable=False),
                StructField("TIMEFRAME", StringType(), nullable=False),
                StructField("MODEL_TYPE", StringType(), nullable=False),
                StructField("BACKTEST_ID", StringType(), nullable=False),
                StructField("SCALER_KEY", StringType(), nullable=True),
                StructField("MODEL_ID", StringType(), nullable=False),
                StructField("SELECTION_METHOD", StringType(), nullable=True),
                StructField("PROB_OPT_METHOD", StringType(), nullable=True),
                StructField("MIN_CUTOFF", DoubleType(), nullable=True),
                StructField("MAX_CUTOFF", DoubleType(), nullable=True),
                StructField("STRATEGY_TYPE", StringType(), nullable=False),
                StructField("STRATEGY_NAME", StringType(), nullable=False),
            ]
        )

        try:
            # Get the correct table name based on the environment
            delta_table_path = self._get_delta_path_by_env(deploy_env, storage_account_name)

            # Create DataFrame from the input data
            df = self.spark.createDataFrame([data], schema=schema)

            # Save the DataFrame to the specified Delta table
            df.write.format("delta").mode("append").option("mergeSchema", "true").save(delta_table_path)

            print(f"Deploy metadata saved successfully on {delta_table_path}.")
        except Exception as e:
            print(f"Error saving deploy metadata: {e}")
            traceback.print_exc()

    def get_model_ids_from_active_strategies(self,
                                             storage_account_name: str,
                                             status: str = "ON",
                                             env: str = "sandbox"):
        if env == "production":
            layer = "gold"
        else:
            layer = "silver"

        table_name = "active_strategies"
        delta_table_path = f"wasbs://{layer}@{storage_account_name}.blob.core.windows.net/{table_name}"

        query = f"select * from temp_{table_name} where STATUS = '{status}'"

        sdf = self._read_temp_table(query, table_name, delta_table_path)

        rows = sdf.select(["STRATEGY_KEY"]).collect()

        model_ids = [row["STRATEGY_KEY"] for row in rows]

        return model_ids

    def get_model_ids_from_active_strategies_by_tickers(self,
                                                        tickers: List[str],
                                                        storage_account_name: str,
                                                        env: str = "sandbox"):
        if env == "production":
            layer = "gold"
        else:
            layer = "silver"

        table_name = "active_strategies"
        delta_table_path = f"wasbs://{layer}@{storage_account_name}.blob.core.windows.net/{table_name}"

        ticker_str = ', '.join(f"'{ticker}'" for ticker in tickers)

        query = f"select * from temp_{table_name} where TICKER in ({ticker_str}) and STATUS = 'ON'"

        sdf = self._read_temp_table(query, table_name, delta_table_path)

        rows = sdf.select(["STRATEGY_KEY"]).collect()

        model_ids = [row["STRATEGY_KEY"] for row in rows]

        return model_ids

    def get_backtest_ids_from_metadata_train_deploy(self,
                                                    model_ids: List[str],
                                                    storage_account_name: str):

        table_name = "metadata_train_deploy"
        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/{table_name}"

        if not model_ids:
            raise ValueError("model_ids list is empty. Query cannot be executed.")

        model_ids_str = ', '.join(f"'{model_id}'" for model_id in model_ids)

        query = f"select * from temp_{table_name} where MODEL_ID in ({model_ids_str})"

        sdf = self._read_temp_table(query, table_name, delta_table_path)

        rows = sdf.select("BACKTEST_ID").collect()

        backtest_ids = [row["BACKTEST_ID"] for row in rows]

        return backtest_ids

    def get_metadata_train(self, backtest_id: str, storage_account_name: str):
        table_name = "metadata_train_v2"

        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/{table_name}"

        query = f"select BACKTEST_ID, CONFIG from temp_{table_name} where BACKTEST_ID = '{backtest_id}'"

        sdf = self._read_temp_table(query, table_name, delta_table_path)

        return sdf

    def get_metadata_retrain(self, backtest_id: str, storage_account_name: str):
        table_name = "metadata_retrain_v2"

        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/{table_name}"

        query = f"select BACKTEST_ID, CONFIG from temp_{table_name} where BACKTEST_ID = '{backtest_id}'"

        sdf = self._read_temp_table(query, table_name, delta_table_path)

        return sdf

    def get_distinct_dataframe(self, storage_account_name: str, table_name: str, folder_name: str = None) -> DataFrame:
        if folder_name:
            delta_table_path = f"wasbs://silver@{storage_account_name}.blob.core.windows.net/{folder_name}/{table_name}"
        else:
            delta_table_path = f"wasbs://silver@{storage_account_name}.blob.core.windows.net/{table_name}"
        try:
            parquet_df = self.spark.read.parquet(delta_table_path)
            parquet_df.createOrReplaceTempView(f"temp_{table_name}")
        except Exception as e:
            print(e)

        query = f"select count(distinct DATAFRAME) as distinct_count from temp_{table_name}"
        sdf = self._read_temp_table(query, table_name, delta_table_path)
        distinct_count = sdf.collect()[0]["distinct_count"]

        return distinct_count

    def get_portfolio_btids(self, storage_account_name, deploy_env):
        if deploy_env == 'production':
            table_name='portfolio'
        else:
            table_name='portfolio_sandbox'

        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/{table_name}"
        df_portfolio = self.spark.read.format("delta").load(delta_table_path).toPandas()
        btids = df_portfolio['BACKTEST_ID'].tolist()
        return btids

    def _read_temp_table(self, query: str, table_name: str, delta_table_path: str):
        try:
            df = self.spark.sql(query)
        except Exception:
            self.spark.sql(f"create table temp_{table_name} using delta location '{delta_table_path}'")
            df = self.spark.sql(query)

        return df

    def read_table(self,
                   container_name: str,
                   storage_account_name: str,
                   table_name: str,
                   folder_name: str = None) -> DataFrame:
        """
        Select all data from table.
        """

        if folder_name:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{folder_name}/{table_name}"
        else:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"

        query = f"select * from temp_{table_name}"

        return self._read_temp_table(query, table_name, delta_table_path)

    def read_table_with_spark(self,
                              spark: SparkSession,
                              container_name: str,
                              storage_account_name: str,
                              table_name: str,
                              folder_name: str = None) -> DataFrame:
        """
        Select all data from table.
        """
        if folder_name:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{folder_name}/{table_name}"
        else:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"

        return spark.read.format("delta").load(delta_table_path)

    def read_table_datetime(self,
                             container_name: str,
                             storage_account_name: str,
                             table_name: str,
                             date_time: str,
                             folder_name: str = None) -> DataFrame:
        """
        Select all data from table.
        """

        if folder_name:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{folder_name}/{table_name}"
        else:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"

        query = f"select * from temp_{table_name} where DATETIME >= {date_time}"

        return self._read_temp_table(query, table_name, delta_table_path)

    def save_multicrypto_results(self,
                                 df_results_data: DataFrame,
                                 container_name: str,
                                 storage_account_name: str,
                                 table_name: str,
                                 folder_name: str = None) -> DataFrame:
        """
        Append rows in batch to a table.
        """

        if folder_name:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{folder_name}/{table_name}"
        else:
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"

        df_spk_results_data = self.spark.createDataFrame(df_results_data)

        df_spk_results_data.write \
                        .mode("append") \
                        .format("delta")\
                        .option("mergeSchema", "true")\
                        .save(delta_table_path)

    def write_table(self,
                    df: DataFrame,
                    table_path: str,
                    mode: str) -> DataFrame:
        try:
            df.write.format("delta").mode(mode).saveAsTable(table_path)
            print("Data written successfully.")
        except Exception as error:
            print(f"Error writing table: {error}")

    def overwrite_table(self, df: DataFrame, table_path: str):
        df.write.format("delta").mode("overwrite").saveAsTable(table_path)

    def save_metadata_train(self,
                            metadata_list: List[Tuple[str, str, str, dict]],
                            storage_account_name: str):
        """
        Save informations about run_train or multi_crypto_train.
        """
        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/metadata_train_v2"

        schema = StructType(
            [
                StructField("DATETIME", StringType(), False),
                StructField("DATAFRAME", StringType(), False),
                StructField("BACKTEST_ID", StringType(), False),
                StructField("CONFIG", StringType(), False)
            ]
        )

        rows = [(current_time, df_id, backtest_id, json.dumps(config)) for current_time, df_id, backtest_id, config in metadata_list]

        df_metadata = self.spark.createDataFrame(rows, schema)
        df_metadata.write.format("delta").option("mergeSchema", "true").mode("append").save(delta_table_path)

    def save_metadata_retrain(self,
                              df_id_inicial: str,
                              df_id_final: str,
                              backtest_id_train: str,
                              backtest_id: str,
                              config: dict,
                              storage_account_name: str):
        """
        Save informations about retrain.
        """
        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/metadata_retrain_v2"

        schema = StructType(
            [
                StructField("DATETIME", StringType(), False),
                StructField("DATAFRAME_INICIAL", StringType(), False),
                StructField("DATAFRAME_FINAL", StringType(), False),
                StructField("BACKTEST_ID_TRAIN", StringType(), False),
                StructField("BACKTEST_ID", StringType(), False),
                StructField("CONFIG", StringType(), False)
            ]
        )

        config_str = json.dumps(config)

        data = (current_time(), df_id_inicial, df_id_final, backtest_id_train, backtest_id, config_str)
        df_metadata = self._create_dataframe(data, schema)
        df_metadata.write.format("delta").mode("append").save(delta_table_path)

    def save_metadata_train_deploy(self,
                                   df_id: str,
                                   backtest_id_retrain: str,
                                   model_id: str,
                                   config: dict,
                                   storage_account_name: str):
        """
        Save informations about train deploy.
        """
        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/metadata_train_deploy"

        schema = StructType(
            [
                StructField("DATETIME", StringType(), False),
                StructField("DATAFRAME", StringType(), False),
                StructField("BACKTEST_ID", StringType(), False),
                StructField("MODEL_ID", StringType(), False),
                StructField("CONFIG", StringType(), False)
            ]
        )

        config_str = json.dumps(config)

        data = (current_time(), df_id, backtest_id_retrain, model_id, config_str)
        df_metadata = self._create_dataframe(data, schema)
        df_metadata.write.format("delta").mode("append").save(delta_table_path)

    def remove_row_by_datetime(self, table_path: str, date: str):
        """
        Remove rows and overwrite table
        """
        df = self.read_table(table_path)

        df = df.withColumn("DATETIME", col("DATETIME").cast("timestamp"))

        datetime_to_remove = datetime.strptime(date, "%Y-%m-%d %H:%M:%S")

        df_filtered = df.filter(col("DATETIME") < datetime_to_remove)

        df_filtered = df_filtered.withColumn("DATETIME",  date_format(col("DATETIME"), "yyyy-MM-dd HH:mm:ss"))

        return df_filtered

    def update_field_by_model_id(self,
                                 table_path: str,
                                 field: str,
                                 model_ids: List[str],
                                 new_value: Any):
        df = self.read_table(table_path)
        for model_id in model_ids:
            df = df.withColumn(field, when(col("MODEL_ID") == model_id, lit(new_value)).otherwise(col(field)))

        return df
