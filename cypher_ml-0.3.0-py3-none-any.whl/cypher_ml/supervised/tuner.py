import mlflow
import numpy as np
import logging
from trainer import Trainer, CypherTrainer
from hyperopt import fmin, tpe, hp, STATUS_OK
from hyperopt.pyll import scope

logger = logging.getLogger('logger')


class Tuner:
    def __init__(self, config: dict):
        """
        Initializes the Tuner.

        Args:
            config (dict): The configuration dictionary for tuning.
        """
        # Train, tracking and tuning
        self.config = config

        self.framework = self.config['info']['framework']
        self.is_cross_validation = self.config['info']['is_cross_validation']
        self.run_name = self.config['info']['model_id']
        self.model_name = self.config['info']['model_name']

    def _build_search_space(self) -> dict:
        """
        Constructs the search space for hyperparameter tuning.

        Returns:
            dict: The search space for the hyperparameters.
        """
        if self.framework == CypherTrainer.TORCH:
            if self.config['info']['model_id'] == 'lstm_v1':
                space = {
                        'num_layers': scope.int(hp.quniform('num_layers',
                                                            self.config['tune']['num_layers']['low'],
                                                            self.config['tune']['num_layers']['high'],
                                                            1)),  # Assuming a step size of 1 for 'num_layers'

                        'dropout_prob': hp.uniform('dropout_prob',
                                                    self.config['tune']['dropout_prob']['low'],
                                                    self.config['tune']['dropout_prob']['high']),

                        'batch_size': scope.int(hp.quniform('batch_size',
                                                            self.config['tune']['batch_size']['low'],
                                                            self.config['tune']['batch_size']['high'],
                                                            1)),  # Assuming a step size of 1 for 'batch_size'

                        'learning_rate': hp.uniform('learning_rate',
                                                    self.config['tune']['learning_rate']['low'],
                                                    self.config['tune']['learning_rate']['high']),

                        'l2_reg': hp.uniform('l2_reg',
                                             self.config['tune']['l2_reg']['low'],
                                             self.config['tune']['l2_reg']['high']),

                        'hidden_dim': scope.int(hp.quniform('hidden_dim',
                                                            self.config['tune']['hidden_dim']['low'],
                                                            self.config['tune']['hidden_dim']['high'],
                                                            1))
                }
            elif self.config['info']['model_id'] == 'tec_v1':
                # Build tune and track configuration
                space = {
                        'max_len': scope.int(hp.quniform('max_len',
                                                         self.config['tune']['max_len']['low'],
                                                         self.config['tune']['max_len']['high'],
                                                         self.config['tune']['max_len']['step'])),

                        'd_model': hp.choice('d_model', self.config['tune']['d_model']),

                        'num_layers': scope.int(hp.quniform('num_layers',
                                                            self.config['tune']['num_layers']['low'],
                                                            self.config['tune']['num_layers']['high'],
                                                            self.config['tune']['num_layers']['step'])),

                        'num_heads': hp.choice('num_heads', self.config['tune']['num_heads']),

                        'dropout_rate': hp.uniform('dropout_rate',
                                                    self.config['tune']['dropout_rate']['low'],
                                                    self.config['tune']['dropout_rate']['high']),

                        'batch_size': scope.int(hp.quniform('batch_size',
                                                            self.config['tune']['batch_size']['low'],
                                                            self.config['tune']['batch_size']['high'],
                                                            self.config['tune']['batch_size']['step'])),

                        'learning_rate': hp.loguniform('learning_rate',
                                                        np.log(self.config['tune']['learning_rate']['low']),
                                                        np.log(self.config['tune']['learning_rate']['high'])),

                        'l2_reg': hp.loguniform('l2_reg',
                                                np.log(self.config['tune']['l2_reg']['low']),
                                                np.log(self.config['tune']['l2_reg']['high'])),

                        'opt_name': hp.choice('opt_name', self.config['tune']['opt_name']),

                        'scheduler_name': hp.choice('scheduler_name', self.config['tune']['scheduler_name'])
                    }
            else:
                raise ValueError(f"The {self.run_name} was not implemented.")
        elif self.framework == CypherTrainer.XGBOOST:
            space = {
                    "n_estimators": hp.randint('n_estimators',
                                               self.config['tune']['n_estimators']['low'],
                                               self.config['tune']['n_estimators']['high']),
                    "learning_rate": hp.uniform('learning_rate',
                                                self.config['tune']['learning_rate']['low'],
                                                self.config['tune']['learning_rate']['high']),
                    "gamma": hp.uniform('gamma',
                                        self.config['tune']['gamma']['low'],
                                        self.config['tune']['gamma']['high']),
                    "max_depth": hp.randint('max_depth',
                                            self.config['tune']['max_depth']['low'],
                                            self.config['tune']['max_depth']['high']),
                    "subsample": hp.uniform('subsample',
                                            self.config['tune']['subsample']['low'],
                                            self.config['tune']['subsample']['high']),
                    "colsample_bytree": hp.uniform('colsample_bytree',
                                                   self.config['tune']['colsample_bytree']['low'],
                                                   self.config['tune']['colsample_bytree']['high']),
                    "alpha": hp.loguniform('alpha',
                                           np.log(10**self.config['tune']['alpha']['low']),
                                           np.log(10**self.config['tune']['alpha']['high'])),
                    "reg_lambda": hp.uniform('reg_lambda',
                                             self.config['tune']['learning_rate']['low'],
                                             self.config['tune']['learning_rate']['high'])
                }
        elif self.framework == CypherTrainer.LGBM:
            space = {
                    "n_estimators": hp.randint('n_estimators',
                                                self.config['tune']['n_estimators']['low'],
                                                self.config['tune']['n_estimators']['high']),
                    "learning_rate": hp.uniform('learning_rate',
                                                self.config['tune']['learning_rate']['low'],
                                                self.config['tune']['learning_rate']['high']),
                    "num_leaves": hp.randint('num_leaves',
                                             self.config['tune']['num_leaves']['low'],
                                             self.config['tune']['num_leaves']['high']),
                    "max_depth": hp.randint('max_depth',
                                            self.config['tune']['max_depth']['low'],
                                            self.config['tune']['max_depth']['high']),
                    "min_child_samples": hp.randint('min_child_samples',
                                                    self.config['tune']['min_child_samples']['low'],
                                                    self.config['tune']['min_child_samples']['high']),
                    "subsample": hp.uniform('subsample',
                                            self.config['tune']['subsample']['low'],
                                            self.config['tune']['subsample']['high']),
                    "colsample_bytree": hp.uniform('colsample_bytree',
                                                   self.config['tune']['colsample_bytree']['low'],
                                                   self.config['tune']['colsample_bytree']['high']),
                    "reg_alpha": hp.uniform('reg_alpha',
                                            self.config['tune']['reg_alpha']['low'],
                                            self.config['tune']['reg_alpha']['high']),
                    "reg_lambda": hp.uniform('reg_lambda',
                                             self.config['tune']['reg_lambda']['low'],
                                             self.config['tune']['reg_lambda']['high'])
                }

        return space

    def _cast_torch_parameters(self, best: dict) -> dict:
        """
        Casts hyperparameters to their appropriate types.

        This function adjusts the hyperparameter types based on the run_name. For 'lstm_v1', it casts certain
        parameters to int or float. For other models, it retrieves the best values by index and also addresses
        a known issue with Hyperopt (https://github.com/hyperopt/hyperopt/issues/253) where it returns floats
        instead of ints. Despite the issue being marked as resolved, the problem persists, and this workaround
        serves as a temporary solutio

        Parameters:
            best (dict): Dictionary of hyperparameters to be cast.

        Returns:
            dict: Dictionary with hyperparameters cast to the correct types.
        """
        if self.config['info']['model_id'] == "lstm_v1":
            best['num_layers'] = int(best['num_layers'])  # Casting to int
            best['batch_size'] = int(best['batch_size'])  # Casting to int
            # Additional parameters specific to LSTM model
            best['dropout_prob'] = float(best['dropout_prob'])  # Casting to float
            best['learning_rate'] = float(best['learning_rate'])  # Casting to float
            best['l2_reg'] = float(best['l2_reg'])  # Casting to float
            best['hidden_dim'] = int(best['hidden_dim'])  # Casting to int
        else:
            d_model_list = self.config['tune']['d_model']
            opt_name_list = self.config['tune']['opt_name']
            scheduler_name_list = self.config['tune']['scheduler_name']
            num_heads_list = self.config['tune']['num_heads']
            best['d_model'] = d_model_list[best['d_model']]  # Get best d_model value by index
            best['opt_name'] = opt_name_list[best['opt_name']]  # Get best opt_name value by index
            best['scheduler_name'] = scheduler_name_list[best['scheduler_name']]  # Get best reg_lambda value by index
            best['num_heads'] = num_heads_list[best['num_heads']]  # Get best num_heads value by index

            # NOTE: There is an issue where scope returns float instead of int: https://github.com/hyperopt/hyperopt/issues/253;
            #       The issue is close but I haven't been able to return the correct values ​​yet.
            #       For now I forced a integer casting in the parameters that use scope
            best['max_len'] = int(best['max_len'])  # Get best num_heads value by index
            best['num_layers'] = int(best['num_layers'])  # Get best num_heads value by index
            best['batch_size'] = int(best['batch_size'])  # Get best num_heads value by index

        return best

    def fit(self,
            Xtr: np.ndarray,
            ytr: np.ndarray) -> dict:
        """
        Fits the model using hyperparameter tuning.

        Args:
            Xtr (np.ndarray): Training input features.
            ytr (np.ndarray): Training target labels or values.

        Returns:
            dict: the best hyperparameters found by the tuning process.
        """
        def _objective(params: dict):
            # Objective function for tuning
            with mlflow.start_run(nested=True):
                # Update model parameters for the current iteration
                self.config['params'].update(params)
                val_loss = None
                try:
                    # Create a trainer instance and fit the model
                    trainer = Trainer(self.config)
                    if self.framework in ['lgbm', 'xgboost', 'torch'] and self.is_cross_validation:
                        val_loss = trainer.fit_cv(Xtr, ytr)
                    else:
                        val_loss = trainer.fit(Xtr, ytr)

                except Exception as error:
                    logger.error(f"Training error: {error}")
                    logger.error(f"Validation loss: {val_loss}")

                    val_loss = float('inf')  # Return a high loss to indicate failure

                return {'loss': val_loss, 'status': STATUS_OK}

        # Build the search space and execute the tuning
        self.search_space = self._build_search_space()

        with mlflow.start_run(run_name=self.run_name):
            best = fmin(
                fn=_objective,
                space=self.search_space,
                algo=tpe.suggest,
                max_evals=self.config['tune']['max_evals'])  # Define the maximum number of evaluations during tuning

            if self.framework == 'torch':
                best = self._cast_torch_parameters(best)

        return best
