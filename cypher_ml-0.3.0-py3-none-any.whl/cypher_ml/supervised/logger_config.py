import logging
import os
from utils import current_time


def setup_logger(name='logger', level=logging.INFO):
    """
    Function to setup as many loggers as you want

    Parameters:
    name (str): Name of the logger.
    log_file (str): Filename of the log file.
    level: Logging level, e.g., logging.INFO.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Clear existing handlers to avoid duplicates
    if logger.hasHandlers():
        logger.handlers.clear()

    logging.getLogger("py4j").setLevel(logging.ERROR)
    logging.getLogger("org.apache.spark").setLevel(logging.ERROR)
    logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.DEBUG)

    try:
        file_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        file_dir = os.getcwd()

    date_time = current_time().replace(" ", "-")
    log_name = f"output_{date_time}.log"
    log_dir = os.path.join(file_dir, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, log_name)

    logger.propagate = False  # Disable propagation to avoid duplicate logs in the console

    #c_handler = logging.StreamHandler()
    #c_handler.setLevel(logging.WARNING)

    f_handler = logging.FileHandler(log_file)
    f_handler.setLevel(level)

    #c_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
    f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    #c_handler.setFormatter(c_format)
    f_handler.setFormatter(f_format)

    #logger.addHandler(c_handler)
    logger.addHandler(f_handler)

    return logger


def log_message(logger, level, message):
    logger.log(level, message)
