import xgboost as xgb

from typing import Dict


class XGBoostClf:
    """
    A wrapper class for the XGBoost classifier.

    This class initializes an XGBoost classifier model with the given parameters.

    Attributes:
        clf (xgb.XGBClassifier): The XGBoost classifier model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the XGBoost classifier model with specified parameters.

        Args:
            params (Dict[str, float]): A dictionary of parameters for the XGBoost classifier.
                Expected keys are 'n_estimators', 'learning_rate', 'gamma', 'max_depth',
                'subsample', 'colsample_bytree', 'alpha', and 'reg_lambda'.
        """
        self.clf = xgb.XGBClassifier(**params)


class XGBoostReg:
    """
    A wrapper class for the XGBoost regressor.

    This class initializes an XGBoost regressor model with the given parameters.

    Attributes:
        reg (xgb.XGBRegressor): The XGBoost regressor model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the XGBoost regressor model with specified parameters.

        Args:
            params (Dict[str, float]): A dictionary of parameters for the XGBoost regressor.
                Expected keys are 'n_estimators', 'learning_rate', 'gamma', 'max_depth',
                'subsample', 'colsample_bytree', 'alpha', and 'reg_lambda'.
        """
        self.reg = xgb.XGBRegressor(**params, eval_metric='rmse')
