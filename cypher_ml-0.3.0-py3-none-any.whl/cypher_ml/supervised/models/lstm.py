import torch
import torch.nn as nn


class LSTMReg(nn.Module):
    """
    LSTM Regression Model.

    Attributes:
        lstm (nn.LSTM): LSTM layers.
        fc (nn.Linear): Fully connected output layer.

    Parameters:
        params (Optional[Dict]): Dictionary containing parameters for the LSTM model.
                                 Expected keys are 'input_size', 'hidden_size', 'num_layers', and 'dropout_prob'.
    """
    def __init__(self, params: dict = None):
        super().__init__()

        # User parameters
        input_size = params['input_size']
        hidden_size = params['hidden_size']
        num_layers = params['num_layers']
        dropout_prob = params['dropout_prob']

        # Build net
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout_prob if num_layers > 1 else 0.0)

        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for the LSTM regression model.

        Parameters:
            x (torch.Tensor): The input data.

        Returns:
            torch.Tensor: The output of the model.
        """
        lstm_out, _ = self.lstm(x)

        return self.fc(lstm_out[:, -1, :]).squeeze(-1)


class LSTMClf(nn.Module):
    """
    LSTM Classification Model.

    Attributes:
        lstm (nn.LSTM): LSTM layers.
        fc (nn.Linear): Fully connected output layer.
        dropout (nn.Dropout): Dropout layer for regularization.

    Parameters:
        params (Optional[Dict]): Dictionary containing parameters for the LSTM model.
                                 Expected keys are 'input_size', 'hidden_size', 'num_layers', and 'dropout_prob'.
    """
    def __init__(self, params: dict = None):
        super().__init__()

        # User parameters
        input_size = params['input_size']
        hidden_size = params['hidden_size']
        num_layers = params['num_layers']
        dropout_prob = params['dropout_prob']
        num_classes = params['num_classes']
        self.loss_name = params['loss_name']
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout_prob if num_layers > 1 else 0.0,
        )

        # Fully connected output layer
        self.fc = nn.Linear(hidden_size, num_classes)

        # Dropout layer for regularization (optional)
        self.dropout = nn.Dropout(dropout_prob)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for the LSTM classification model.

        Parameters:
            x (torch.Tensor): The input data.

        Returns:
            torch.Tensor: The output of the model.
        """
        # Initialize hidden and cell states
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)

        # LSTM forward pass
        out, _ = self.lstm(x, (h0, c0))
        # Applying dropout
        out = self.dropout(out)

        out = self.fc(out[:, -1, :])

        if self.loss_name == 'bce_logit' or self.loss_name == 'cross_entropy':
            return out  # raw
        else:
            return self.sigmoid(out)