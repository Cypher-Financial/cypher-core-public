from .common_imports import *

from layers.positional_encoding import FrequencyPositionalEnconding


class TransformerEncoderReg(nn.Module):
    """
    Transformer Encoder for Classification tasks.

    Parameters:
        params (dict): Configuration dictionary containing model and user-defined parameters.
    """
    def __init__(self, params: dict = None):

        super().__init__()

        # User parameters
        timestep = params['timestep']
        output_size = params['output_size']

        # Model parameters
        d_model = params['d_model']
        num_layers = params['num_layers']
        num_heads = params['num_heads']
        dropout_prob = params['dropout_prob']
        max_len = params['max_len']
        input_size = params['input_size']

        if d_model % num_heads != 0:
            raise ValueError("The model dimension of enc/dec layers should " +
                             "divisible by the number of heads!")

        # Build layers
        xdim = input_size * timestep

        if max_len < xdim:
            raise ValueError("Positional encoding should have a minimum size " +
                             "to represent each position sequence information!")

        if output_size > 1:
            raise ValueError("The model was designed for just one step look ahead for now!")

        # Build layers
        xdim = timestep * input_size
        ydim = output_size

        self.linear_proj = nn.Linear(xdim, d_model)

        self.positional_encoder = FrequencyPositionalEnconding(d_model=d_model,
                                                               dropout_p=dropout_prob,
                                                               max_len=max_len)

        enc_layer = nn.TransformerEncoderLayer(d_model=d_model,
                                               nhead=num_heads,
                                               dropout=dropout_prob,
                                               activation='relu')

        self.enc = nn.TransformerEncoder(enc_layer, num_layers=num_layers)
        self.relu = nn.ReLU()
        self.output = nn.Linear(d_model, ydim)

    def forward(self, src: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the Transformer Encoder for Regression.

        Parameters:
            src (torch.Tensor): The input time series data.

        Returns:
            torch.Tensor: The predicted output from the model.
        """
        # Apply the linear projection
        lp = self.linear_proj(src)  # (bs, dm)

        # Add positional information
        pe = self.positional_encoder(lp)  # (xdim, dm)

        # Encoder
        out = self.enc(pe)  # (bs, bs, dm)

        # Output
        pre = self.output(out)  # (bs, bs, ydim)

        return self.relu(pre[0, :, :])  # (bs, ydim)


class TransformerEncoderClf(nn.Module):
    """
    Transformer Encoder for Classification tasks.

    Parameters:
        params (dict): Configuration dictionary containing model and user-defined parameters.
    """
    def __init__(self, params: dict = None):

        super().__init__()

        # User parameters
        timestep = params['timestep']
        output_size = params['output_size']

        # Model parameters
        d_model = params['d_model']
        num_layers = params['num_layers']
        num_heads = params['num_heads']
        dropout_prob = params['dropout_prob']
        max_len = params['max_len']
        input_size = params['input_size']
        self.loss_name = params['loss_name']

        if d_model % num_heads != 0:
            raise ValueError("The model dimension of enc/dec layers should " +
                             "divisible by the number of heads")

        # Build layers
        xdim = input_size * timestep  # For encoder input dimention is the size of features x timestep
                                      # (e.g: Input has 10 features and timestep is 2, so xdim = 10 * 2

        if max_len < xdim:
            raise ValueError("Positional encoding should have a minimum size " +
                             "to represent each position sequence information.")

        # Add a linear projection layer to enable working with different input_dim and model dimension
        self.linear_proj = nn.Linear(xdim, d_model)

        self.positional_encoder = FrequencyPositionalEnconding(d_model=d_model,
                                                               dropout_p=dropout_prob,
                                                               max_len=max_len)

        enc_layer = nn.TransformerEncoderLayer(d_model=d_model,
                                               nhead=num_heads,
                                               dropout=dropout_prob,
                                               activation='relu')

        self.enc = nn.TransformerEncoder(enc_layer, num_layers=num_layers)

        self.output = nn.Linear(d_model, output_size)

        self.sigmoid = nn.Sigmoid()

    def forward(self, src: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the Transformer Encoder for Classification.

        Parameters:
            src (torch.Tensor): The input time series data.

        Returns:
            torch.Tensor: The predicted class probabilities.
        """
        # Apply the linear projection
        lp = self.linear_proj(src)  # (bs, dm)

        # Add positional information
        pe = self.positional_encoder(lp)  # (xdim, dm)

        # Encoder
        out = self.enc(pe)  # (bs, bs, dm)

        # Output
        pre = self.output(out)  # (bs, bs, n_cls)

        if self.loss_name == 'bce_logit' or self.loss_name == 'cross_entropy':
            return pre[0, :, :]  # (bs, n_cls)
        else:
            return self.sigmoid(pre[0, :, :]) # (bs, n_cls)
