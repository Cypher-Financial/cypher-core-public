from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor

from typing import Dict


class RfClf:
    """
    A wrapper class for the Rf classifier.
    This class initializes an Rf classifier model with the given parameters.
    Attributes:
        clf  (RandomForestClassifier): The Rf classifier model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the Rf classifier model with specified parameters.
        Args:
            params (Dict[str, float]): A dictionary of parameters for the Rf classifier.
                Expected keys is 'n_estimators'.
        """
        self.clf = RandomForestClassifier(**params)


class RfReg:
    """
    A wrapper class for the Rf regressor.
    This class initializes an Rf regressor model with the given parameters.
    Attributes:
        reg (RandomForestRegressor): The Rf regressor model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the Rf regressor model with specified parameters.
        Args:
            params (Dict[str, float]): A dictionary of parameters for the Rf regressor.
                Expected keys is 'n_estimators'.
        """
        self.reg =  RandomForestRegressor(**params)
