
from sklearn.linear_model import LogisticRegression

from typing import Dict


class LrClf:
    """
    A wrapper class for the Lr classifier.
    This class initializes an Lr classifier model with the given parameters.
    Attributes:
        clf  (LogisticRegression): The Lr classifier model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the Lr classifier model with specified parameters.
        Args:
            params (Dict[str, float]): A dictionary of parameters for the Lr classifier.
                Expected keys is 'C'.
        """
        self.clf = LogisticRegression(**params)
