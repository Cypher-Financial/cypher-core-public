import lightgbm as lgb

from typing import Dict


class LgbmClf:
    """
    A wrapper class for the Lgbm classifier.

    This class initializes an Lgbm classifier model with the given parameters.

    Attributes:
        clf  (lgb.LGBMClassifier): The Lgbm classifier model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the Lgbm classifier model with specified parameters.

        Args:
            params (Dict[str, float]): A dictionary of parameters for the Lgbm classifier.
                Expected keys are 'n_estimators', 'learning_rate', 'gamma', 'max_depth',
                'subsample', 'colsample_bytree', 'alpha', and 'reg_lambda'.
        """
        self.clf = lgb.LGBMClassifier(**params)


class LgbmReg:
    """
    A wrapper class for the Lgbm regressor.

    This class initializes an Lgbm regressor model with the given parameters.

    Attributes:
        reg (lgb.LGBMRegressor): The Lgbm regressor model.
    """

    def __init__(self, params: Dict[str, float]):
        """
        Initializes the Lgbm regressor model with specified parameters.

        Args:
            params (Dict[str, float]): A dictionary of parameters for the Lgbm regressor.
                Expected keys are 'n_estimators', 'learning_rate', 'gamma', 'max_depth',
                'subsample', 'colsample_bytree', 'alpha', and 'reg_lambda'.
        """
        self.reg = lgb.LGBMRegressor(**params)
