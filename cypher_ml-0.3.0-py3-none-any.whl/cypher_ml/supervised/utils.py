import yaml
import json
import random
import string
#import logging
import re
import os
import copy
import asyncio
#import psutil
import concurrent.futures
from typing import Any, Dict, Tuple
from datetime import datetime
from collections import Counter

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import ast
from optimize_cutoff import *
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from constants import DataColums
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import functions as F


def create_spark_session(app_name: str,
                         total_cpus: int,
                         storage_account_name: str,
                         storage_account_key: str,
                         executor_memory: str = "8G",
                         driver_memory: str = "64G",
                         max_result_size: str = "32g"):
    # Create the SparkSession with configurations
    spark = SparkSession.builder \
        .appName(app_name) \
        .config("spark.jars.packages", "io.delta:delta-spark_2.12:3.2.0,org.apache.hadoop:hadoop-azure:3.2.0") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
        .config("spark.executor.memory", executor_memory) \
        .config("spark.driver.memory", driver_memory) \
        .config("spark.driver.maxResultSize", max_result_size) \
        .config("spark.dynamicAllocation.enabled", "true") \
        .config("spark.dynamicAllocation.minExecutors", "1") \
        .config("spark.default.parallelism", str(total_cpus * 2)) \
        .config("spark.executor.extraJavaOptions", "-XX:ReservedCodeCacheSize=4096M -XX:+UseG1GC -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:./gc.log") \
        .config("spark.driver.extraJavaOptions", "-XX:+UseG1GC -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:./gc.log") \
        .config("spark.sql.autoBroadcastJoinThreshold", "-1") \
        .config("spark.sql.adaptive.enabled", "true") \
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
        .config("spark.sql.adaptive.skewJoin.enabled", "true") \
        .config("spark.sql.adaptive.localShuffleReader.enabled", "true") \
        .config("spark.sql.broadcastTimeout", "1200") \
        .config("spark.sql.codegen.wholeStage", "true") \
        .config("spark.sql.inMemoryColumnarStorage.batchSize", "10000") \
        .config("spark.sql.inMemoryColumnarStorage.compressed", "true") \
        .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
        .config("spark.sql.debug.maxToStringFields", "1000") \
        .config("spark.sql.shuffle.partitions", str(total_cpus * 2)) \
        .config("spark.sql.adaptive.coalescePartitions.initialPartitionNum", str(total_cpus)) \
        .config("spark.memory.fraction", "0.6") \
        .config("spark.memory.storageFraction", "0.5") \
        .config("spark.speculation", "true") \
        .config("spark.speculation.quantile", "0.75") \
        .config("spark.speculation.multiplier", "1.5") \
        .config("spark.shuffle.service.enabled", "true") \
        .config("spark.shuffle.file.buffer", "1m") \
        .config("spark.shuffle.io.preferDirectBufs", "true") \
        .config("spark.network.timeout", "800s") \
        .config("spark.network.io.retryWait", "5s") \
        .config("spark.network.io.maxRetries", "10") \
        .config("spark.task.maxFailures", "8") \
        .config("spark.broadcast.blockSize", "128m") \
        .config(f"spark.hadoop.fs.azure.account.key.{storage_account_name}.blob.core.windows.net", storage_account_key) \
        .master("local[*]") \
        .getOrCreate()

    return spark


def load_config(file_path: str) -> Dict[str, Any]:
    """
    Load and return the configuration from a YAML file.

    Parameters:
        file_path (str): The path to the configuration YAML file.

    Returns:
        Dict[str, Any]: A dictionary containing the configuration parameters.
    """
    # Open the file and load the YAML content
    with open(file_path, "r") as file:
        try:
            yaml_data = yaml.safe_load(file)
            return yaml_data  # Returning the loaded configuration
        except yaml.YAMLError as exc:
            print(f"Error loading YAML file: {exc}")
            raise


def get_dummie_data(
    url: str = "http://storage.googleapis.com/download.tensorflow.org/data/heart.csv",
):
    """
    Loads a dataset from the specified URL, performs preprocessing and scaling, and splits
    it into training and testing sets for a binary classification task.

    The default dataset is a a CSV file where the target variable is named 'target'.
    Specific columns ('sex', 'cp', 'fbs', 'restecg', 'exang', 'thal') are one-hot encoded,
    and the features are scaled using StandardScaler. The target variable is converted
    to binary classification (1 if 'target' > 0, else 0). The data is then split into
    training and testing sets.

    Parameters:
        url (str): The URL to download the dataset from. Default is set to TensorFlow's heart disease dataset.

    Returns:
        - X_train (np.array): Training features array, scaled and preprocessed.
        - X_test (np.array): Testing features array, scaled and preprocessed.
        - y_train (np.array): Training target array, binary encoded and reshaped to (n, 1).
        - y_test (np.array): Testing target array, binary encoded and reshaped to (n, 1).
    """
    # Load dataset
    df = pd.read_csv(url)

    # Preprocessing
    df = pd.get_dummies(df, columns=["sex", "cp", "fbs", "restecg", "exang", "thal"])
    scaler = StandardScaler()
    X = scaler.fit_transform(df.drop("target", axis=1))
    y = df["target"].values

    # Convert to binary classification
    y = np.array((y > 0).astype(int))

    # Convert to binary classification
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Convert (n,) to (n, 1)
    y_train = y_train.reshape(-1, 1)
    y_test = y_test.reshape(-1, 1)

    return X_train, X_test, y_train, y_test

def scaling(scaler_info, xtrain, xtest=None):
    is_scaling = scaler_info.get('is_scaling', False)  # Default to False if not provided
    method = scaler_info.get('method')

    if method is None:
        raise ValueError("Scaling method must be provided.")

    if method == 'minmax':
        feature_range = tuple(scaler_info.get('feature_range', (0, 1)))  # Default to (0, 1)
        scaler = MinMaxScaler(feature_range=feature_range)
    else:
        raise ValueError("Scaling method not implemented!!!")

    if is_scaling:
        xtrain_scaled = scaler.fit_transform(xtrain)
        if xtest is not None and not xtest.empty:  # Corrected condition
            xtest_scaled = scaler.transform(xtest)
        else:
            xtest_scaled = None
        return xtrain_scaled, xtest_scaled, scaler
    else:
        return xtrain, xtest, None

def windowing(
    df_ind: pd.DataFrame,
    features: str,
    end_train_date: str,
    end_test_date: str,
    TIMESTAMP: str,
    TARGET: str,
    imbalance: bool = False,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Splits the given data into training and testing sets based on a specified time window.

    Parameters:
        df_ind (pd.DataFrame): The DataFrame containing the data to be windowed.
        features (str): The name of the column in 'data' which contains the selected features in JSON format.
        end_train_date (str): The value of the end of training date used to split into train and test data.
        TIMESTAMP (str): The name of the column in 'data' representing the time component.
        TARGET (str): The name of the target column in 'data'.
        imbalance (bool): True to imbalance oversample df class

    Returns:
        Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]: A tuple containing:
            - X_train (pd.DataFrame): Training features.
            - X_test (pd.DataFrame): Testing features.
            - y_train (pd.DataFrame): Training target.
            - y_test (pd.DataFrame): Testing target.
    """
    if imbalance:
        smote = SMOTE(random_state=42)  # Fixed random state
        X_oversampled, y_oversampled = smote.fit_resample(
            df_ind.drop("TARGET", axis=1), df_ind["TARGET"]
        )

        df_oversampled = pd.DataFrame(X_oversampled, columns=df_ind.columns[:-1])
        df_oversampled["TARGET"] = y_oversampled

        df_ind = df_oversampled

    # Get selected features by an selection method

    cols = ast.literal_eval(features)

    # Windowing
    X_train = df_ind[df_ind[TIMESTAMP] < end_train_date][cols]
    y_train = df_ind[df_ind[TIMESTAMP] < end_train_date][TARGET]

    X_test = df_ind[(df_ind[TIMESTAMP] >= end_train_date) & (df_ind[TIMESTAMP] < end_test_date)][cols]
    y_test = df_ind[(df_ind[TIMESTAMP] >= end_train_date) & (df_ind[TIMESTAMP] < end_test_date)][TARGET]

    return X_train, X_test, y_train, y_test


def get_timestamp_data(
    df_ind: pd.DataFrame,
    end_train_date: str,
    TIMESTAMP: str
) -> pd.DataFrame:
    """
    Extract data from a DataFrame based on timestamp.

    Args:
        data (pd.DataFrame): The input DataFrame containing the data.
        data_idx (str): The value to filter the 'dataframe' column on.
        dataframe (str): The name of the column to filter on.
        timestamp (str): The name of the timestamp column.
        end_train_date (str): The name of the end_train_date column..

    Returns:
        DataFrame: A DataFrame containing the filtered data based on the specified conditions.
    """
    # Filter window timestamp
    df_timestamp = df_ind[df_ind[TIMESTAMP] >= end_train_date]

    return df_timestamp


def load_spark_dataframe(spark: SparkSession, table_name: str = None) -> pd.DataFrame:
    """
    Loads data from a Spark SQL table and converts it to a sorted pandas DataFrame.

    Parameters:
        table_name (Optional[str]): The name of the table to load from Spark SQL.
                                    If None, no table will be specified.

    Returns:
        pd.DataFrame: A pandas DataFrame sorted by the TIMESTAMP column.
    """
    # Load data from the specified Spark SQL table
    df_spk = spark.sql(f"SELECT * FROM {table_name}")

    return df_spk


def init_backtest() -> pd.DataFrame:
    """
    Initializes a DataFrame for backtesting.

    Returns:
        pd.DataFrame: An empty pandas DataFrame with columns for TIMESTAMP, SIGNAL, and TICKER.
    """
    # Initialize and return an empty DataFrame with specific columns
    return pd.DataFrame(
        columns=[DataColums.TIMESTAMP, DataColums.SIGNAL, DataColums.TICKER]
    )


def create_backtest_signal(data: pd.DataFrame, signal: pd.Series) -> pd.DataFrame:
    """
    Creates a backtest DataFrame with the given signal data.

    Parameters:
        data (pd.DataFrame): The DataFrame containing the TIMESTAMP and TICKER data.
        signal (pd.Series): A pandas Series containing the signal data.

    Returns:
        pd.DataFrame: A DataFrame with TIMESTAMP, SIGNAL, and TICKER columns.
    """
    # Construct and return the backtest DataFrame
    return pd.DataFrame(
        {
            DataColums.TIMESTAMP: data[DataColums.TIMESTAMP][-len(signal) :],
            DataColums.SIGNAL: signal,
            DataColums.TICKER: data[DataColums.TICKER][-len(signal) :],
        }
    )


def format_backtest_signal(signal: pd.DataFrame,
                           is_multiclass: bool,
                           risk: int) -> pd.DataFrame:
    """
    Formats the signal column in the provided DataFrame.

    This function changes the values in the 'SIGNAL' column of the DataFrame:
    If the value is 0, it is replaced with -1. All other values remain unchanged.

    Parameters:
        signal (pd.DataFrame): A DataFrame containing the 'SIGNAL' column.
        is_multiclass (bool): Flag to choose binary or multiclass.
        risk (int): Level of risk 0 (low) and 1 (high).

    Returns:
        pd.DataFrame: The DataFrame with the formatted
    """
    if is_multiclass:
        if risk == "low":  # (sell, buy, hold)
            strong_sell, strong_buy = 0, 1
            return signal[DataColums.SIGNAL].apply(
                lambda x: -1 if x == strong_sell else (1 if x == strong_buy else 0)
            )
        else:
            sell, buy, strong_sell, strong_buy = (
                0,
                1,
                2,
                3,
            )  # (sell, buy, strong sell, strong buy, hold)
            return signal[DataColums.SIGNAL].apply(
                lambda x: (
                    -1
                    if x in [sell, strong_sell]
                    else (1 if x in [buy, strong_buy] else 0)
                )
            )
    else:
        # binary
        return signal[DataColums.SIGNAL].apply(lambda x: -1 if x == 0 else x)


def save_metadata_model(spark: SparkSession,
                        model_id: str,
                        backtest_id: str,
                        config: dict) -> None:
    """
    Save the metadata of a model to a Delta table.
    This function takes a model identifier and its configuration, converts the configuration into
    a string, and then creates a DataFrame with this information. The DataFrame is then appended
    to a Delta table named 'gold.metadata_model_id'.
    Parameters:
        spark (SparkSession): An active SparkSession instance.
        model_id (str): A unique identifier for the model.
        backtest_id (str): A unique identifier for the backtest.
        config (dict): A dictionary containing the configuration settings of the model.
    Returns:
        None: This function does not return anything.
    """
    # Define the schema
    schema = StructType(
        [
            StructField("MODEL_ID", StringType(), True),
            StructField("BACKTEST_ID", StringType(), True),
            StructField("CONFIG", StringType(), True),
        ]
    )

    # Convert dict to string
    config_str = json.dumps(config)

    # Create a DataFrame
    metadata = [(model_id, backtest_id, config_str)]
    df_metadata = spark.createDataFrame(metadata, schema)

    # Save the DataFrame as a Delta table
    df_metadata.write.mode("append").format("delta").saveAsTable(
        "gold.metadata_model_id"
    )


def generate_alpha_numeric_key(length: int = 16) -> str:
    """
    Generate an alphanumeric key of a specified length.
    The generated key will include at least one digit and one letter.
    The characters are randomly shuffled to ensure variety.
    Args:
        length (int): The length of the key to be generated. Default is 8.
    Returns:
        str: An alphanumeric key of the specified length.
    Example:
        generate_alpha_numeric_key(16) -> '4Gh7K2eAbA83Msw5'
    """
    # Ensure the key has at least one digit and one letter
    key = [random.choice(string.ascii_letters), random.choice(string.digits)]

    # Fill the rest of the key with a random mix of digits and letters
    key += random.choices(string.ascii_letters + string.digits, k=length - 2)

    # Shuffle the list to randomize the order of characters
    random.shuffle(key)

    # Join the list into a string and return
    key_str = "".join(key)

    return key_str


def df_kelly(df_spk, df_id, train_signal):
    """
    Calculates the Kelly Criterion value based on the provided data frame, data frame ID, and training signal.

    The function filters the input data frame `df_spk` to include only the rows that match the specified `df_id` and
    where the 'TIMESTAMP' is less than or equal to 'END_TRAIN_DATE'. It then calculates the returns based on the 'CLOSE'
    prices and applies the training signal. The function computes the quantity and percentage of gains and losses
    for long and short signals, and uses these metrics to calculate the Kelly Criterion value, which is a measure of
    how much of the portfolio to allocate to each trade.

    Args:
        df_spk (pd.DataFrame): The input data frame containing stock information. Must include 'DATAFRAME',
                               'TIMESTAMP', 'END_TRAIN_DATE', 'TARGET', and 'CLOSE' columns.
        df_id (int or str): The ID used to filter the data frame.
        train_signal (int): The training signal to be applied. Expected to be either 1 (for long) or 0 (for short).

    Returns:
        float: The calculated Kelly Criterion value, indicating the optimal fraction of the portfolio to bet on each trade.

    Note:
        - The function assumes that the 'TIMESTAMP', 'TARGET', and 'CLOSE' columns are correctly formatted.
        - Returns are calculated as the percentage change in 'CLOSE' price.
        - The function automatically drops any rows with missing values resulting from the shift operation.
        - The Kelly Criterion value (k) is calculated using the formula: k = w - ((1 - w) / r), where
          w is the win ratio, and r is the win/loss return ratio.
    """

    df_train = df_spk[
        (df_spk["DATAFRAME"] == df_id)
        & (df_spk["TIMESTAMP"] <= df_spk["END_TRAIN_DATE"])
    ][["TIMESTAMP", "TARGET", "CLOSE"]]
    df_train["SIGNAL"] = train_signal
    df_train["RETURN"] = (df_train["CLOSE"].shift(-1) / df_train["CLOSE"]) - 1
    df_train = df_train.dropna()

    qty_gain_long = df_train[
        (df_train["SIGNAL"] == 1) & (df_train["TARGET"] == 1)
    ].shape[0]
    qty_gain_short = df_train[
        (df_train["SIGNAL"] == 0) & (df_train["TARGET"] == 0)
    ].shape[0]
    qty_gain = qty_gain_long + qty_gain_short

    percent_gain_long = df_train[(df_train["SIGNAL"] == 1) & (df_train["TARGET"] == 1)][
        "RETURN"
    ].sum()
    percent_gain_short = (
        df_train[(df_train["SIGNAL"] == 0) & (df_train["TARGET"] == 0)]["RETURN"].sum()
        * -1
    )
    percent_gain = percent_gain_long + percent_gain_short

    qty_loss_long = df_train[
        (df_train["SIGNAL"] == 1) & (df_train["TARGET"] == 0)
    ].shape[0]
    qty_loss_short = df_train[
        (df_train["SIGNAL"] == 0) & (df_train["TARGET"] == 1)
    ].shape[0]
    qty_loss = qty_loss_long + qty_loss_short

    percent_loss_long = (
        df_train[(df_train["SIGNAL"] == 1) & (df_train["TARGET"] == 0)]["RETURN"].sum()
        * -1
    )
    percent_loss_short = df_train[
        (df_train["SIGNAL"] == 0) & (df_train["TARGET"] == 1)
    ]["RETURN"].sum()
    percent_loss = percent_loss_long + percent_loss_short

    w = qty_gain / (qty_gain + qty_loss)
    r = percent_gain / percent_loss
    k = w - ((1 - w) / r)

    return k


def classify_pct_change(
    pct_change: float, threshold: float, trust_factor: int, risk: str
):
    """
    Classify the percentage change of a financial instrument into categories based
    on specified risk levels and thresholds.

    Parameters
    ----------
    pct_change : float
        The percentage change of the financial instrument, expressed as a decimal
        (e.g., 0.05 for a 5% increase).
    threshold : float, optional
        The base threshold for classifying percentage changes. The default value is 0.1.
    trust_factor : float, optional
        A multiplier applied to the threshold to adjust for stronger buy or sell signals.
        The default value is 1.
    risk : str, optional
        The risk appetite setting which adjusts the classification strategy.
        Accepted values are 'low' and 'high'. The default value is 'low'.

    Returns
    -------
    int
        An integer label representing the classification of the percentage change:
        - For 'low' risk: 0 (STRONG_SELL), 1 (STRONG_BUY), or 2 (HOLD)
        - For 'high' risk: 0 (SELL), 1 (BUY), 2 (HOLD), 3 (STRONG_BUY), or 4 (STRONG_SELL)

    Raises
    ------
    ValueError
        If the `risk` parameter does not match the expected 'low' or 'high' values.

    Notes
    -----
    The function uses the `threshold` and `trust_factor` parameters to determine the
    boundaries for classification. The `risk` parameter adjusts the granularity of the
    classification, with 'high' risk providing more categories (including SELL/BUY in addition
    to STRONG_SELL/STRONG_BUY and HOLD) than 'low' risk."""
    # Compute thresholds
    strong_buy_threshold = threshold * trust_factor
    buy_threshold = threshold
    sell_threshold = -threshold
    strong_sell_threshold = -threshold * trust_factor

    if risk not in ["low", "high", "none"]:
        raise ValueError("Risk is not implemented. Use 'low' or 'high'.")

    if risk == "low":
        cls_to_lbl = {"STRONG_SELL": 0, "STRONG_BUY": 1, "HOLD": 2}

        if pct_change >= strong_buy_threshold:
            return cls_to_lbl.get("STRONG_BUY")
        elif pct_change <= strong_sell_threshold:
            return cls_to_lbl.get("STRONG_SELL")
        else:
            return cls_to_lbl.get("HOLD")
    else:
        cls_to_lbl = {
            "SELL": 0,
            "BUY": 1,
            "STRONG_SELL": 2,
            "STRONG_BUY": 3,
            "HOLD": 4,
        }

        if pct_change >= strong_buy_threshold:
            return cls_to_lbl.get("STRONG_BUY")
        elif pct_change >= buy_threshold:
            return cls_to_lbl.get("BUY")
        elif pct_change <= strong_sell_threshold:
            return cls_to_lbl.get("STRONG_SELL")
        elif pct_change <= sell_threshold:
            return cls_to_lbl.get("SELL")
        else:
            return cls_to_lbl.get("HOLD")


def regression_signal(df, filter):

    df["SIGNAL"] = df.apply(
        lambda x: -1 if x["SIGNAL"] < -filter else (1 if x["SIGNAL"] > filter else 0),
        axis=1,
    )

    return df


def calculate_quantile(data, quantile):
    """
    Calculate the quantile of a list of numbers.

    Parameters:
    - data: List of numbers
    - quantile: Float representing the desired quantile (e.g., 0.5 for median, 0.25 for first quartile)

    Returns:
    - The quantile value.
    """
    # Sort the data
    sorted_data = sorted(data)

    # Calculate the position of the quantile
    n = len(sorted_data)
    position = (n - 1) * quantile

    # Find the indices surrounding the position
    lower_index = int(position)
    upper_index = lower_index + 1

    # Handle cases where the position is exactly an index
    if lower_index == upper_index or upper_index >= n:
        return sorted_data[lower_index]

    # Linear interpolation for cases where position is between two indices
    lower_value = sorted_data[lower_index]
    upper_value = sorted_data[upper_index]
    return lower_value + (upper_value - lower_value) * (position - lower_index)


def current_time():
    current_timestamp = datetime.now()
    return current_timestamp.strftime("%Y-%m-%d %H:%M:%S")


def current_br_time():
    current_timestamp = datetime.now(-3)
    return current_timestamp.strftime("%Y-%m-%d %H:%M:%S")


def calculate_class_weight(y_train: np.array) -> dict:
    """Calculate class weights for imbalanced datasets
        This function computes the class weights based on the formula:
        weight(class) = n_samples / (n_classes * n_samples_class)

    Args:
        y_train (np.array): A list of class labels for the training data.

    Returns:
        dict: A dictionary with class labels (key) and its number of samples (values).
    """

    counter = Counter(y_train)
    n_samples = len(y_train)
    n_classes = len(counter)
    class_weight = {
        class_label: n_samples / (n_classes * n_samples_class)
        for class_label, n_samples_class in counter.items()
    }

    return class_weight


def plot_train_metrics(df):
    plot_loss_curve(df)
    plot_confusion_matrixes(df)
    plot_overall_metrics(df)


def plot_loss_curve(df):
    # Create subplots
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))

    # Plot loss curves
    for idx, row in df.iterrows():
        axes[0].plot(row["train_loss"], label=f"Model {idx} Train Loss")
        axes[1].plot(row["val_loss"], label=f"Model {idx} Val Loss")
    axes[0].set_title("Training Loss")
    axes[1].set_title("Validation Loss")
    axes[0].legend()
    axes[1].legend()

    # Adjust layout
    plt.tight_layout()
    plt.show()


def plot_confusion_matrixes(df):
    for idx, row in df.iterrows():
        fig, ax = plt.subplots(
            figsize=(6, 4)
        )  # You can adjust the figure size as needed
        sns.heatmap(np.array(row["cm"]), annot=True, fmt="d", cmap="Blues", ax=ax)
        ax.set_title(f"Confusion Matrix for Model {idx + 1}")
        plt.show()


def plot_overall_metrics(df):
    _, axes = plt.subplots(nrows=3, ncols=1, figsize=(10, 15))

    # Plot overall metrics
    df[["accuracy", "precision", "recall", "fscore"]].plot(kind="bar", ax=axes[0])
    axes[0].set_title("Overall Metrics")
    axes[0].set_xticklabels(range(len(df)), rotation=0)

    # Plot class-specific metrics for the first class
    class_0_metrics = pd.DataFrame(
        df[["precision_by_class", "recall_by_class", "fscore_by_class"]].applymap(
            lambda x: x[0]
        )
    )
    class_0_metrics.plot(kind="bar", ax=axes[1])
    axes[1].set_title("Class 0 Metrics")
    axes[1].set_xticklabels(range(len(df)), rotation=0)

    # Plot class-specific metrics for the second class
    class_1_metrics = pd.DataFrame(
        df[["precision_by_class", "recall_by_class", "fscore_by_class"]].applymap(
            lambda x: x[1]
        )
    )
    class_1_metrics.plot(kind="bar", ax=axes[2])
    axes[2].set_title("Class 1 Metrics")
    axes[2].set_xticklabels(range(len(df)), rotation=0)

    # Adjust layout
    plt.tight_layout()

    # Move the legend to the bottom of the plots
    plt.legend(
        loc="upper center", bbox_to_anchor=(0.5, -0.05), ncol=4, fontsize="small"
    )

    plt.show()


def validate_timeframe(timeframe: str):
    pattern = ["5m", "15m", "30m", "1h", "2h", "4h", "8h", "12h", "1d"]
    if timeframe in pattern:
        return True
    else:
        return False


def convert_timeframe_format(time_string):
    patterns = {
        r"(\d+)\s*minutes?": "m",  # Matches 'minute' or 'minutes' with any leading number and optional spaces
        r"(\d+)\s*hours?": "h",  # Matches 'hour' or 'hours' with any leading number and optional spaces
        r"(\d+)\s*days?": "d",  # Matches 'day' or 'days' with any leading number and optional spaces
    }

    for pattern, shorthand in patterns.items():
        time_string = re.sub(
            pattern, r"\1" + shorthand, time_string, flags=re.IGNORECASE
        )

    return time_string


def process_timeframe(timeframe):
    if validate_timeframe(timeframe):
        return timeframe
    converted_timeframe = convert_timeframe_format(timeframe)
    if validate_timeframe(converted_timeframe):
        return converted_timeframe
    raise ValueError("Invalid timeframe format")


def print_config(config: dict):
    for key, val in config.items():
        print(f"{key}, {val}")


def initialize_environment():
    """
    Sets up the environment for running the script.

    Returns:
        tuple: A tuple containing:
               - log_dir (str): The path to the logs directory.
               - spark (SparkSession): An instance of SparkSession for running Spark operations.
    """
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

    # Check if the directory already exists
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Set up Spark configuration
    spark = SparkSession.builder.getOrCreate()

    return log_dir, spark


def initialize_results_dataframe():
    """
    Initializes an empty DataFrame for storing results with predefined columns.

    Returns:
        df_results (pd.DataFrame): An empty DataFrame with specified columns.
    """
    columns = [
        "DATETIME",
        "CRYPTO",
        "DF_ID_START",
        "DF_ID_END",
        "TIMEFRAME",
        "POSITION_SIZE",
        "FRAMEWORK",
        "MODEL_NAME",
        "MODEL_TYPE",
        "IS_TUNE",
        "SELECTION",
        "STRATEGY_TYPE",
        "IS_UNBALANCED",
        "IS_CROSS_VALIDATION",
        "IS_BLOCK_CV",
        "N_SPLITS",
        "TABLE_KEY",
        "IS_MULTICLASS",
        "PCT_CHANGE_TH",
        "TRUST_FACTOR",
        "RISK",
        "TUNE_LOSS_FUNCTION",
        "BUY_HOLD",
        "DRAWDOWN",
        "STRATEGY",
        "STRATEGY_WITH_COST",
        "TRADES",
        "BACKTEST_ID",
    ]

    df_results = pd.DataFrame(columns=columns)
    return df_results

def initialize_strategy_metrics_dataframe():
    """
    Initializes an empty DataFrame for storing results with predefined columns.

    Returns:
        df_results (pd.DataFrame): An empty DataFrame with specified columns.
    """
    df_metrics = pd.DataFrame(columns=["MEAN_RETURNS", "STD_RETURNS", "SEMI_STD_RETURNS", "MAXDRAWDOWN",
                                    "MEAN_RET_TRADES", "STD_RET_TRADES", "SEMI_STD_RET_TRADES", "NUM_TRADES",
                                    "CAGR_RETURNS", "SLOPE_RETURNS", "DF_NUM", "BACKTEST_ID", "TICKER",
                                    "STRATEGY_TYPE", "OPTIMIZE_METHOD", "END_DATE",
                                    "MODEL_TYPE", "TIMEFRAME", "TABLE_KEY", "SELECTION", "NUM_FEATURES"])

    return df_metrics

def load_config_template(file_path):
    """
    Loads a configuration template from a YAML file.

    Parameters:
        file_path (str): The path to the YAML file that contains the configuration template.

    Returns:
        dict: A dictionary containing the loaded configuration from the YAML file.
    """
    with open(file_path, "r") as file:
        base_config = yaml.safe_load(file)

    return base_config


def update_configuration(base_config, row):
    """
    Updates a base configuration dictionary with values from a given row.

    The keys are expected to belong to one of the specific categories: 'backtest', 'info',
    'params', 'tune', or 'track'.

    Parameters:
        base_config (dict): The initial configuration dictionary that needs to be updated.
        row (dict): A dictionary containing the updates to be applied.

    Returns:
        dict: The updated configuration dictionary after applying the changes from the row.
    """
    config = copy.deepcopy(base_config)

    # Update the configuration based on the key
    for key, value in row.items():
        if key in config["backtest"]:
            config["backtest"][key] = value
        elif key in config["info"]:
            config["info"][key] = value
        elif key in config["params"]:
            config["params"][key] = value
        elif key in config["tune"]:
            config["tune"][key] = value
        elif key in config["track"]:
            config["track"][key] = value

    return config


def create_results_data(**kwargs):
    """
    Creates a dictionary with results data for logging or storage.

    Parameters:
        kwargs (dict): A dictionary of arguments.

    Returns:
        dict: A dictionary containing the compiled results data.
    """
    date_time = kwargs.get('date_time')
    ticker = kwargs.get('ticker')
    df_start_idx = kwargs.get('df_start_idx')
    df_end_idx = kwargs.get('df_end_idx')
    timeframe = kwargs.get('timeframe')
    position_size = kwargs.get('position_size')
    framework = kwargs.get('framework')
    model_name = kwargs.get('model_name')
    model_type = kwargs.get('model_type')
    is_tune = kwargs.get('is_tune')
    selection = kwargs.get('selection')
    optimize_method = kwargs.get('optimize_method')
    strategy_type = kwargs.get('strategy_type')
    is_unbalanced = kwargs.get('is_unbalanced')
    is_cross_validation = kwargs.get('is_cross_validation')
    is_block_cv = kwargs.get('is_block_cv')
    n_splits = kwargs.get('n_splits')
    table_key = kwargs.get('table_key')
    is_multiclass = kwargs.get('is_multiclass')
    pct_change_th = kwargs.get('pct_change_th')
    trust_factor = kwargs.get('trust_factor')
    risk = kwargs.get('risk')
    tune_loss_function = kwargs.get('tune_loss_function')
    df_bkt_obj = kwargs.get('df_bkt_obj')
    backtest_id = kwargs.get('backtest_id')
    #mrmr_selection = kwargs.get('mrmr_selection')
    #n_features_mrmr = kwargs.get('n_features_mrmr')
    is_multi_crypto_df = kwargs.get('is_multi_crypto_df')
    is_one_crypto_feats = kwargs.get('is_one_crypto_feats')
    selected_features = kwargs.get('selected_features')

    if df_bkt_obj.shape[0] == 0:
        cummul_returns_bh = 0.0
        drawdown = 0.0
        cummul_returns_strat = 0.0
        cum_ret_strat_with_cost = 0.0
        trade = df_bkt_obj["trade"].sum() / 2
    else:
        cummul_returns_bh = float((df_bkt_obj["cummul_returns_bh"].iloc[-1] - 1.0) * 100)
        drawdown = float(df_bkt_obj["drawdown"].max() * 100)
        cummul_returns_strat = float((df_bkt_obj["cummul_returns_strat"].iloc[-1] - 1.0) * 100)
        cum_ret_strat_with_cost = float((df_bkt_obj["cum_ret_strat_with_cost"].iloc[-1] - 1.0) * 100)
        trade = df_bkt_obj["trade"].sum() / 2

    results_data = {
        'DATETIME': date_time,
        'CRYPTO': ticker,
        'DF_ID_START': df_start_idx,
        'DF_ID_END': df_end_idx,
        'TIMEFRAME': timeframe,
        'POSITION_SIZE': position_size,
        'FRAMEWORK': framework,
        'MODEL_NAME': model_name,
        'MODEL_TYPE': model_type,
        'IS_TUNE': is_tune,
        'SELECTION': selection,
        'SIGNAL_TYPE': '-',
        'OPTIMIZE_METHOD': optimize_method,
        'STRATEGY_TYPE': strategy_type,
        'IS_UNBALANCED': is_unbalanced,
        'IS_CROSS_VALIDATION': is_cross_validation,
        'IS_BLOCK_CV': is_block_cv,
        'N_SPLITS': n_splits,
        'TABLE_KEY': table_key,
        'IS_MULTICLASS': is_multiclass,
        'PCT_CHANGE_TH': pct_change_th,
        'TRUST_FACTOR': trust_factor,
        'RISK': risk,
        'TUNE_LOSS_FUNCTION': tune_loss_function,
        'BUY_HOLD': cummul_returns_bh,
        'DRAWDOWN': drawdown,
        'STRATEGY': cummul_returns_strat,
        'STRATEGY_WITH_COST': cum_ret_strat_with_cost,
        'TRADES': trade,
        'BACKTEST_ID': backtest_id,
        #'MRMR_SELECTION': mrmr_selection,
        #'N_FEATURES_MRMR': n_features_mrmr,
        'IS_MULTICRYPTO_DF': is_multi_crypto_df,
        'IS_ONE_CRYPTO_FEATS': is_one_crypto_feats,
        'SELECTED_FEATURES': selected_features
    }

    return results_data


def reg_class_optimize_method(
    optim_methods,
    cutoff_min,
    cutoff_max,
    config,
    df_spk,
    X_train,
    trainer,
    framework,
    df_funding,
    model_type,
    X_test,
):
    best_return = -1
    method_return = -1
    for optimize_method in optim_methods:
        print(f"optimize_method:{optimize_method}")
        if model_type == "clf":
            if "fixed_percentil" in optimize_method:
                method_return, method_min_cutoff, method_max_cutoff = (
                    calculate_fixed_percentil(
                        config,
                        df_spk,
                        X_train,
                        trainer,
                        df_funding,
                        framework,
                        optimize_method,
                    )
                )
            else:
                if optimize_method != "best":
                    method_return, method_min_cutoff, method_max_cutoff = (
                        quantile_return_optimize(
                            config,
                            df_spk,
                            X_train,
                            trainer,
                            df_funding,
                            framework,
                            optimize_method,
                        )
                    )
        elif model_type == "reg":
            dynamic_percentil = [
                "X_train_mean_percentil",
                "X_train_inverse_cv_percentil",
                "X_train_max_point_percentil",
                "X_val_mean_percentil",
                "X_val_inverse_cv_percentil",
                "X_val_max_point_percentil",
            ]

            dynamic_filter = [
                "X_train_mean_filter",
                "X_train_inverse_cv_filter",
                "X_train_max_point_filter",
                "X_val_mean_filter",
                "X_val_inverse_cv_filter",
                "X_val_max_point_filter",
            ]

            if optimize_method != "best":
                if "fixed_percentil" in optimize_method:
                    method_return, method_min_cutoff, method_max_cutoff = (
                        calculate_fixed_percentil(
                            config,
                            df_spk,
                            X_train,
                            trainer,
                            df_funding,
                            framework,
                            optimize_method,
                        )
                    )
                elif "regression" in optimize_method:
                    method_return, method_min_cutoff, method_max_cutoff = (
                        fixed_regression_filter(
                            config,
                            df_spk,
                            X_train,
                            trainer,
                            df_funding,
                            framework,
                            optimize_method,
                        )
                    )
                elif optimize_method in dynamic_percentil:
                    method_return, method_min_cutoff, method_max_cutoff = (
                        quantile_return_optimize(
                            config,
                            df_spk,
                            X_train,
                            trainer,
                            df_funding,
                            framework,
                            optimize_method,
                        )
                    )
                elif optimize_method in dynamic_filter:
                    method_return, method_min_cutoff, method_max_cutoff = (
                        regression_filter_return_optimize(
                            config,
                            df_spk,
                            X_train,
                            trainer,
                            df_funding,
                            framework,
                            optimize_method,
                        )
                    )
                else:
                    pass
        else:
            raise ValueError("Model type not implemented!!!")

        if method_return > best_return:
            best_min_cutoff = method_min_cutoff
            best_max_cutoff = method_max_cutoff
            best_return = method_return

        if optimize_method == "best":
            cutoff_min[optimize_method].extend([best_min_cutoff] * X_test.shape[0])
            cutoff_max[optimize_method].extend([best_max_cutoff] * X_test.shape[0])
        else:
            cutoff_min[optimize_method].extend([method_min_cutoff] * X_test.shape[0])
            cutoff_max[optimize_method].extend([method_max_cutoff] * X_test.shape[0])

    return cutoff_min, cutoff_max


def generate_signal(
    df_backtest,
    is_multiclass,
    risk,
    cutoff_min,
    cutoff_max,
    optimize_method,
    model_type,
):

    if model_type == "clf":
        # Create column even if not used to avoid missing columns while saving backtest
        if optimize_method == "none":
            df_backtest[DataColums.SIGNAL] = format_backtest_signal(
                df_backtest, is_multiclass, risk
            )
        else:
            df_backtest["PROBABILITY_MIN"] = cutoff_min[optimize_method]
            df_backtest["PROBABILITY_MAX"] = cutoff_max[optimize_method]
            df_backtest["SIGNAL"] = df_backtest.apply(
                lambda x: (
                    -1
                    if x["PROBABILITY"] <= x["PROBABILITY_MIN"]
                    else (1 if x["PROBABILITY"] >= x["PROBABILITY_MAX"] else 0)
                ),
                axis=1,
            )
    else:
        df_backtest["PREDICT_MIN"] = cutoff_min[optimize_method]
        df_backtest["PREDICT_MAX"] = cutoff_max[optimize_method]
        df_backtest["SIGNAL"] = df_backtest.apply(
            lambda x: (
                -1
                if x["PREDICT"] <= x["PREDICT_MIN"]
                else (1 if x["PREDICT"] >= x["PREDICT_MAX"] else 0)
            ),
            axis=1,
        )

    df_backtest = df_backtest.dropna()

    return df_backtest


def create_optim_methods_list(config, strategy_types):
    percentils = [0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.30, 0.35, 0.40, 0.50]

    if config["info"]["model_type"] == "reg":
        optim_methods = [
            "X_train_mean_percentil",
            "X_train_inverse_cv_percentil",
            "X_train_max_point_percentil",
            "X_val_mean_percentil",
            "X_val_inverse_cv_percentil",
            "X_val_max_point_percentil",
            "X_train_mean_filter",
            "X_train_inverse_cv_filter",
            "X_train_max_point_filter",
            "X_val_mean_filter",
            "X_val_inverse_cv_filter",
            "X_val_max_point_filter",
        ]

        short_timeframe = ["5m", "15m", "30m", "1h"]
        medium_timeframe = ["2h", "4h", "8h"]
        long_timeframe = ["12h", "1d"]

        timeframe = config["backtest"]["timeframe"]

        if timeframe in short_timeframe:
            regression_filters = [0.001, 0.003, 0.005, 0.007, 0.009]
        elif timeframe in medium_timeframe:
            regression_filters = [0.01, 0.015, 0.02, 0.025, 0.03]
        elif timeframe in long_timeframe:
            regression_filters = [0.01, 0.02, 0.03, 0.04, 0.05]
        else:
            raise ValueError("Timeframe not implemented on this version!!!")

        for regression_filter in regression_filters:
            optim_methods.append("regression_filter_" + str(regression_filter))
    else:
        optim_methods = [
            "X_train_mean_percentil",
            "X_train_inverse_cv_percentil",
            "X_train_max_point_percentil",
            "X_val_mean_percentil",
            "X_val_inverse_cv_percentil",
            "X_val_max_point_percentil",
        ]

    for percentil in percentils:
        optim_methods.append("X_train_fixed_percentil_" + str(percentil))
        optim_methods.append("X_val_fixed_percentil_" + str(percentil))

    strategy_cutoff_min = {strategy_type: {method: [] for method in optim_methods} for strategy_type in strategy_types}
    strategy_cutoff_max = {strategy_type: {method: [] for method in optim_methods} for strategy_type in strategy_types}

    return optim_methods, strategy_cutoff_min, strategy_cutoff_max


async def _user_input():
    try:
        loop = asyncio.get_event_loop()
        input_ = await loop.run_in_executor(None, input, "To save backtest type ('y'|'n') or 'exit' to quit: ")
        return input_.strip().lower()
    except Exception:
        return None


async def save_backtest():
    try:
        input_task = asyncio.create_task(_user_input())
        try:
            input_ = await asyncio.wait_for(input_task, timeout=10)
            if input_ == "y":
                print("You started the training with saving backtest.")
                return True
            elif input_ == "n":
                print("You started the training without saving backtest.")
                return False
            elif input_ == "exit":
                print("You cancel the training.")
                return None
            else:
                raise ValueError("Input should be 'y' or 'n' or 'exit'.")
        except asyncio.TimeoutError:
            print('\nYour time got over')
            return None
    except Exception as error:
        print(f"An error occurred while receiving user input: {error}")


def spark_to_pandas_partitioned(spark_df, num_partitions):
    spark_df = spark_df.repartition(num_partitions)

    spark_df = spark_df.withColumn("partition_id", F.spark_partition_id())

    pandas_df_list = []

    # Collect each partition and convert it to a Pandas DataFrame
    for partition_id in range(num_partitions):
        partition_df = spark_df.filter(spark_df["partition_id"] == partition_id).drop("partition_id")
        partition_data = partition_df.collect()
        partition_pd = pd.DataFrame([row.asDict() for row in partition_data])
        pandas_df_list.append(partition_pd)

    # Concatenate all chunks into a single Pandas DataFrame
    full_pandas_df = pd.concat(pandas_df_list, ignore_index=True)

    return full_pandas_df


# def print_memory_usage(logger=None):
#     process = psutil.Process(os.getpid())
#     mem_info = process.memory_info()
#     print(f"RSS: {mem_info.rss / (1024 ** 2):.2f} MB, VMS: {mem_info.vms / (1024 ** 2):.2f} MB")
#     if logger:
#         logger.info(f"RSS: {mem_info.rss / (1024 ** 2):.2f} MB, VMS: {mem_info.vms / (1024 ** 2):.2f} MB")


def optimize_for_method(optimize_method, model_type, config, df_spk, X_train, trainer, df_funding, framework):
    if model_type == "clf":
        # Classifier optimization logic
        if "fixed_percentil" in optimize_method:
            return calculate_fixed_percentil(config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
        elif optimize_method != "best":
            return quantile_return_optimize(config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
    elif model_type == "reg":
        dynamic_percentil = [
                "X_train_mean_percentil",
                "X_train_inverse_cv_percentil",
                "X_train_max_point_percentil",
                "X_val_mean_percentil",
                "X_val_inverse_cv_percentil",
                "X_val_max_point_percentil",
            ]

        dynamic_filter = [
            "X_train_mean_filter",
            "X_train_inverse_cv_filter",
            "X_train_max_point_filter",
            "X_val_mean_filter",
            "X_val_inverse_cv_filter",
            "X_val_max_point_filter",
        ]
        try:
            # Regression optimization logic
            if "fixed_percentil" in optimize_method:
                return calculate_fixed_percentil(config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
            elif "regression" in optimize_method:
                return fixed_regression_filter(config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
            # Dynamic percentil or filter logic can be expanded here
            elif optimize_method in dynamic_percentil:
                return quantile_return_optimize(config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
            elif optimize_method in dynamic_filter:
                return regression_filter_return_optimize( config, df_spk, X_train, trainer, df_funding, framework, optimize_method)
        except Exception as e:
            print(e)
        finally:
            print(f"optimize_method: {optimize_method}")

    else:
        raise ValueError("Model type not implemented!!!")


def reg_class_optimize_method_concurrent(
    optim_methods,
    strategy_cutoff_min,
    strategy_cutoff_max,
    strategy_types,
    config,
    df_spk,
    X_train,
    trainer,
    framework,
    df_funding,
    model_type,
    X_test,
):
    best_return = -1
    results = {}
    for strategy_type in strategy_types:
        config['info']['strategy_type'] = strategy_type
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future_to_method = {executor.submit(optimize_for_method, method, model_type, config, df_spk, X_train, trainer, df_funding, framework): method for method in optim_methods}
            for future in concurrent.futures.as_completed(future_to_method):
                method = future_to_method[future]
                #try:
                method_return, method_min_cutoff, method_max_cutoff = future.result()
                results[method] = (method_return, method_min_cutoff, method_max_cutoff)

                if strategy_type not in strategy_cutoff_min:
                    strategy_cutoff_min[strategy_type] = {}

                    for method in optim_methods:
                        # Initialize the list for each method under strategy_type if it doesn't exist
                        if method not in strategy_cutoff_min[strategy_type]:
                            strategy_cutoff_min[strategy_type][method] = []

                if method_return > best_return:
                    best_min_cutoff = method_min_cutoff
                    best_max_cutoff = method_max_cutoff
                    best_return = method_return

                strategy_cutoff_min[strategy_type][method].extend([method_min_cutoff] * X_test.shape[0])
                strategy_cutoff_max[strategy_type][method].extend([method_max_cutoff] * X_test.shape[0])

    return strategy_cutoff_min, strategy_cutoff_max


def drop_all_temp_views(spark_session):
    all_tables = spark_session.catalog.listTables()
    temp_views = [table.name for table in all_tables if table.tableType == "TEMPORARY"]

    for view_name in temp_views:
        spark_session.catalog.dropTempView(view_name)
        print(f"Dropped temporary view: {view_name}")

    remaining_temp_views = [table.name for table in spark_session.catalog.listTables() if table.tableType == "TEMPORARY"]
    if not remaining_temp_views:
        print("All temporary views have been dropped successfully.")
    else:
        print("Some temporary views could not be dropped:", remaining_temp_views)
