import os
import gc
import time
import concurrent.futures
import traceback
import logging
from io import BytesIO
from azure.storage.blob import BlobServiceClient, ContainerClient
from itertools import product
from concurrent.futures import ProcessPoolExecutor
from typing import List
import mlflow
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from trainer import Trainer
from tuner import Tuner
from utils import *
from constants import DataColums
from backtest import Backtest
from dashboard_backtest import *
from optimize_cutoff import *
from dlhandler import DeltaLakeHandler
from logger_config import setup_logger
from pyspark.sql.functions import col, current_timestamp


DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR

LEVEL = INFO

logger = setup_logger(level=LEVEL)

def populate_line_df_metrics(df_slice, df_metrics, backtest_id, counter, ticker, strategy_type, optimize_method, end_date,
                             model_type, timeframe, table_key, selection, num_features):

    mean_window = df_slice["strategy_with_cost"].mean()

    std_window = df_slice["strategy_with_cost"].std()

    semi_std_window = df_slice[df_slice["strategy_with_cost"] < 0.0]["strategy_with_cost"].std()

    cummulative_rets = (1 + df_slice["strategy_with_cost"]).cumprod()
    peak_cummulative_rets = cummulative_rets.cummax()
    drawdown = (peak_cummulative_rets - cummulative_rets) / peak_cummulative_rets
    max_drawdown_window = drawdown.max()

    trades_filter = (df_slice["SIGNAL"] - df_slice["SIGNAL"].shift(1)).astype(bool)
    creturns_trades = cummulative_rets[trades_filter]
    returns_trades = (creturns_trades / creturns_trades.shift(1)) - 1.0

    mean_trades = returns_trades.mean()

    std_trades = returns_trades.std()

    semi_std_trades = returns_trades[returns_trades < 0.0].std()

    num_trades = trades_filter.sum()

    cagr_returns = ((cummulative_rets.iloc[-1] / cummulative_rets.iloc[0])**(365.25 / 180.00) - 1)

    slope_returns = np.polyfit(np.arange(len(df_slice["strategy_with_cost"])), df_slice["strategy_with_cost"].values, 1)[0]

    df_metrics.loc[len(df_metrics)] = [mean_window, std_window, semi_std_window, max_drawdown_window,
                                       mean_trades, std_trades, semi_std_trades, num_trades,
                                       cagr_returns, slope_returns, f"{counter:03d}", backtest_id, ticker,
                                       strategy_type, optimize_method, end_date,
                                       model_type, timeframe, table_key, selection, num_features]

def create_df_metrics(df_backtest, backtest_id, ticker, strategy_type, optimize_method,
                      model_type, timeframe, table_key, selection, num_features, is_expanding):
    df_backtest = df_backtest.reset_index()
    df_backtest["TIMESTAMP"] = pd.to_datetime(df_backtest["TIMESTAMP"])
    df_backtest = df_backtest.sort_values("TIMESTAMP")

    if is_expanding:
        start_date = pd.to_datetime("2021-11-01")
    else:
        start_date = df_backtest["TIMESTAMP"].min()

    end_date_abs = df_backtest["TIMESTAMP"].max()

    df_metrics = initialize_strategy_metrics_dataframe()

    counter = 0

    while (start_date + pd.DateOffset(days=180)) < end_date_abs:

        end_date_partial = start_date + pd.DateOffset(days=180)
        df_slice = df_backtest[(df_backtest["TIMESTAMP"] >= start_date) & (df_backtest["TIMESTAMP"] < end_date_partial)]

        populate_line_df_metrics(df_slice, df_metrics, backtest_id, counter, ticker, strategy_type, optimize_method, end_date_partial,
                                 model_type, timeframe, table_key, selection, num_features)

        start_date = start_date + pd.DateOffset(days=30)
        counter += 1

    start_date = end_date_abs - pd.DateOffset(days=180)
    df_slice = df_backtest[(df_backtest["TIMESTAMP"] >= start_date) & (df_backtest["TIMESTAMP"] < end_date_abs)]

    populate_line_df_metrics(df_slice, df_metrics, backtest_id, counter, ticker, strategy_type, optimize_method, end_date_abs,
                             model_type, timeframe, table_key, selection, num_features)

    return df_metrics

def process_backtest(**kwargs):
    backtest_id = kwargs['backtest_id']
    ticker = kwargs['ticker']
    optimize_method = kwargs['optimize_method']
    strategy_type = kwargs['strategy_type']
    config = kwargs['config']
    df_backtest = kwargs['df_backtest']
    is_multiclass = kwargs['is_multiclass']
    risk = kwargs['risk']
    cutoff_min = kwargs['cutoff_min']
    cutoff_max = kwargs['cutoff_max']
    model_type = kwargs['model_type']
    df_funding_filtered = kwargs['df_funding_filtered']
    storage_account_name = kwargs['storage_account_name']
    timeframe = kwargs['timeframe']
    table_key = kwargs['table_key']
    selection = kwargs['selection']
    num_features = kwargs['num_features']
    is_expanding = kwargs['is_expanding']

    logger.info(f'ticker: {ticker} --- optimize_method-{optimize_method}---strategy_type-{strategy_type}')

    config['info']['optimize_method'] = optimize_method
    config['info']['strategy_type'] = strategy_type

    df_backtest = generate_signal(df_backtest,
                                  is_multiclass,
                                  risk,
                                  cutoff_min,
                                  cutoff_max,
                                  optimize_method,
                                  model_type)

    df_backtest = df_backtest.dropna()
    df_backtest_shifted = df_backtest.copy()
    df_backtest_shifted['SIGNAL'] = df_backtest_shifted['SIGNAL'].shift(1)
    df_backtest_shifted = df_backtest_shifted.dropna()

    # Get backtest information from configuration file
    logger.info(f"backtest_id: {backtest_id}")
    bkt_obj = Backtest(backtest_id,
                       df_backtest_shifted,
                       config,
                       df_funding_filtered,
                       storage_account_name,
                       is_save=True)

    df_metrics = create_df_metrics(bkt_obj.result_df_test_strategy, backtest_id, ticker, strategy_type, optimize_method,
                                   model_type, timeframe, table_key, selection, num_features, is_expanding)

    # # save backtest metrics
    # delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/strategy_metrics"
    # #sdf_metrics = spark.createDataFrame(df_metrics)
    # #sdf_metrics.write.mode("append").format("delta").option("mergeSchema", "true").save(delta_table_path)

    # buffer = BytesIO()

    # connection_dict = {
    #         "storage_account_name": storage_account_name,
    #         "container_name": 'gold',
    #         "storage_account_key": storage_account_key,
    #     }

    # connection_dict["connect_str"] = (
    #         f"DefaultEndpointsProtocol=https;AccountName={connection_dict['storage_account_name']};AccountKey={connection_dict['storage_account_key']};EndpointSuffix=core.windows.net"
    #     )

    # connection_dict["relative_path"] = (
    #     f"wasbs://{connection_dict['container_name']}@{connection_dict['storage_account_name']}.blob.core.windows.net"
    # )

    # # Create the BlobServiceClient object which will be used to create a container client
    # blob_service_client = BlobServiceClient.from_connection_string(connection_dict["connect_str"])

    # blob_full_path = "strategy_metrics_test.parquet"

    # blob_client = blob_service_client.get_blob_client(container=connection_dict["container_name"],
    #                                                   blob=blob_full_path)

    # df_metrics.to_parquet(buffer, index=False)
    # buffer.seek(0)
    # blob_client.upload_blob(buffer, blob_type="BlockBlob", overwrite=True)

    # Explicitly clear large objects
    del bkt_obj, df_backtest, df_backtest_shifted
    gc.collect()

    return df_metrics, config


def main():
    logger.info("-----MULTICRYPTO-----")

    # Define sparkthe variables
    app_name = "RunTrainMultiCryptos"
    total_cpus = os.cpu_count()

    # Azure Blob Storage account information
    storage_account_name = "dlcypherus"
    container_name = "silver"
    storage_account_key = "Eubzuzb612QyIQN9lS9FA17b2LpiJQ9+RQtJJhV0LJcLRlurgd+iEbvfQ6qNUJYPToTE5uXAc+CH+AStPSZiwA=="

    # Create the Spark session with custom memory parameters
    spark = create_spark_session(app_name,
                                total_cpus,
                                storage_account_name,
                                storage_account_key,
                                executor_memory="8G",
                                driver_memory="64G",
                                max_result_size="32g")

    # Start blob delta lake handler
    dl_handler = DeltaLakeHandler(spark)

    # uncoment if run on gpu
    # os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

    # Check if the directory already exists
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Define setup train
    param_options = {
        'ticker': ['BTCUSDT', 'NEARUSDT', 'SOLUSDT', 'FTMUSDT','EOSUSDT',
                   'ETCUSDT', 'TRXUSDT', 'XLMUSDT', 'UNIUSDT', 'DOGEUSDT',
                   'FILUSDT', 'LINKUSDT', 'DOTUSDT', 'LTCUSDT', 'XMRUSDT',
                   'BNBUSDT', 'ETHUSDT', 'XRPUSDT', 'ADAUSDT', 'AVAXUSDT',
                   'BCHUSDT', 'RUNEUSDT', 'DASHUSDT'],
        'framework': ['lgbm'],  # Only tested for lgbm until now
        'model_type': ['clf'],  # clf or reg
        'selection': ['LGBM_FEAT_IMPORTANCE'],  # Check dataset VARIANCE_CORRELATION_RANK, NONE_METHOD
        'timeframe': ['1h'], # NOTE: Only works for one timeframe at once
        'table_key': ['76CNorJ6Mno4wpjR'],
    }

    strategy_types = ["long_and_short", "long_or_short"]

    # keys (A) x values (B)
    combinations = list(product(*param_options.values()))
    df_combinations = pd.DataFrame(combinations, columns=param_options.keys())

    visited_table_keys = []

    logger.info("Loading table_meatadata_features...")
    sdf_metadata_features = dl_handler.read_table_with_spark(spark,
                                                             container_name,
                                                             storage_account_name,
                                                             table_name='metadata_features')



    ts_df_fund = time.time()
    logger.info("Processing df_funding ...")
    df_funding = read_funding_cost(spark,
                                   container_name,
                                   storage_account_name)
    logger.info(f"The df_funding computation spent: {time.time()-ts_df_fund}s")

    try:
        for idx_com, row in df_combinations.iterrows():
            framework = row['framework']
            model_type = row['model_type']

            config_name = f"{framework}_{model_type}.yml"
            config_path = f'/home/azureuser/machine-learning/cypher_ml/supervised/models/config_templates/{config_name}'

            base_config = load_config_template(config_path)

            ts = time.time()

            df_metrics_all = initialize_strategy_metrics_dataframe()

            config = update_configuration(base_config, row)

            # Get basic configuration information
            ticker = config['backtest']['ticker']
            position_size = config['backtest']['position_size']
            table_key = config['info']['table_key']
            is_tune = config['info']['is_tune']
            model_name = config['info']['model_name']
            output_dir = config['info']['output_dir']
            is_multiclass = config['info']['is_multiclass']
            risk = config['info']['risk']
            pct_change_th = config['info']['pct_change_th']
            trust_factor = config['info']['trust_factor']
            output_name = config['info']['output_name']
            is_unbalanced = config['info']['is_unbalanced']
            is_cross_validation = config['info']['is_cross_validation']
            is_block_cv = config['info']['is_block_cv']
            n_splits = config['info']['n_splits']
            tune_loss_function = config['tune']['tune_loss_function']
            is_multi_crypto_df = config['info']['is_multi_crypto_df']
            is_one_crypto_feats = config['info']['is_one_crypto_feats']
            is_checkpoint = config.get('checkpoint', None)
            timeframe = config['backtest']['timeframe']

            table_name = "metadata_preprocess_new"
            delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"
            df_met_pre_new = spark.read.format("delta").load(delta_table_path).toPandas()
            is_expanding = df_met_pre_new[(df_met_pre_new["KEY"] == table_key)]['WINDOW_INFO'].iloc[0]['is_expanding']

            print(f"is_expanding: {is_expanding}")
            if validate_timeframe(timeframe):
                indicator_table_name = f"full_indicators_{timeframe}"
                logger.info(f"Running table {indicator_table_name}")
                logger.info(f"The {idx_com+1}-th combination setup: {set(row)}")
            else:
                raise ValueError("Timeframe not valid!!!")

            # Get dataframe columns configuration
            SELECTION = config['info']['selection']
            TIMESTAMP = DataColums.TIMESTAMP
            START_TRAIN_DATE = DataColums.START_TRAIN_DATE
            END_TEST_DATE = DataColums.END_TEST_DATE
            END_TRAIN_DATE = DataColums.END_TRAIN_DATE
            TARGET = DataColums.TARGET
            DF_ = DataColums.DF_
            TIMEFRAME = DataColums.TIMEFRAME
            TICKER = DataColums.TICKER
            CLOSE = DataColums.CLOSE
            KEY = DataColums.KEY
            PROBLEM_TYPE = DataColums.PROBLEM_TYPE
            INGESTION_TIMESTAMP = DataColums.INGESTION_TIMESTAMP
            SCALE_INFO = DataColums.SCALE_INFO

            # Initialize backtest data
            df_backtest = init_backtest()

            # Trainer and tuning
            if is_tune:
                tuner = Tuner(config)
            else:
                tuner = None

            probability = []
            list_of_kelly = []
            historical_metrics_all_dfs = pd.DataFrame()

            optim_methods, strategy_cutoff_min, strategy_cutoff_max = create_optim_methods_list(config, strategy_types)

            close_column = f'CLOSE-{ticker}'

            # Create unique ids
            run_name_id = generate_alpha_numeric_key()

            # Filter dataframe metadata info
            logger.info(f"Filtering meatadata_features by ticker:{ticker}, key:{table_key}, timeframe:{timeframe}, problem_type:{model_type}")
            criterion = (sdf_metadata_features[TICKER] == ticker) & \
                        (sdf_metadata_features[KEY] == table_key) & \
                        (sdf_metadata_features[TIMEFRAME] == timeframe) & \
                        (sdf_metadata_features[PROBLEM_TYPE] == model_type)

            sdf_meta_fea_fil = sdf_metadata_features.filter(criterion)

            if sdf_meta_fea_fil.isEmpty():
                logger.error("Metadata features returned empty after filtering. A common cause of" +
                               "this can be when bad combinations are generated. Moving to next combination... \n")
                continue

            logger.info("Converting/Sorting meatadata_features to pandas ...")
            pdf_meta_fea_fil_ord = sdf_meta_fea_fil.toPandas().sort_values(by=INGESTION_TIMESTAMP, ascending=True)
            # NOTE: Preprocessing is bugged, this is to removed duplicated data.
            pdf_meta_fea_fil_ord = pdf_meta_fea_fil_ord[(pdf_meta_fea_fil_ord['INGESTION_TIMESTAMP']>'2024-12-01')].sort_values('DATAFRAME')

            # table_metadata_features_filtered = table_metadata_features.filter_by(ticker, timeframe, framework, model_type, feature_key)
            if table_key not in visited_table_keys:
                logger.info("Reading indicator table...")
                df_indicators = dl_handler.read_table_with_spark(spark,
                                                                container_name,
                                                                storage_account_name,
                                                                table_name=indicator_table_name,
                                                                folder_name='indicators_full')

                logger.info("Converting indicator table to pandas...")
                df_indicators = df_indicators.toPandas().sort_values(by=TIMESTAMP, ascending=True)

                df_indicators[TIMESTAMP] = pd.to_datetime(df_indicators[TIMESTAMP])
            else:
                logger.info(f"Indicator table already exist for this key {table_key}...")

            if idx_com == 0:
                # Get ticker close columns
                close_columns = [col for col in df_indicators.columns if 'CLOSE-' in col]

                # Filter row with close greater than zero
                df_indicators_close = df_indicators[df_indicators[close_columns].gt(0).all(axis=1)]

                # Get first timestamp
                first_timestamp = df_indicators_close.iloc[0]['TIMESTAMP'].strftime('%Y-%m-%d %H:%M:%S')

                # Find initial dataframe
                result_df = sdf_meta_fea_fil.filter((col('START_TRAIN_DATE') <= first_timestamp)).select('DATAFRAME')

                # Start checkpoint from broken dataframe
                checkpoint_path = output_dir + output_name
                if os.path.exists(checkpoint_path):
                    df_start_idx = int(output_name.split('.')[0].split('_')[2])
                else:
                    df_start_idx = result_df.count() + 1

            df_funding_filtered = filter_funding_cost(config, df_funding)

            logger.info("Processing dataframes ...")

            df_end_idx = len(pdf_meta_fea_fil_ord) - 1

            for i in range(df_start_idx, df_end_idx):
                df_id = DF_ + f"{i:03d}"

                logger.info(f'-------------------------DATAFRAME = {df_id}-------total = {df_end_idx}----------------------------------------')

                logger.info("Filtering indicators by features metadata ...")
                # Filtering indicators by dataframe
                start_train_date = pdf_meta_fea_fil_ord.iloc[i][START_TRAIN_DATE]
                end_train_date = pdf_meta_fea_fil_ord.iloc[i][END_TRAIN_DATE]
                end_test_date = pdf_meta_fea_fil_ord.iloc[i][END_TEST_DATE]
                features = pdf_meta_fea_fil_ord.iloc[i][SELECTION]
                scaler_info = ast.literal_eval(pdf_meta_fea_fil_ord.iloc[i][SCALE_INFO])

                df_ind = df_indicators[
                    (df_indicators[TIMESTAMP] >= start_train_date) &
                    (df_indicators[TIMESTAMP] < end_test_date) &
                    (df_indicators[TIMEFRAME] == timeframe)].copy()

                # Add ticker
                df_ind[TICKER] = ticker

                if is_multi_crypto_df:
                    df_ind[CLOSE] = df_ind[close_column]

                if model_type == 'reg':
                    df_ind[TARGET] = (df_ind[CLOSE].shift(-1)/df_ind[CLOSE])-1
                else:
                    df_ind[TARGET] = np.where(df_ind[CLOSE].shift(-1) > df_ind[CLOSE], 1, 0)

                ticker_close_0 = df_ind[CLOSE].iloc[0]

                if ticker_close_0 > 0:
                    if is_multiclass:
                        df_ind['PERCENT_CHANGE'] = df_ind.CLOSE.pct_change().shift(-1)

                        # Apply classification to each row
                        df_ind[TARGET] = df_ind['PERCENT_CHANGE'].apply(classify_pct_change,
                                                                        args=(pct_change_th,
                                                                              trust_factor,
                                                                              risk))
                    logger.info(f'Creating train and test dataset')
                    X_train, X_test, y_train, y_test = windowing(df_ind,
                                                                 features,
                                                                 end_train_date,
                                                                 end_test_date,
                                                                 TIMESTAMP,
                                                                 TARGET)

                    logger.info(f'Scaling datasets.')
                    X_train, X_test, _ = scaling(scaler_info, X_train, X_test)

                    # Use only crypto features
                    if is_one_crypto_feats:
                        cols = [col for col in df_ind.columns if ticker in col]
                        X_train = X_train[[cols]]
                        X_test = X_test[[cols]]

                    if model_type == 'clf':
                        if framework == 'lgbm' or framework == 'torch':
                            class_weight = calculate_class_weight(y_train)
                            config['params']['class_weight'] = class_weight

                    if framework == 'torch':
                        if CLOSE in X_train:
                            X_train[CLOSE] = 0.0
                            X_test[CLOSE] = 0.0

                        config['params']['input_size'] = len(X_train.columns)

                        if is_multiclass:
                            # Convert integer class labels into one-hot vectors for torch models
                            onehot_encoder = OneHotEncoder(sparse_output=False)  # Avoid sparse data structure
                            y_train = onehot_encoder.fit_transform(y_train.values.reshape(-1, 1))
                            y_test = onehot_encoder.fit_transform(y_test.values.reshape(-1, 1))

                    if not os.path.exists(checkpoint_path):
                        run_name = f"{model_name}_{df_id}_{run_name_id}"
                    else:
                        run_name = output_name.split('.')[0]
                        run_name_id = run_name.split('_')[-1]

                    config['info']['output_name'] = run_name

                    date_time = current_time().replace(" ", "-")
                    log_name = f"./{log_dir}/{date_time}_{run_name}"
                    config['info']['log_name'] = log_name

                    if tuner:
                        tuner.run_name = run_name
                        best_parameter = tuner.fit(X_train, y_train)
                        logger.info(f"Best Parameters: {best_parameter}")
                        config['params'].update(best_parameter)

                        # Check if data type is supported by json
                        for k, v in config['params'].items():
                            # If not, cast to int32
                            if isinstance(v, np.int64):
                                config['params'][k] = int(v)

                    with mlflow.start_run(run_name=run_name):
                        # turn off tuning flag to save best model
                        if is_tune:
                            config['info']['is_tune'] = False

                        # Train model
                        trainer = Trainer(config)
                        trainer.fit(X_train, y_train)
                        historical_metrics_all_dfs = pd.concat([historical_metrics_all_dfs,
                                                                trainer.strategy.historical_metrics_df],
                                                                ignore_index=True)

                        if framework in ["lgbm", "xgboost"]:
                            trainer = Trainer(config)
                            trainer.fit_final_model(X_train, y_train)

                        mlflow.end_run()

                        # reset flag to original value
                        config['info']['is_tune'] = is_tune

                        # Configure the global logger to save logs to a file
                        logger.debug(config)

                    # Load best model
                    best_model_path = output_dir + run_name
                    if os.path.exists(best_model_path):
                        trainer.load(best_model_path)

                    # Compute the signal for backtest
                    signal = trainer.predict(X_test)

                    if position_size == 'kelly_critery':
                        train_signal = trainer.predict(X_train).tolist()
                        kelly = df_kelly(df_ind, df_id, train_signal)
                        list_of_kelly.extend([kelly] * X_test.shape[0])

                    if model_type == 'clf':
                        if framework == 'torch':
                            probability.extend(trainer.predict_proba(X_test).tolist())
                        else:
                            probability.extend(trainer.predict_proba(X_test)[:, 1].tolist())
                    # TODO: Remove is duplicated
                    df_timestamp = get_timestamp_data(df_ind, end_train_date, TIMESTAMP)
                    df_signal = create_backtest_signal(df_timestamp, signal)

                    # Align columns of df_signal with df_backtest
                    df_signal = df_signal.reindex(columns=df_backtest.columns, fill_value=0)

                    # Create backtest outputs for each window data from best models
                    df_backtest = pd.concat([df_backtest, df_signal])

                    # Create the checkpoint path based on dfs of windowing
                    if is_checkpoint:
                        output_name = f'{model_name}_{i+1}_{run_name_id}' + '.ckp'
                    else:
                        if framework == 'torch':
                            output_name = f'{model_name}_{i+1}_{run_name_id}' + '.pt'
                        else:
                            output_name = f'{model_name}_{i+1}_{run_name_id}' + '.pkl'

                    checkpoint_path = output_dir + output_name

                    # Retrieve cutoff values for the specific strategy
                    start_time = time.time()
                    strategy_cutoff_min, strategy_cutoff_max = reg_class_optimize_method_concurrent(optim_methods,
                                                                                                    strategy_cutoff_min,
                                                                                                    strategy_cutoff_max,
                                                                                                    strategy_types,
                                                                                                    config,
                                                                                                    df_ind,
                                                                                                    X_train,
                                                                                                    trainer,
                                                                                                    framework,
                                                                                                    df_funding_filtered,
                                                                                                    model_type,
                                                                                                    X_test)
                    # Calculate the total time spent
                    time_spent = time.time() - start_time
                    logger.info(f"Time spent optimize cuttoff: {time_spent} seconds")

            num_features = X_train.shape[1]

            if model_type == 'clf':
                df_backtest['PROBABILITY'] = probability
                df_backtest['PREDICT'] = 0
            else:
                df_backtest['PREDICT'] = df_backtest['SIGNAL']
                df_backtest['PROBABILITY'] = 0
                df_backtest['PROBABILITY_MIN'] = 0
                df_backtest['PROBABILITY_MAX'] = 0

            if position_size == 'kelly_critery':
                df_backtest['KELLY'] = list_of_kelly[0:df_backtest.shape[0]]

            # Prepare the list of parameters for each job
            params_list = []
            for optimize_method in optim_methods:
                for strategy_type in strategy_types:
                    backtest_id = generate_alpha_numeric_key()
                    params = {
                        'date_time': date_time,
                        'ticker': ticker,
                        'df_start_idx': df_start_idx,
                        'df_end_idx': df_end_idx,
                        'timeframe': timeframe,
                        'position_size': position_size,
                        'cutoff_min': strategy_cutoff_min[strategy_type],
                        'cutoff_max': strategy_cutoff_max[strategy_type],
                        'framework': framework,
                        'model_name': model_name,
                        'model_type': model_type,
                        'is_tune': is_tune,
                        'selection': SELECTION,
                        'optimize_method': optimize_method,
                        'strategy_type': strategy_type,
                        'is_unbalanced': is_unbalanced,
                        'is_cross_validation': is_cross_validation,
                        'is_block_cv': is_block_cv,
                        'n_splits': n_splits,
                        'table_key': table_key,
                        'is_multiclass': is_multiclass,
                        'pct_change_th': pct_change_th,
                        'trust_factor': trust_factor,
                        'risk': risk,
                        'tune_loss_function': tune_loss_function,
                        'backtest_id': backtest_id,
                        'is_multi_crypto_df': is_multi_crypto_df,
                        'is_one_crypto_feats': is_one_crypto_feats,
                        'selected_features': features,
                        'config': config.copy(),
                        'df_backtest': df_backtest.copy(),
                        'df_funding_filtered': df_funding_filtered,
                        'storage_account_name': storage_account_name,
                        'logger': logger,
                        'scaler_type': scaler_info.get('method', None),
                        'num_features': num_features,
                        'is_expanding': is_expanding,
                    }
                    params_list.append(params)
            # Execute all jobs in parallel
            metadata_list = []
            try:
                with ProcessPoolExecutor(max_workers=total_cpus) as executor:
                    metadata_list: List[Tuple[str, str, dict]] = []
                    futures = {executor.submit(process_backtest, **params): params for params in params_list}
                    # Wait all jobs to finish
                    for future in concurrent.futures.as_completed(futures):
                        # Set metadata parameters
                        params = futures[future]
                        df_id = f"df_{params.get('df_start_idx')}" + f"_df_{params.get('df_end_idx')}"
                        backtest_id = params.get('backtest_id')
                        ticker = params.get('ticker')
                        timeframe = params.get('timeframe')
                        strategy_type = params.get('strategy_type')
                        optimize_method = params.get('optimize_method')
                        config = params.get('config')
                        try:
                            # Accumulate backtest results
                            df_metrics, config = future.result()
                            df_metrics_all = pd.concat([df_metrics_all, df_metrics], ignore_index=True)

                            # Accumulate metadata info
                            config['backtest'].update({'title': f"{current_time().replace(' ', '-')}_{ticker}_{timeframe}_{strategy_type}_{optimize_method}"})
                            metadata_list.append((current_time(), df_id, backtest_id, config))

                        except Exception as e:
                            logger.error(f"Generated an exception while running opt cutoff in parallel: {e}")

                    # save train
                    dl_handler.save_metadata_train(metadata_list, storage_account_name)

                    delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/strategy_metrics"
                    sdf_metrics = spark.createDataFrame(df_metrics_all)
                    sdf_metrics = sdf_metrics.withColumn(
                        "INGESTION_TIMESTAMP", current_timestamp()
                    )
                    sdf_metrics.write.mode("append").format("delta").option("mergeSchema", "true").save(delta_table_path)

            except Exception as e:
                logger.error(f"An error occurred with the ProcessPoolExecutor: {e}")
                traceback.print_exc()
            finally:
                executor.shutdown(wait=True)
                logger.info("Executor has been shut down.")

            logger.info(f"Time spent for {ticker}: {time.time() - ts}")

            visited_table_keys.append(table_key)

            drop_all_temp_views(spark)

            del metadata_list, df_funding_filtered, df_metrics_all, sdf_metrics
            gc.collect()
            logger.info("\n")

    except ValueError as ve:
        logger.error(f"Value error: {ve}")
        traceback.print_exc()
    except IOError as ioe:
        logger.error(f"I/O error: {ioe}")
        traceback.print_exc()
    except Exception as ge:
        logger.error(f"General error: {ge}")
        traceback.print_exc()

    logger.info("----------Multi cryptos train finished !!!----------")


if __name__ == "__main__":
    main()
