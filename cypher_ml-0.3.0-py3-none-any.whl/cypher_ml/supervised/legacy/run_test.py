import os
import traceback
import warnings
import logging

# NOTE: It seems assynchronous use of cuda can rise error for BCE loss
# but a better investigation is necessary. If use BCE change cuda to
# synchronous cuda operations.
# os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
import yaml
import mlflow
import pandas as pd
import numpy as np

from sklearn.preprocessing import OneHotEncoder
from trainer import Trainer
from tuner import Tuner
from utils import *
from constants import DataColums
from backtest import Backtest
from pyspark.sql import SparkSession

# Define a mapping of (framework, model) to file names
model_to_file_mapping = {
    ('lgbm', 'LgbmClf'): 'lgbm.yml',
    ('sklearn', 'RfClf'): 'rf.yml',
    ('torch', 'LSTMClf'): 'lstm.yml',
    ('sklearn', 'LrClf'): 'log_reg.yml',
    ('torch', 'TransformerEncoderClf'): 'transformer.yml',
    ('xgboost', 'XGBoostClf'): 'xgboost.yml'
}


def map_to_file(framework, model):
    """
    Map a given framework and model to a specific file name.

    :param framework: The name of the framework (e.g., 'sklearn')
    :param model: The name of the model (e.g., 'random forest')
    :return: The file name associated with the framework and model, or None if not found.
    """
    # Create a tuple from the framework and model
    key = (framework, model)

    # Look up the file name in the mapping
    file_name = model_to_file_mapping.get(key)

    if file_name:
        return file_name
    else:
        return None

# Define the parameters and their possible values
is_multiclass_options = [True, False]
save_criteria_options = ['all', 'best', 'none']
risk_options = ['low', 'high']  # Relevant only for multiclass
frameworks_options = {
    'sklearn': ['RfClf', 'LrClf'],
    'torch': ['TransformerEncoderClf', 'LSTMClf'],
    'lgbm': ['LgbmClf'],
    'xgboost': ['XGBoostClf']
}

# Generate combinations
combinations = []

for is_multiclass in is_multiclass_options:
    for save_criteria in save_criteria_options:
        # For binary classification (not multiclass), risk and frameworks combinations are handled differently
        if not is_multiclass:
            for framework, models in frameworks_options.items():
                for model in models:
                    combinations.append({
                        'is_multiclass': is_multiclass,
                        'save_criteria': save_criteria,
                        'risk': 'none',  # Indicating binary classification
                        'framework': framework,
                        'model_name': model,
                        'file_name': map_to_file(framework, model)
                    })
        else:  # For multiclass, include risk in the combinations
            for risk in risk_options:
                for framework, models in frameworks_options.items():
                    for model in models:
                        combinations.append({
                            'is_multiclass': is_multiclass,
                            'save_criteria': save_criteria,
                            'risk': risk,
                            'framework': framework,
                            'model_name': model,
                            'file_name': map_to_file(framework, model)
                        })

# Create a DataFrame
combinations_df = pd.DataFrame(combinations)

# Set parameters
configs = []
for idx, row in combinations_df.iterrows():
    file_path = f'./models/config_templates/{row.file_name}'
    with open(file_path, 'r') as file:
        config = yaml.safe_load(file)
        config['info']['is_multiclass'] = row['is_multiclass']
        config['info']['save_criteria'] = row['save_criteria']
        config['info']['risk'] = row['risk']
        config['info']['framework'] = row['framework']
        config['info']['model_name'] = row['model_name']

        # For torch
        if row['is_multiclass']:
            if row['risk'] == 'low' and row['framework'] == 'torch':
                config['params']['num_classes'] = 3
                config['params']['loss_name'] = 'cross_entropy'
            if row['risk'] == 'high' and row['framework'] == 'torch':
                config['params']['num_classes'] = 5
                config['params']['loss_name'] = 'cross_entropy'
        else:
            if row['risk'] == 'none' and row['framework'] == 'torch':
                config['params']['num_classes'] = 1
                config['params']['loss_name'] = 'bce_logits'

    configs.append(config)

# Flag for debug purpose
is_debug = False

if is_debug:
    # Access MLflow's logger
    mlflow_logger = logging.getLogger("mlflow")

    # Set the logging level to DEBUG
    mlflow_logger.setLevel(logging.DEBUG)
else:
    warnings.filterwarnings("ignore")
    # Set up Spark configuration
spark = SparkSession.builder.getOrCreate()

errors = []
for config in configs:
    # Get basic configuration information
    is_tune = config['info']['is_tune']
    model_name = config['info']['model_name']
    output_dir = config['info']['output_dir']
    signal_type = config['info']['signal_type']
    n_quantiles = config['info']['n_quantiles']
    strategy_type = config['info']['strategy_type']
    min_cutoff = config['info']['min_cutoff']
    max_cutoff = config['info']['max_cutoff']
    framework = config['info']['framework']
    table_key = config['info']['table_key']
    is_multiclass = config['info']['is_multiclass']
    risk = config['info']['risk']
    pct_change_th = config['info']['pct_change_th']
    trust_factor = config['info']['trust_factor']

    # Get backtest information
    position_size = config['backtest']['position_size']

    # Get dataframe columns configuration
    selection = config['info']['selection']
    dataframe = DataColums.DATAFRAME
    timestamp = DataColums.TIMESTAMP
    end_train_date = DataColums.END_TRAIN_DATE
    target = DataColums.TARGET
    df_ = DataColums.DF_

    # Acess metadata
    df_metadata = spark.sql("SELECT * FROM silver.dfs_metadata").toPandas()
    table_name = df_metadata[df_metadata["KEY"] == table_key]["TABLE_NAME"].iloc[0]
    ticker = df_metadata[df_metadata["KEY"] == table_key]["TICKER"].iloc[0]

    # Initialize backtest data
    df_backtest = init_backtest()

    # Trainer and tuning
    if is_tune:
        tuner = Tuner(config)
    else:
        tuner = None

    probability = []
    list_of_kelly=[]

    # Get the number of dataframes from dataset
    n_dfs = spark.sql(f"select DISTINCT DATAFRAME from {table_name}").toPandas().shape[0]

    # Load DF table
    df_all = load_spark_dataframe(spark, table_name)
    df_all["TICKER"] = ticker

    if is_multiclass:
        df_all['PERCENT_CHANGE'] = df_all.CLOSE.pct_change().shift(-1)

        # Apply classification to each row
        df_all['TARGET'] = df_all['PERCENT_CHANGE'].apply(classify_pct_change, args=(pct_change_th, trust_factor, risk))

    try:
        # Iterate over windows of data
        for i in range(1):
            df_id = df_ + str(i)

            # Data handling
            print(f'-------------------------DATAFRAME = {df_id}-------total = {n_dfs}----------------------------------------')

            df_spk = df_all[df_all['DATAFRAME'] == df_id]

            X_train, X_test, y_train, y_test = windowing(df_spk,
                                                        df_id,
                                                        dataframe,
                                                        selection,
                                                        timestamp,
                                                        end_train_date,
                                                        target,
                                                        imbalance=False)

            if framework == 'torch':
                config['params']['input_size'] = len(X_train.columns)

                if is_multiclass and framework == 'torch':
                    # Convert integer class labels into one-hot vectors for torch models
                    onehot_encoder = OneHotEncoder(sparse_output=False)  # Avoid sparse data structure
                    y_train = onehot_encoder.fit_transform(y_train.values.reshape(-1, 1))
                    y_test = onehot_encoder.fit_transform(y_test.values.reshape(-1, 1))

            df_timestamp = get_timestamp_data(df_spk,
                                            df_id,
                                            dataframe,
                                            timestamp,
                                            end_train_date)

            run_name = model_name + df_id
            config['info']['output_name'] = run_name

            if tuner:
                tuner.run_name = run_name
                best_parameter = tuner.fit(X_train, y_train)
                print(f"Best Parameters: {best_parameter}")
                config['params'].update(best_parameter)

                # Check if data type is supported by json
                for k, v in config['params'].items():
                    # If not, cast to int32
                    if isinstance(v, np.int64):
                        config['params'][k] = int(v)

            with mlflow.start_run(run_name=run_name) as run:
                # Save model metadata
                model_id = run.info.run_id
                backtest_id = generate_alpha_numeric_key()
                save_metadata_model(spark, model_id, backtest_id, config)

                # turn off tuning flag to save best model
                if is_tune:
                    config['info']['is_tune'] = False

                # Train model
                trainer = Trainer(config)
                trainer.fit(X_train, y_train)
                mlflow.end_run()

                # reset flag to original value
                config['info']['is_tune'] = is_tune

            # Load best model
            best_model_path = output_dir + run_name
            if os.path.exists(best_model_path):
                trainer.load(best_model_path)

            # Compute the signal
            signal = trainer.predict(X_test)

            if position_size == 'kelly_critery':
                # Calculate Kelly Critery
                train_signal = trainer.predict(X_train).tolist()
                kelly = df_kelly(df_spk, df_id, train_signal)

                list_of_kelly.extend([kelly] * X_test.shape[0])

            # Compute the predict_proba
            if signal_type != 'default':
                if framework == 'torch':
                    proba = trainer.predict_proba(X_test)
                    probability.extend(trainer.predict_proba(X_test).tolist())
                else:
                    probability.extend(trainer.predict_proba(X_test)[:, 1].tolist())

            df_signal = create_backtest_signal(df_timestamp, signal)

            # Align columns of df_signal with df_backtest
            df_signal = df_signal.reindex(columns=df_backtest.columns, fill_value=0)

            # Create backtest outputs for each window data from best models
            df_backtest = pd.concat([df_backtest, df_signal])

        # Change zeros to minus one
        if signal_type == 'default':
            df_backtest[DataColums.SIGNAL] = format_backtest_signal(df_backtest, is_multiclass, risk)
        else:
            df_backtest['PROBABILITY'] = probability
            df_backtest['PROBABILITY'] = df_backtest['PROBABILITY'].shift(1)

        if signal_type == 'quantile':
            df_backtest = prob_proba_quantile_signal(df_backtest, n_quantiles)

        if signal_type == 'prob_cutoff':
            df_backtest = prob_proba_cutoff_signal(df_backtest, min_cutoff, max_cutoff)

        if position_size == 'kelly_critery':
            df_backtest['KELLY'] = list_of_kelly[0:df_backtest.shape[0]]

        # Shift data by one given that features represents (t) and the prediction (t+1)
        df_backtest_shifted = df_backtest.copy()
        df_backtest_shifted[DataColums.SIGNAL] = df_backtest_shifted[DataColums.SIGNAL].shift(1)
        df_backtest_shifted = df_backtest_shifted.dropna()

        # Get backtest information from configuration file
        bkt_obj = Backtest(spark,
                        backtest_id=backtest_id,
                        signal=df_backtest_shifted,
                        config=config)
    except Exception as ge:
        print(f"General error: {ge}")
        traceback.print_exc()
        errors.append(config)
