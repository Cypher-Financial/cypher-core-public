The scripts from this folder can be useful but are not update to current main or dev branchs.
