# %%
import traceback
import pandas as pd

from sklearn.preprocessing import OneHotEncoder
from trainer import Trainer
from utils import *
from constants import DataColums
from backtest import Backtest
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

# Set up Spark configuration
spark = SparkSession.builder.getOrCreate()

# Set table key
table_key = ''
model_name = ''
run_name_id = ''
output_dir = ''

# Acess metadata
df_metadata = spark.sql("SELECT * FROM silver.dfs_metadata").toPandas()
table_name = df_metadata[df_metadata["KEY"] == table_key]["TABLE_NAME"].iloc[0]
ticker = df_metadata[df_metadata["KEY"] == table_key]["TICKER"].iloc[0]

# Initialize backtest data
df_backtest = init_backtest()

# Get the number of dataframes from dataset
n_dfs = spark.sql(f"select DISTINCT DATAFRAME from {table_name}").toPandas().shape[0]

# Load DF table
df_all = load_spark_dataframe(spark, table_name)
df_all = df_all.withColumn("TICKER", F.lit( ticker))

backtest_id = generate_alpha_numeric_key()

probability = []
list_of_kelly=[]

dataframe = DataColums.DATAFRAME
timestamp = DataColums.TIMESTAMP
end_train_date = DataColums.END_TRAIN_DATE
target = DataColums.TARGET
df_ = DataColums.DF_

try:
    # Iterate over windows of data
    for i in range(n_dfs-1):
        df_id = df_ + str(i)
        # Set the best df model path
        output_name = f'{model_name}_{df_id}_{run_name_id}'
        best_model_path = output_dir + output_name
        best_config_path = output_dir + output_name + '_all_parameters.json'

        # Open best json file and load its content
        with open(best_config_path, 'r') as file:
            config = json.load(file)

        # Get basic configuration information
        model_name = config['info']['model_name']
        signal_type = config['info']['signal_type']
        n_quantiles = config['info']['n_quantiles']
        strategy_type = config['info']['strategy_type']
        min_cutoff = config['info']['min_cutoff']
        max_cutoff = config['info']['max_cutoff']
        framework = config['info']['framework']
        table_key = config['info']['table_key']
        is_multiclass = config['info']['is_multiclass']
        risk = config['info']['risk']
        pct_change_th = config['info']['pct_change_th']
        trust_factor = config['info']['trust_factor']
        selection = config['info']['selection']
        position_size = config['backtest']['position_size']

        # Data handling
        print(f'-------------------------DATAFRAME = {df_id}-------total = {n_dfs}----------------------------------------')

        df_spk = df_all.filter(F.col('DATAFRAME') == df_id)
        df_spk = df_spk.toPandas().sort_values('TIMESTAMP')

        if is_multiclass:
            df_spk['PERCENT_CHANGE'] = df_spk.CLOSE.pct_change().shift(-1)

            # Apply classification to each row
            df_spk['TARGET'] = df_spk['PERCENT_CHANGE'].apply(classify_pct_change, args=(pct_change_th, trust_factor, risk))

        X_train, X_test, y_train, y_test = windowing(df_spk,
                                                     df_id,
                                                     dataframe,
                                                     selection,
                                                     timestamp,
                                                     end_train_date,
                                                     target,
                                                     imbalance=False)

        if framework == 'torch':
            config['params']['input_size'] = len(X_train.columns)
            X_train['CLOSE'] = 0.0
            X_test['CLOSE'] = 0.0

            if is_multiclass:
                # Convert integer class labels into one-hot vectors for torch models
                onehot_encoder = OneHotEncoder(sparse_output=False)  # Avoid sparse data structure
                y_train = onehot_encoder.fit_transform(y_train.values.reshape(-1, 1))
                y_test = onehot_encoder.fit_transform(y_test.values.reshape(-1, 1))

        df_timestamp = get_timestamp_data(df_spk,
                                          df_id,
                                          dataframe,
                                          timestamp,
                                          end_train_date)

        # Start and load best trainer
        trainer = Trainer(config)
        trainer.load(best_model_path)

        # Compute the signal
        signal = trainer.predict(X_test)

        if position_size == 'kelly_critery':
            # Calculate Kelly Critery
            train_signal = trainer.predict(X_train).tolist()
            kelly = df_kelly(df_spk, df_id, train_signal)

            list_of_kelly.extend([kelly] * X_test.shape[0])

        # Compute the predict_proba
        if framework == 'torch':
            probability.extend(trainer.predict_proba(X_test).tolist())
        else:
            probability.extend(trainer.predict_proba(X_test)[:, 1].tolist())

        df_signal = create_backtest_signal(df_timestamp, signal)

        # Align columns of df_signal with df_backtest
        df_signal = df_signal.reindex(columns=df_backtest.columns, fill_value=0)

        # Create backtest outputs for each window data from best models
        df_backtest = pd.concat([df_backtest, df_signal])

    # Change zeros to minus one
    if signal_type == 'default':
        df_backtest[DataColums.SIGNAL] = format_backtest_signal(df_backtest, is_multiclass, risk)

    # Create column even if not used to avoid missing columns while saving backtest
    df_backtest['PROBABILITY'] = probability

    if signal_type == 'quantile':
        df_backtest = prob_proba_quantile_signal(df_backtest, n_quantiles)

    if signal_type == 'prob_cutoff':
        df_backtest = prob_proba_cutoff_signal(df_backtest, min_cutoff, max_cutoff)

    if position_size == 'kelly_critery':
        df_backtest['KELLY'] = list_of_kelly[0:df_backtest.shape[0]]

    # Shift data by one given that features represents (t) and the prediction (t+1)
    df_backtest_shifted = df_backtest.copy()
    df_backtest_shifted[DataColums.SIGNAL] = df_backtest_shifted[DataColums.SIGNAL].shift(1)
    df_backtest_shifted = df_backtest_shifted.dropna()

    # Get backtest information from configuration file
    bkt_obj = Backtest(spark,
                       backtest_id=backtest_id,
                       signal=df_backtest_shifted,
                       config=config)

except ValueError as ve:
    print(f"Value error: {ve}")
    traceback.print_exc()
except IOError as ioe:
    print(f"I/O error: {ioe}")
    traceback.print_exc()
except Exception as ge:
    print(f"General error: {ge}")
    traceback.print_exc()
