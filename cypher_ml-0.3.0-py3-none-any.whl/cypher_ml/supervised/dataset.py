from torch.utils.data import Dataset
from typing import Tuple, Any
import torch

import numpy as np


class Simple(Dataset):
    """
    A simple custom dataset to pair features (X) and labels (y) for PyTorch models.
    """
    def __init__(self, X: Any, y: Any):
        """
        Initialize the dataset with features and labels.

        Args:
            X (Any): The input features (must support indexing and have a length).
            y (Any): The corresponding labels or target values (must support indexing and have a length).
        """
        self.X = X
        self.y = y

    def __len__(self) -> int:
        """
        Return the number of samples in the dataset.

        Returns:
            int: The number of samples.
        """

        return len(self.X)

    def __getitem__(self, idx: int) -> Tuple[Any, Any]:
        """
        Retrieve the feature and label at the specified index.

        Args:
            idx (int): The index of the data point to retrieve.

        Returns:
            Tuple[Any, Any]: The feature and label for the given index.
        """
        return self.X[idx], self.y[idx]


class SimplePrediction(Dataset):
    """
    A simple custom dataset to predict the features (X) for PyTorch models.
    """
    def __init__(self, X: Any):
        """
        Initialize the dataset with features and labels.

        Args:
            X (Any): The input features (must support indexing and have a length).
            y (Any): The corresponding labels or target values (must support indexing and have a length).
        """
        self.X = X

    def __len__(self) -> int:
        """
        Return the number of samples in the dataset.

        Returns:
            int: The number of samples.
        """

        return len(self.X)

    def __getitem__(self, idx: int) -> Tuple[Any, Any]:
        """
        Retrieve the feature and label at the specified index.

        Args:
            idx (int): The index of the data point to retrieve.

        Returns:
            Tuple[Any, Any]: The feature and label for the given index.
        """
        return self.X[idx]


import numpy as np
from typing import Tuple

class TimeSeries(Dataset):
    """
    A dataset class designed for time-series data, enabling sequential data processing
    for PyTorch models. It handles the creation of input sequences and their corresponding
    target values for training time-series models.
    """

    def __init__(self,
                 x_data: np.ndarray,
                 y_data: np.ndarray,
                 timestep: int) -> None:
        """
        Initialize the dataset with time-series input and output data along with
        the specified timestep for sequence creation.
        """
        self.x_sequences, self.y_sequences = self._prepare_data(x_data, y_data, timestep)

    def _prepare_data(self,
                      x_data: np.ndarray,
                      y_data: np.ndarray,
                      timestep: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepare the sequential data for the model.

        This internal method generates sequences of the specified timestep from the
        input data, along with their corresponding target values.
        """
        dataX, dataY = [], []
        # Create sequences of the specified timestep and their corresponding targets
        for i in range(len(x_data) - timestep):
            x = x_data[i:(i + timestep)]
            dataX.append(x)
            y = y_data[i + timestep]  # Target is the next value following the sequence
            dataY.append(y)

        # Ensure all data is in a consistent numpy format suitable for machine learning models
        # Convert lists to numpy arrays with shapes [(number of sequences), (timestep), ...]
        dataX = np.stack(dataX)
        dataY = np.stack(dataY)

        return dataX, dataY

    def __len__(self) -> int:
        """
        Get the total number of sequences in the dataset.
        """
        return len(self.x_sequences)

    def __getitem__(self, idx: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Retrieve a sequence and its corresponding target value by index.
        """
        x_sequence = self.x_sequences[idx]
        y_sequence = self.y_sequences[idx]

        return x_sequence, y_sequence



class TimeSeriesPrediction(Dataset):
    """
    A dataset class for time-series prediction that requires only input features (X)
    and does not require labels (y). It is suitable for forecasting scenarios.
    """
    def __init__(self, x_data: np.ndarray, timestep: int):
        """
        Initialize the dataset with time-series features.

        Args:
            x_data: The input features for the time-series data.
            timestep: The number of time steps to include in each input sample.
        """
        self.x_sequences = self._prepare_data(x_data, timestep)

    def _prepare_data(self, x_data: np.ndarray, timestep: int):
        """
        Prepare the input data for the model.

        Args:
            x_data: The input time-series data in numpy format.
            timestep: The number of time steps for each input sequence.

        Returns:
            A tensor of shape (n_samples, timestep, n_features) containing
            the input sequences for the model.
        """
        # Convert x_data to a tensor if it's a numpy array, otherwise assume it's already a tensor
        x_tensor = torch.tensor(x_data, dtype=torch.float32) if isinstance(x_data, np.ndarray) else x_data
        dataX = []
        for i in range(len(x_tensor) - timestep + 1):
            x = x_tensor[i:(i + timestep)]
            # Directly use the slice of tensor
            dataX.append(x)

        # Stack all sequence tensors to create a single tensor
        return torch.stack(dataX)


    def __len__(self):
        """
        Return the number of samples in the dataset.
        """
        return len(self.x_sequences)

    def __getitem__(self, idx: int):
        """
        Retrieve the input sequence at the specified index.

        Args:
            idx: The index of the data point to retrieve.

        Returns:
            The input sequence for the given index.
        """
        return self.x_sequences[idx]