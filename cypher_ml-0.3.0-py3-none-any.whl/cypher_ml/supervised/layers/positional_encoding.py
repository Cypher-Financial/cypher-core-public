import math

import torch
import torch.nn as nn


class FrequencyPositionalEnconding(nn.Module):
    """Frequency based positional encoding layer."""
    def __init__(self, d_model: int, dropout_p: float, max_len: int):
        """
        Initializes the FrequencyPositionalEncoding module.

        Parameters:
            d_model (int): The dimensionality of the model.
            dropout_p (float): Dropout probability.
            max_len (int): Maximum length of the input sequences.
        """

        super().__init__()

        # Initialize positional encoding matrix
        pos_enc = torch.zeros(max_len, d_model)

        # Number of positions by each row
        positions = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)

        # Create a series of values to scale the positions before applying the sine and cosine functions.
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)  # 10000^(2i/dim_model)
        )

        # Ensures that each position gets a distinct and repeatable encoding (frequency)
        pos_enc[:, 0::2] = torch.sin(positions * div_term)
        pos_enc[:, 1::2] = torch.cos(positions * div_term)

        pos_enc = pos_enc.unsqueeze(0).transpose(0, 1)  # (1, max_len, dm) -> (max_len, dm) -> (dm, max_len)

        # Access position encoder as attribute
        self.register_buffer('pe', pos_enc)

        self.dropout = nn.Dropout(dropout_p)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for the FrequencyPositionalEncoding.

        Args:
            emb (torch.Tensor): The input tensor (xdim, batch_size, d_model).

        Returns:
            torch.Tensor: The tensor with added positional encodings.
        """
        # Ensure positional encoding is compatible with the input size
        x = x + self.pe[:x.size(0), :]  # (bs, dm) + (bs, 1, dm)

        return self.dropout(x)
