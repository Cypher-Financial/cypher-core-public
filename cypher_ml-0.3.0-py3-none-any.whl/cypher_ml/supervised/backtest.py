import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pyspark.pandas as ps
import logging
import time
from io import BytesIO
from azure.storage.blob import BlobServiceClient, ContainerClient
from pyspark.sql import functions as F
from constants import DataColums

logger = logging.getLogger('logger')


class Backtest:
    """
    A class to perform backtesting of a trading strategy on historical data.

    Attributes:
        raw (pd.DataFrame): The raw historical data.
        trading_cost (float): The cost associated with each trade.
        results (pd.DataFrame): The results of the backtest, including strategy performance metrics.
    """

    def __init__(self,
                 backtest_id: str,
                 signal: pd.DataFrame,
                 config: dict,
                 df_funding: pd.DataFrame,
                 storage_account_name: str,
                 is_save: bool = False,
                 is_print: bool = True,
                 is_plot: bool = False):
        """
        Initializes the Backtest class with historical data and trading cost.

        Parameters:
            spark (SparkSession): The spark session.
            signal (pd.DataFrame): The DataFrame containing the trading signals.
            config (dict): The configuration file to get backtest information.
        """
        self.minute_table_name = config['backtest']['minute_table_name']
        self.trading_cost = config['backtest']['trading_cost']
        self.ticker = config['backtest']['ticker']
        self.timeframe = config['backtest']['timeframe']
        self.title = config['backtest']['title']
        self.author = config['backtest']['author']
        self.strategy_type = config['info']['strategy_type']
        self.position_size = config['backtest']['position_size']
        self.fixed_percentual = config['backtest']['fixed_percentual']
        self.optimize_method = config['info']['optimize_method']

        # Running the strategy test and printing the metrics
        self.df_funding = df_funding
        self.df_funding['TIMESTAMP'] = self.df_funding['TIMESTAMP'].astype('datetime64[ns]')
        self.result_df = self.convert_signal_to_minute(signal)
        self.result_df_strategy_type = self.convert_signal_to_strategy_type()
        self.result_df_test_strategy = self.test_strategy()

        if is_save:
            start_time = time.time()
            self.save_backtest(backtest_id, storage_account_name)
            time_spent = time.time() - start_time
            logger.info(f"Time spent on saving backtest with less columns: {time_spent}")

        if is_print:
            self.print_metrics()

        if is_plot:
            self.plot_results()

    def convert_signal_to_minute(self, df_backtest: pd.DataFrame) -> pd.DataFrame:
        """
        Converts trading signals to align with minute-level data.

        Args:
            df_backtest (pd.DataFrame): DataFrame containing backtest signals.

        Returns:
            pd.DataFrame: A DataFrame with signals aligned to minute-level data.
        """

        # Add 4 minutes delay to signal
        df_backtest['TIMESTAMP'] = df_backtest['TIMESTAMP'] + pd.Timedelta(minutes=4)

        # Left merge backtest dataframe with dataframe df_funding
        result_df = pd.merge(self.df_funding,
                             df_backtest,
                             on=[DataColums.TIMESTAMP, DataColums.TICKER], how='left')

        # Select data by start and end data processed
        end_date = df_backtest[DataColums.TIMESTAMP].tail(1).iloc[0]
        start_date = df_backtest[DataColums.TIMESTAMP].head(1).iloc[0]
        result_df = result_df[(result_df[DataColums.TIMESTAMP] > start_date) & (result_df[DataColums.TIMESTAMP] <= end_date)]

        return result_df

    def convert_signal_to_strategy_type(self):

        """Converts trading signals to a specified strategy type.

        This method modifies the signal data in `result_df` based on the strategy type set in `self.strategy_type`. The modifications are as follows:

        - 'long_and_short': Replaces 0s in the signal data with NaN
        - 'long_only': Alters signal data such that any -1 values (indicating short positions) are converted to 0, effectively removing short signals.
        - 'short_only': Changes signal data by converting any 1 values (indicating long positions) to 0, effectively removing long signals.
        - 'long_or_short': Makes no changes to the signal data.
        - If the strategy type is none of the above, a ValueError is raised.
        - Forward fills NaN values, and then replaces the original signal data with updated values.

        Raises:
            ValueError: If `self.strategy_type` is not one of 'long_or_short', 'long_only', 'short_only', or 'long_and_short'.

        Returns:
            pandas.DataFrame: The modified DataFrame with updated signal data according to the specified strategy type.
        """

        if self.strategy_type == 'long_and_short':
            # will hold previous value after ffil
            self.result_df[DataColums.SIGNAL] = self.result_df[DataColums.SIGNAL].replace(0, np.nan)
        elif self.strategy_type == 'long_only':
            self.result_df[DataColums.SIGNAL] = self.result_df[DataColums.SIGNAL].apply(lambda x: 0 if x == -1 else x)
        elif self.strategy_type == 'short_only':
            self.result_df[DataColums.SIGNAL] = self.result_df[DataColums.SIGNAL].apply(lambda x: 0 if x == 1 else x)
        elif self.strategy_type == 'long_or_short':
            pass
        else:
            raise ValueError("Setup a valid strategy: 'long_or_short', 'long_only', 'short_only', 'long_and_short'")

        self.result_df[DataColums.SIGNAL] = self.result_df[DataColums.SIGNAL].ffill()
        self.result_df['strategy_type'] = self.strategy_type

        return self.result_df

    def test_strategy(self) -> pd.DataFrame:
        """
        Tests the trading strategy on the historical data and calculates performance metrics.

        Returns:
            pd.DataFrame: DataFrame containing the results of the strategy test.
        """

        raw = self.result_df_strategy_type.set_index(DataColums.TIMESTAMP).sort_index()
        data = raw.copy()

        # Calculating returns
        data['RETURN'] = (data['CLOSE'] / data['CLOSE'].shift(1))-1

        # Foward fill null values
        data.fillna(method='ffill', inplace=True)
        data.dropna(inplace=True)

        # Calculating returns with position Size and funding cost
        if self.position_size == 'kelly_critery':
            data['RETURN_WITH_POSITION_SIZE'] = data['RETURN'] * data['KELLY']
            data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-(data['FUND_VALUE'] * data['KELLY']),  data['RETURN_WITH_POSITION_SIZE']+(data['FUND_VALUE'] * data['KELLY']))
        elif self.position_size == 'fixed_percentual':
            data['RETURN_WITH_POSITION_SIZE'] = data['RETURN'] * self.fixed_percentual
            data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-(data['FUND_VALUE']* self.fixed_percentual ),  data['RETURN_WITH_POSITION_SIZE']+(data['FUND_VALUE']* self.fixed_percentual ))
        else:
            data['RETURN_WITH_POSITION_SIZE'] = data['RETURN']
            data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-data['FUND_VALUE'],  data['RETURN_WITH_POSITION_SIZE']+data['FUND_VALUE'])

        # Calculating trades and strategy performance
        data["trade"] = data[DataColums.SIGNAL].diff().fillna(0).abs()
        data["strategy"] = data[DataColums.SIGNAL] * data["RETURN_WITH_POSITION_SIZE"]
        data["strategy_with_cost"] =  (data[DataColums.SIGNAL] * data["RETURN_WITH_FUNDING_COST"]) - (data["trade"] * self.trading_cost)

        # Cumulative returns calculation
        data["cummul_returns_bh"] = (data["RETURN"]+1).cumprod()
        data["cummul_returns_strat"] = (data["strategy"]+1).cumprod()
        data["cum_ret_strat_with_cost"] = (data["strategy_with_cost"]+1).cumprod()
        data["drawdown"] = (data["cum_ret_strat_with_cost"].cummax() - data["cum_ret_strat_with_cost"]) / data["cum_ret_strat_with_cost"].cummax()
        data["max_drawdown"] = data["drawdown"].cummax()

        data[DataColums.SIGNAL] = data[DataColums.SIGNAL].astype(int)
        try:
            self.ret_bnh = (data["cummul_returns_bh"].iloc[-1] - 1.0) * 100
            self.ret_strat = (data["cummul_returns_strat"].iloc[-1] - 1.0) * 100
            self.ret_strat_net = (data["cum_ret_strat_with_cost"].iloc[-1] - 1.0) * 100
            self.max_drawdown = data["drawdown"].max() * 100
            self.trades = int(data["trade"].sum())
        except Exception as error:
            print(error)
            self.ret_bnh = -1
            self.ret_strat = -1
            self.ret_strat_net = -1
            self.max_drawdown = -1
            self.trades = -1

        return (data)

    def print_metrics(self):
        """
        Prints the performance metrics of the trading strategy.
        """
        # Header
        header = "Trading Strategy Performance Metrics"
        print(header.center(50, "="))

        # Metrics
        print(f"{'Buy and Hold Strategy:':<25} {self.ret_bnh:>7.2f}%")
        print(f"{'Strategy:':<25} {self.ret_strat:>7.2f}%")
        print(f"{'Strategy with Trade Cost:':<25} {self.ret_strat_net:>7.2f}%")
        print(f"{'Max Drawdown:':<25} {self.max_drawdown:>7.2f}%")
        print(f"{'Number of trades:':<25} {self.trades:>7d}")

        # Footer
        print("=" * 50)

        logger.info(header.center(50, "="))

        # Metrics
        logger.info(f"{'Buy and Hold Strategy:':<25} {self.ret_bnh:>7.2f}%")
        logger.info(f"{'Strategy:':<25} {self.ret_strat:>7.2f}%")
        logger.info(f"{'Strategy with Trade Cost:':<25} {self.ret_strat_net:>7.2f}%")
        logger.info(f"{'Max Drawdown:':<25} {self.max_drawdown:>7.2f}%")
        logger.info(f"{'Number of trades:':<25} {self.trades:>7d}")

        # Footer
        logger.info("=" * 50)

    def plot_results(self):
        """
        Plots the results of the backtest with labels for each column.
        """

        # Plotting the DataFrame columns
        ax = self.result_df_test_strategy[["cummul_returns_bh",
                                           "cummul_returns_strat",
                                           "cum_ret_strat_with_cost"]].plot(figsize=(12, 8))

        # Adding a title to the plot
        plt.suptitle("BACKTEST" + f" -- {self.ticker}", fontsize=16)
        plt.title(f"{'Max Drawdown: '} {self.max_drawdown:5.2f}%" + "    |    " + f"{'Returns: '} {self.ret_strat_net:>5.2f}%", fontsize=12)

        # Adding a legend with labels, which are the column names
        ax.legend(["Buy n Hold", "Stratategy withOUT Cost", "Strategy WITH Cost"])

        ax.set_ylabel("Cumulative Returns")
        ax.set_xlabel("DATE (Timestamp)")

        # Display the plot
        plt.show()

    def read_df_minute(self, spark) -> pd.DataFrame:
        """
        Reads minute-level data from a predefined Spark SQL table.

        Returns:
            pd.DataFrame: A DataFrame containing minute-level trade data.
        """
        try:
            df_minute_spark = spark.sql(f"select * from {self.minute_table_name} where Timeframe == '{self.timeframe}'")
            df_minute_spark = df_minute_spark.select(DataColums.TIMESTAMP,
                                                    DataColums.TICKER,
                                                    DataColums.CLOSE)
            df_minute = df_minute_spark.toPandas()
            df_minute = df_minute.sort_values(by=DataColums.TIMESTAMP).reset_index().drop(columns=['index'])

            return df_minute

        except Exception as e:
            print(f"Error reading minute data: {e}")

            return pd.DataFrame()

    def save_backtest(self, backtest_id: str, storage_account_name: str) -> None:
        """
        Saves the backtest results to a Spark SQL table for further analysis or dashboard integration.
        """
        delta_table_path = f"wasbs://gold@{storage_account_name}.blob.core.windows.net/backtest_path/{backtest_id}"

        try:
            # sdf_results = ps.from_pandas(self.result_df_test_strategy.reset_index()).to_spark()

            # sdf_results = sdf_results.withColumn("ticker", F.lit(self.ticker)) \
            #                          .withColumn("backtest_id", F.lit(backtest_id)) \
            #                          .withColumn("optimize_method", F.lit(self.optimize_method))

            # sdf_results = sdf_results.select('backtest_id',
            #                                  'TIMESTAMP',
            #                                  'ticker',
            #                                  'strategy_type',
            #                                  'optimize_method',
            #                                  'strategy_with_cost',
            #                                  'trade',
            #                                  'SIGNAL')

            # for col in sdf_results.columns:
            #     sdf_results = sdf_results.withColumnRenamed(col, col.upper())

            #sdf_results.write.mode("append").format("delta").save(delta_table_path)
            df_results = self.result_df_test_strategy.reset_index().copy()
            df_results = df_results.assign(ticker=self.ticker,
                                           backtest_id=backtest_id,
                                           optimize_method = self.optimize_method)[['backtest_id',
                                                                                    'TIMESTAMP',
                                                                                    'ticker',
                                                                                    'CLOSE',
                                                                                    'strategy_type',
                                                                                    'optimize_method',
                                                                                    'strategy_with_cost',
                                                                                    'trade',
                                                                                    'SIGNAL',
                                                                                    'PROBABILITY',
                                                                                    'PREDICT']]

            self.result_df_test_strategy['ticker'] = self.ticker

            buffer = BytesIO()

            connection_dict = {
                    "storage_account_name": storage_account_name,
                    "container_name": 'gold',
                    "storage_account_key": 'Eubzuzb612QyIQN9lS9FA17b2LpiJQ9+RQtJJhV0LJcLRlurgd+iEbvfQ6qNUJYPToTE5uXAc+CH+AStPSZiwA==',
                }

            connection_dict["connect_str"] = (
                    f"DefaultEndpointsProtocol=https;AccountName={connection_dict['storage_account_name']};AccountKey={connection_dict['storage_account_key']};EndpointSuffix=core.windows.net"
                )

            connection_dict["relative_path"] = (
                f"wasbs://{connection_dict['container_name']}@{connection_dict['storage_account_name']}.blob.core.windows.net"
            )

            # Create the BlobServiceClient object which will be used to create a container client
            blob_service_client = BlobServiceClient.from_connection_string(connection_dict["connect_str"])

            blob_full_path = f"/short_backtest_path/{backtest_id}.parquet"

            blob_client = blob_service_client.get_blob_client(container=connection_dict["container_name"], blob=blob_full_path)

            df_results.to_parquet(buffer, index=False)
            buffer.seek(0)
            blob_client.upload_blob(buffer, blob_type="BlockBlob", overwrite=True)

            del df_results
        except Exception as e:
            logger.error(f"Error saving backtest results: {e}")
