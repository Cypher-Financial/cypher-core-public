# Databricks notebook source
# Setup blob azure
storage_account_name = "dlcypherus"
container_name = "gold"
storage_account_key = "Eubzuzb612QyIQN9lS9FA17b2LpiJQ9+RQtJJhV0LJcLRlurgd+iEbvfQ6qNUJYPToTE5uXAc+CH+AStPSZiwA=="

# COMMAND ----------

# Set the storage account key in the Spark session
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net",
    storage_account_key
)

# COMMAND ----------

# Mount blob storage to dbfs
dbutils.fs.mount(
    source = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net",
    mount_point = f"/mnt/{storage_account_name}/{container_name}",
    extra_configs = {f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net": storage_account_key}
)

# COMMAND ----------

# Get/Create a portfolio json
name = "sep_2024"

portfolio = {
    name: {
        "matic": {
            "train": "76dxOX7R282aBeZn",
            "retrain": "GOjlddp84iPUUo9I"
        },
        "link": {
            "train": "5pp3G3z0MnGgwT4l",
            "retrain": "oK14x8SbUQ4XeGjE"
        },
        "uni": {
            "train": "6ysBmR61eaUitBdh",
            "retrain": "Mi3PkYGQdjOrTygm"
        },
        "doge": {
            "train": "zCG7tkbukw9mxvyb",
            "retrain": "2CsUHBtYBS0xR1tH"
        },
        "dot": {
            "train": "AYD8juIaZKadIoJh",
            "retrain": "CZjojfYuS63914oq"
        },
        "eth": {
            "train": "OeJHC6vwzDuJVFOa",
            "retrain": "2pjjLQQ67Plb9g4O"
        },
        "xrp": {
            "train": "9jxodZcOoFOkChid",
            "retrain": "6AHXk3f7w0pmOX8d"
        },
        "btc": {
            "train": "dJtponyk3gEPOmgF",
            "retrain": "tFUyQ60w55R1brk5"
        }
    },
    "datetime": "2024-09-01 00:00:00"
}

# COMMAND ----------

# Get metadata_deploy
container_name = "gold"
table_name = "metadata_deploy_sandbox"

# Read from blob azure
delta_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{table_name}"
df_meta_deploy = spark.read.format("delta").load(delta_path)

# COMMAND ----------

scaler_keys = []
model_ids = []

for ticker, bids in portfolio[name].items():
    retrain_id = bids["retrain"]

    df_meta_deploy_fil = df_meta_deploy.filter(df_meta_deploy["BACKTEST_ID"] == retrain_id)

    result = df_meta_deploy_fil.select("SCALER_KEY", "MODEL_ID").collect()

    if result:
        scaler_keys.append(result[0]["SCALER_KEY"])
        model_ids.append(result[0]["MODEL_ID"])
    else:
        print(f"No matching backtest_id found for {ticker}")

scaler_keys = list(set(scaler_keys))
model_ids = list(set(model_ids))

print("Scaler Keys:", scaler_keys)
print("Model IDs:", model_ids)

# COMMAND ----------

folder = "features"
for model_id in model_ids:
    source_path = f"/mnt/{storage_account_name}/{container_name}/{folder}/features_{model_id}.txt"
    print(source_path)
    destination_path = f"dbfs:/FileStore/deploy/{folder}/features_{model_id}.txt"
    #dbutils.fs.cp(source_path, destination_path)

# COMMAND ----------

folder = "scalers"
for scaler_key in scaler_keys:
    source_path = f"/mnt/{storage_account_name}/{container_name}/{folder}/scaler_{scaler_key}.save"
    print(source_path)
    destination_path = f"dbfs:/FileStore/deploy/{folder}/scaler_{scaler_key}.save"
    #dbutils.fs.cp(source_path, destination_path)


# COMMAND ----------

folder = "models"
for model_id in model_ids:
    source_path = f"/mnt/{storage_account_name}/{container_name}/{folder}/model_{model_id}.pkl"
    print(source_path)
    destination_path = f"dbfs:/FileStore/deploy/{folder}/model_{model_id}.pkl"
    #dbutils.fs.cp(source_path, destination_path)


# COMMAND ----------

dbutils.fs.unmount(f"/mnt/{storage_account_name}/{container_name}")

# COMMAND ----------

# Write(append) new portfolio to metadata deploy (production or sandbox)
#spark.write.format("delta").mode("append").save(f'catalog.silver.{table_name}')
