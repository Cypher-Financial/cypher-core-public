import pandas as pd
import numpy as np

from constants import DataColums
from scipy.ndimage import generic_filter
from multiprocessing import Pool


def read_funding_cost(spark, container_name, storage_account_name):
    table_name = "candles_funding_1_minute_binancefuture"
    delta_table_path = f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/binance/{table_name}"

    # Acess metadata
    try:
        sdf_funding = spark.sql(f"select * from temp_{table_name}")
    except:
        spark.sql(f"CREATE TABLE temp_{table_name} USING delta LOCATION '{delta_table_path}'")
        sdf_funding = spark.sql(f"select * from temp_{table_name}")

    sdf_funding.persist()

    df_funding = sdf_funding.toPandas()

    sdf_funding.unpersist()

    return df_funding

def filter_funding_cost(config, df_funding):
    df_funding_ = df_funding[df_funding["TICKER"]==config['backtest']['ticker']].copy()
    df_funding_ = df_funding_.sort_values('TIMESTAMP').reset_index(drop=True)
    df_funding_['RETURN'] = (df_funding_.CLOSE / df_funding_.CLOSE.shift(1))-1
    df_funding_['FUND'] = df_funding_.index.map(lambda x: 1 if (x + 1) % 480 == 0 else 0)
    df_funding_ = df_funding_.dropna().reset_index(drop=True)
    df_funding_['FUND_VALUE'] = df_funding_['FUND']*df_funding_['RATE']
    df_funding_ = df_funding_[['TIMESTAMP', 'TICKER', 'CLOSE', 'FUND_VALUE']]

    return df_funding_

def convert_signal_to_minute(df_funding, df_backtest):
    # Left merge backtest dataframe with dataframe df_funding
    result_df = pd.merge(df_funding,
                        df_backtest,
                        on=[DataColums.TIMESTAMP, DataColums.TICKER], how='left')

    # Select data by start and end data processed
    end_date = df_backtest[DataColums.TIMESTAMP].tail(1).iloc[0]
    start_date = df_backtest[DataColums.TIMESTAMP].head(1).iloc[0]
    result_df = result_df[(result_df[DataColums.TIMESTAMP] > start_date) & (result_df[DataColums.TIMESTAMP] <= end_date)]

    return result_df


def convert_signal_to_strategy_type(config, result_df):

    strategy_type = config['info']['strategy_type']

    if strategy_type == 'long_and_short':
        # will hold previous value after ffil
        result_df[DataColums.SIGNAL] = result_df[DataColums.SIGNAL].replace(0, np.nan)
    elif strategy_type == 'long_only':
        result_df[DataColums.SIGNAL] = result_df[DataColums.SIGNAL].apply(lambda x: 0 if x == -1 else x)
    elif strategy_type == 'short_only':
        result_df[DataColums.SIGNAL] = result_df[DataColums.SIGNAL].apply(lambda x: 0 if x == 1 else x)
    elif strategy_type == 'long_or_short':
        pass
    else:
        raise ValueError("Setup a valid strategy: 'long_or_short', 'long_only', 'short_only', 'long_and_short'")

    result_df[DataColums.SIGNAL] = result_df[DataColums.SIGNAL].ffill()

    return result_df


def test_strategy(config, result_df_strategy_type):

    raw = result_df_strategy_type.set_index(DataColums.TIMESTAMP).sort_index()
    data = raw.copy()

    # Calculating returns
    data['RETURN'] = (data['CLOSE'] / data['CLOSE'].shift(1))-1

    # Foward fill null values
    data.fillna(method='ffill', inplace=True)
    data.dropna(inplace=True)

    position_size = config['backtest']['position_size']
    fixed_percentual = config['backtest']['fixed_percentual']
    trading_cost = config['backtest']['trading_cost']

    # Calculating returns with position Size and funding cost
    if position_size == 'kelly_critery':
        data['RETURN_WITH_POSITION_SIZE'] = data['RETURN'] * data['KELLY']
        data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-(data['FUND_VALUE'] * data['KELLY']),  data['RETURN_WITH_POSITION_SIZE']+(data['FUND_VALUE'] * data['KELLY']))
    elif position_size == 'fixed_percentual':
        data['RETURN_WITH_POSITION_SIZE'] = data['RETURN'] * fixed_percentual
        data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-(data['FUND_VALUE']* fixed_percentual ),  data['RETURN_WITH_POSITION_SIZE']+(data['FUND_VALUE']* fixed_percentual ))
    else:
        data['RETURN_WITH_POSITION_SIZE'] = data['RETURN']
        data['RETURN_WITH_FUNDING_COST'] = np.where(data['SIGNAL'] ==1, data['RETURN_WITH_POSITION_SIZE']-data['FUND_VALUE'],  data['RETURN_WITH_POSITION_SIZE']+data['FUND_VALUE'])

    # Calculating trades and strategy performance
    data["trade"] = data[DataColums.SIGNAL].diff().fillna(0).abs()
    data["strategy"] = data[DataColums.SIGNAL] * data["RETURN_WITH_POSITION_SIZE"]
    data["strategy_with_cost"] =  (data[DataColums.SIGNAL] * data["RETURN_WITH_FUNDING_COST"]) - (data["trade"] * trading_cost)

    # Cumulative returns calculation
    data["cummul_returns_bh"] = (data["RETURN"]+1).cumprod()
    data["cummul_returns_strat"] = (data["strategy"]+1).cumprod()
    data["cum_ret_strat_with_cost"] = (data["strategy_with_cost"]+1).cumprod()
    data["drawdown"] = (data["cum_ret_strat_with_cost"].cummax() - data["cum_ret_strat_with_cost"]) / data["cum_ret_strat_with_cost"].cummax()
    data["max_drawdown"] = data["drawdown"].cummax()
    data[DataColums.SIGNAL] = data[DataColums.SIGNAL].astype(int)

    return (data)


def process_quantiles(args):
    i, j, df_backtest_val, config, df_funding = args

    if df_backtest_val.empty:
        return [0, 0, 0, i, j, 1 - j, None, None]

    df_backtest_local = df_backtest_val.copy()
    df_backtest_local['PROBABILITY_MIN'] = df_backtest_local['PROBABILITY_LAG1'].expanding(min_periods=i).quantile(j)
    df_backtest_local['PROBABILITY_MAX'] = df_backtest_local['PROBABILITY_LAG1'].expanding(min_periods=i).quantile(1 - j)

    # Signal calculation can potentially be optimized further depending on the specifics of the conditions
    df_backtest_local['SIGNAL'] = np.select(
        [
            df_backtest_local['PROBABILITY'] < df_backtest_local['PROBABILITY_MIN'],
            df_backtest_local['PROBABILITY'] > df_backtest_local['PROBABILITY_MAX']
        ],
        [-1, 1],
        default=0
    )
    df_backtest_local['SIGNAL']=df_backtest_local['SIGNAL'].shift(1).dropna()

    if df_backtest_local.empty:
        return [0, 0, 0, i, j, 1 - j, None, None]

    # Assuming convert_signal_to_minute and other functions cannot be optimized without their definitions
    result_df = convert_signal_to_minute(df_funding, df_backtest_local)
    result_df_strategy_type = convert_signal_to_strategy_type(config, result_df)
    pandas_df_results = test_strategy(config, result_df_strategy_type)

    if pandas_df_results.empty:
        return [0, 0, 0, i, j, 1 - j, None, None]

    trade_sum = pandas_df_results['trade'].sum() / 2
    cum_ret_strat_with_cost = pandas_df_results["cum_ret_strat_with_cost"].iloc[-1]
    max_drawdown = pandas_df_results["max_drawdown"].iloc[-1]
    probability_min = df_backtest_local['PROBABILITY_MIN'].iloc[-1]
    probability_max = df_backtest_local['PROBABILITY_MAX'].iloc[-1]

    return [trade_sum, cum_ret_strat_with_cost, max_drawdown, i, j, 1 - j, probability_min, probability_max]


def tune_X_train_cutoff(config, df_spk, X_train, trainer, df_funding, framework):

    X_val = X_train[-int((0.2 * X_train.shape[0])):]

    if framework == 'torch':
        proba = trainer.predict_proba(X_val).tolist()
    else:
        proba = trainer.predict_proba(X_val)[:, 1].tolist()

    df_backtest_val = pd.DataFrame({
        'TIMESTAMP': df_spk['TIMESTAMP'].iloc[ 0:X_train.shape[0]][-int((0.2 * X_train.shape[0])):],
        'PROBABILITY': proba,
        'TICKER': config['backtest']['ticker']
    })
    df_backtest_val['PROBABILITY_LAG1'] = df_backtest_val['PROBABILITY'].shift(1)

    quantile_ranges = [(i, j) for i in range(100, 1500, 100) for j in np.arange(0.01, 0.3, 0.01)]

    with Pool() as pool:
        tasks = [(i, j, df_backtest_val, config, df_funding) for i, j in quantile_ranges]
        results = pool.map(process_quantiles, tasks)

    df_results = pd.DataFrame(results, columns=["TRADES", "RETURNS", "DRAWDOWN", "QUANTILE_WINDOW", "MIN_QUANTILE", "MAX_QUANTILE", "CUTOFF_MIN", "CUTOFF_MAX"])
    df_results["MIN_QUANTILE"] = df_results["MIN_QUANTILE"].round(2)
    df_results["RETURNS_DRAWNDOWN"] = df_results["RETURNS"] / df_results["DRAWDOWN"]
    df_results["RETURNS_TRADES"] = df_results["RETURNS"] / df_results["TRADES"]
    df_results["RETURNS_DRAWNDOWN_TRADES"] = df_results["RETURNS_DRAWNDOWN"] / df_results["TRADES"]

    df_results_pivot = df_results.pivot_table(values='RETURNS', index='QUANTILE_WINDOW', columns='MIN_QUANTILE', aggfunc='mean')

    probability_optimize_method = config['info']['probability_optimize_method']

    # Optimize this section by directly applying optimization methods
    if probability_optimize_method == "inverse_cv":
        heat_map = inverse_cv_mean(df_results_pivot)
        heat_map=zero_rows_cols(heat_map)
    elif probability_optimize_method == "mean":
        heat_map = apply_neighborhood_mean(df_results_pivot)
        heat_map=zero_rows_cols(heat_map)
    elif probability_optimize_method == "max_point":
        heat_map = df_results_pivot
    else:
        raise("Probability Optimize Method ot implemented!")

    # Find the maximum value in the smoothed DataFrame to identify the optimal parameters
    max_value = heat_map.max().max()
    optimal_params = heat_map.stack()[heat_map.stack() == max_value].index.tolist()[0]

    # Extracting the optimal quantile window and min quantile based on the location of the max value
    optimal_quantile_window, optimal_min_quantile = optimal_params

    # Use the determined max_value_location to select the optimal configuration
    df_tuning = df_results[(df_results["QUANTILE_WINDOW"] == optimal_quantile_window) & (df_results["MIN_QUANTILE"].round(2) == optimal_min_quantile)].iloc[0]

    cutoff_min = df_tuning["CUTOFF_MIN"]
    cutoff_max = df_tuning["CUTOFF_MAX"]

    return cutoff_min, cutoff_max


def mean_neighborhood(input_array):
    """
    Calculate the mean of a 3x3 neighborhood, ignoring NaN values.
    """
    valid_values = input_array[~np.isnan(input_array)]
    return np.mean(valid_values)


def apply_neighborhood_mean(df_results_pivot):
    """
    Applies a 3x3 neighborhood mean calculation to each cell in a 2D DataFrame.
    """
    # Convert the DataFrame to a numpy array for processing
    data_array = df_results_pivot.to_numpy()

    # Apply the mean_neighborhood function across the DataFrame
    mean_neighborhood_array = generic_filter(data_array, mean_neighborhood, size=(3, 3), mode='constant', cval=np.NaN)

    # Convert the result back to a DataFrame
    mean_neighborhood_df = pd.DataFrame(mean_neighborhood_array, index=df_results_pivot.index, columns=df_results_pivot.columns)

    return mean_neighborhood_df


def inverse_cv_mean(df_results_pivot):
    # ... your existing code to prepare df_results_pivot ...

    # Assuming df_results_pivot is ready and contains the RETURNS data in a 2D structure
    # Convert the pivot table to a numpy array for processing
    pivot_array = df_results_pivot.to_numpy()

    # Apply the custom CV function using a 3x3 neighborhood for each cell
    # The mode='constant' and cval=np.NaN ensure that the borders are handled by treating them as NaNs
    inverse_cv_neighborhood = generic_filter(pivot_array, calculate_cv_neighborhood, size=(3, 3), mode='constant', cval=np.NaN)

    # Convert the result back to a DataFrame for easier handling
    inverse_cv_df = pd.DataFrame(inverse_cv_neighborhood, index=df_results_pivot.index, columns=df_results_pivot.columns)

    return inverse_cv_df


def calculate_cv_neighborhood(input_array):
    """
    Calculate the coefficient of variation for a 3x3 neighborhood,
    ignoring NaN values. Returns inverse CV.
    """
    valid_values = input_array[~np.isnan(input_array)]
    mean = np.mean(valid_values)
    std = np.std(valid_values)
    cv = std / mean if mean != 0 else np.nan
    return 1 / cv if cv != 0 else np.nan


def zero_rows_cols(df):

    # Setting the first and last row to 0
    df.iloc[0, :] = 0
    df.iloc[-1, :] = 0

    # Setting the first and last column to 0
    df.iloc[:, 0] = 0
    df.iloc[:, -1] = 0
    return df


def coeff_of_variation(x):
    return x.std() / x.mean()

def calculate_fixed_percentil(config, df_spk, X_train, trainer, df_funding, framework, optimize_method):

    percentil = float(optimize_method.split('_')[-1])

    if 'X_val' in optimize_method:
        x = X_train[-int((0.2 * X_train.shape[0])):]
    else:
        x = X_train

    df_backtest_local = pd.DataFrame({
    'TIMESTAMP': df_spk['TIMESTAMP'].iloc[0:X_train.shape[0]][-int(x.shape[0]):],
    'TICKER': config['backtest']['ticker']})

    if config['info']['model_type'] == 'clf':
        if framework == 'torch':
            proba = trainer.predict_proba(x).tolist()
        else:
            proba = trainer.predict_proba(x)[:, 1].tolist()

        df_backtest_local['PROBABILITY'] = proba
        df_backtest_local['PROBABILITY_LAG1'] = df_backtest_local['PROBABILITY'].shift(1)
        df_backtest_local['PROBABILITY_MIN'] = df_backtest_local['PROBABILITY_LAG1'].quantile(percentil)
        df_backtest_local['PROBABILITY_MAX'] = df_backtest_local['PROBABILITY_LAG1'].quantile(1 - percentil)
        df_backtest_local['SIGNAL'] = df_backtest_local.apply(lambda x: -1 if x['PROBABILITY'] < x['PROBABILITY_MIN'] else (1 if x['PROBABILITY'] > x['PROBABILITY_MAX'] else 0), axis=1)

    else:
        predict = trainer.predict(x)

        df_backtest_local['PREDICT'] = predict
        df_backtest_local['PREDICT_MIN'] = df_backtest_local['PREDICT'].quantile(percentil)
        df_backtest_local['PREDICT_MAX'] = df_backtest_local['PREDICT'].quantile(1 - percentil)
        df_backtest_local['SIGNAL'] = df_backtest_local.apply(lambda x: -1 if x['PREDICT'] < x['PREDICT_MIN'] else (1 if x['PREDICT'] > x['PREDICT_MAX'] else 0), axis=1)

    df_backtest_local['SIGNAL']=df_backtest_local['SIGNAL'].shift(1).dropna()


    if config['info']['model_type'] == 'clf':
        cutoff_min = df_backtest_local['PROBABILITY_MIN'].iloc[-1]
        cutoff_max = df_backtest_local['PROBABILITY_MAX'].iloc[-1]
    else:
        cutoff_min = df_backtest_local['PREDICT_MIN'].iloc[-1]
        cutoff_max = df_backtest_local['PREDICT_MAX'].iloc[-1]

    max_value = 0

    return max_value, cutoff_min, cutoff_max


def quantile_return_optimize(config, df_spk, X_train, trainer, df_funding, framework, optimize_method):

    if 'X_val' in optimize_method:
        x = X_train[-int((0.2 * X_train.shape[0])):]
    else:
        x = X_train

    df_backtest_local = pd.DataFrame({
    'TIMESTAMP': df_spk['TIMESTAMP'].iloc[ 0:X_train.shape[0]][-int(x.shape[0]):],
    'TICKER': config['backtest']['ticker']})

    if config['info']['model_type'] == 'clf':
        if framework == 'torch':
            proba = trainer.predict_proba(x).tolist()
        else:
            proba = trainer.predict_proba(x)[:, 1].tolist()

        df_backtest_local['PROBABILITY'] = proba
        df_backtest_local['PROBABILITY_LAG1'] = df_backtest_local['PROBABILITY'].shift(1)
    else:
        predict = trainer.predict(x)

        df_backtest_local['PREDICT'] = predict

    all_results = []

    for j in np.arange(0.01, 0.4, 0.02):
        if config['info']['model_type'] == 'clf':
            df_backtest_local['PROBABILITY_MIN'] = df_backtest_local['PROBABILITY_LAG1'].quantile(j)
            df_backtest_local['PROBABILITY_MAX'] = df_backtest_local['PROBABILITY_LAG1'].quantile(1 - j)
            df_backtest_local['SIGNAL'] = df_backtest_local.apply(lambda x: -1 if x['PROBABILITY'] < x['PROBABILITY_MIN'] else (1 if x['PROBABILITY'] > x['PROBABILITY_MAX'] else 0), axis=1)
        else:
            df_backtest_local['PREDICT_MIN'] = df_backtest_local['PREDICT'].quantile(j)
            df_backtest_local['PREDICT_MAX'] = df_backtest_local['PREDICT'].quantile(1 - j)
            df_backtest_local['SIGNAL'] = df_backtest_local.apply(lambda x: -1 if x['PREDICT'] < x['PREDICT_MIN'] else (1 if x['PREDICT'] > x['PREDICT_MAX'] else 0), axis=1)

        df_backtest_local['SIGNAL']=df_backtest_local['SIGNAL'].shift(1).dropna()

        # Assuming convert_signal_to_minute and other functions cannot be optimized without their definitions
        # BUG: Possible error of timestamp types
        result_df = convert_signal_to_minute(df_funding, df_backtest_local)
        # BUG: Multicripto always calculate cuttoff based on long and short strategy type
        # while retrain computes cuttoff based on the strategy type selected. This is
        # creating different cuttoffs min and max values causing the metrics divergence.
        result_df_strategy_type = convert_signal_to_strategy_type(config, result_df)
        pandas_df_results = test_strategy(config, result_df_strategy_type)

        trade_sum = pandas_df_results['trade'].sum() / 2
        cum_ret_strat_with_cost = pandas_df_results["cum_ret_strat_with_cost"].iloc[-1]
        max_drawdown = pandas_df_results["max_drawdown"].iloc[-1]

        if config['info']['model_type'] == 'clf':
            min_cutoff = df_backtest_local['PROBABILITY_MIN'].iloc[-1]
            max_cutoff = df_backtest_local['PROBABILITY_MAX'].iloc[-1]
        else:
            min_cutoff = df_backtest_local['PREDICT_MIN'].iloc[-1]
            max_cutoff = df_backtest_local['PREDICT_MAX'].iloc[-1]

        results = [trade_sum, cum_ret_strat_with_cost, max_drawdown, j, 1 - j, min_cutoff, max_cutoff]
        all_results.append(results)

    df_results = pd.DataFrame(all_results, columns=["TRADES", "RETURNS", "DRAWDOWN", "MIN_QUANTILE", "MAX_QUANTILE", "CUTOFF_MIN", "CUTOFF_MAX"])
    df_results["MIN_QUANTILE"] = df_results["MIN_QUANTILE"].round(3)
    df_results["RETURNS_DRAWNDOWN"] = df_results["RETURNS"] / df_results["DRAWDOWN"]
    df_results["RETURNS_TRADES"] = df_results["RETURNS"] / df_results["TRADES"]
    df_results["RETURNS_DRAWNDOWN_TRADES"] = df_results["RETURNS_DRAWNDOWN"] / df_results["TRADES"]

    # Optimize this section by directly applying optimization methods
    if ( optimize_method == "X_train_inverse_cv_percentil") or ( optimize_method == "X_val_inverse_cv_percentil"):
         df_results['METRIC'] =  df_results['RETURNS'].rolling(window=5, center=True).apply(coeff_of_variation, raw=True)
    elif ( optimize_method == "X_train_mean_percentil") or ( optimize_method ==  "X_val_mean_percentil"):
        df_results['METRIC'] = ( df_results['RETURNS'] + df_results['RETURNS'].shift(1)  +  df_results['RETURNS'].shift(2) +  df_results['RETURNS'].shift(-1)  +  df_results['RETURNS'].shift(-2))/5
    elif ( optimize_method == "X_train_max_point_percentil") or ( optimize_method == "X_val_max_point_percentil"):
        df_results['METRIC'] = df_results['RETURNS']
    else:
        raise("Probability Optimize Method ot implemented!")

    # Find the maximum value in the smoothed DataFrame to identify the optimal parameters
    max_value = df_results['METRIC'].max()

    cutoff_min = df_results[df_results['METRIC'] == max_value]['CUTOFF_MIN'].iloc[0]
    cutoff_max = df_results[df_results['METRIC'] == max_value]['CUTOFF_MAX'].iloc[0]

    return max_value, cutoff_min, cutoff_max


def regression_filter_return_optimize(config, df_spk, X_train, trainer, df_funding, framework, optimize_method):

    if ('X_val' in optimize_method):
        x = X_train[-int((0.2 * X_train.shape[0])):]
    else:
        x = X_train

    predict = trainer.predict(x)

    df_backtest_local = pd.DataFrame({
        'TIMESTAMP': df_spk['TIMESTAMP'].iloc[ 0:X_train.shape[0]][-int(x.shape[0]):],
        'PREDICT': predict,
        'TICKER': config['backtest']['ticker']
    })

    all_results = []

    short_timeframe = ['5m', '15m', '30m', '1h']
    medium_timeframe = ['2h', '4h', '8h']
    long_timeframe = ['12h', '1d']

    timeframe = config['backtest']['timeframe']
    if (timeframe in short_timeframe):
        value_range = (0.001, 0.01, 0.001)
    elif (timeframe in medium_timeframe):
        value_range = (0.005, 0.03, 0.005)
    elif (timeframe in long_timeframe):
        value_range = (0.01, 0.10, 0.01)
    else:
        raise ValueError("Timeframe not implemented for this version!!!")

    for filter in np.arange(*value_range):
        df_backtest_local['SIGNAL'] = df_backtest_local.apply(lambda x: -1 if x['PREDICT'] < -filter else (1 if x['PREDICT'] > filter else 0), axis=1)
        df_backtest_local['SIGNAL'] = df_backtest_local['SIGNAL'].shift(1).dropna()

        # Assuming convert_signal_to_minute and other functions cannot be optimized without their definitions
        result_df = convert_signal_to_minute(df_funding, df_backtest_local)
        result_df_strategy_type = convert_signal_to_strategy_type(config, result_df)

        try:
            pandas_df_results = test_strategy(config, result_df_strategy_type)
            trade_sum = pandas_df_results['trade'].sum() / 2
            cum_ret_strat_with_cost = pandas_df_results["cum_ret_strat_with_cost"].iloc[-1]
            max_drawdown = pandas_df_results["max_drawdown"].iloc[-1]
        except:
            trade_sum = 0
            cum_ret_strat_with_cost = 0
            max_drawdown = 1

        results = [trade_sum, cum_ret_strat_with_cost, max_drawdown, filter]
        all_results.append(results)

    df_results = pd.DataFrame(all_results, columns=["TRADES", "RETURNS", "DRAWDOWN", "REGRESSION_FILTER"])
    df_results["REGRESSION_FILTER"] = df_results["REGRESSION_FILTER"].round(3)
    df_results["RETURNS_DRAWNDOWN"] = df_results["RETURNS"] / df_results["DRAWDOWN"]
    df_results["RETURNS_TRADES"] = df_results["RETURNS"] / df_results["TRADES"]
    df_results["RETURNS_DRAWNDOWN_TRADES"] = df_results["RETURNS_DRAWNDOWN"] / df_results["TRADES"]

    # Optimize this section by directly applying optimization methods
    if ( optimize_method == "X_train_inverse_cv_filter") or ( optimize_method == "X_val_inverse_cv_filter"):
         df_results['METRIC'] =  df_results['RETURNS'].rolling(window=5, center=True).apply(coeff_of_variation, raw=True)
    elif ( optimize_method == "X_train_mean_filter") or ( optimize_method ==  "X_val_mean_filter"):
        df_results['METRIC'] = ( df_results['RETURNS'] + df_results['RETURNS'].shift(1)  +  df_results['RETURNS'].shift(2) +  df_results['RETURNS'].shift(-1)  +  df_results['RETURNS'].shift(-2))/5
    elif ( optimize_method == "X_train_max_point_filter") or ( optimize_method == "X_val_max_point_filter"):
        df_results['METRIC'] = df_results['RETURNS']
    else:
        raise("Probability Optimize Method ot implemented!")

    # Find the maximum value in the smoothed DataFrame to identify the optimal parameters
    max_value = df_results['METRIC'].max()
    regresion_filter = df_results[df_results['METRIC'] == max_value]['REGRESSION_FILTER'].iloc[0]

    cutoff_min = -regresion_filter
    cutoff_max = regresion_filter

    return max_value, cutoff_min, cutoff_max


def fixed_regression_filter(config, df_spk, X_train, trainer, df_funding, framework, optimize_method):

    regression_filter = float(optimize_method.split('_')[-1])

    max_value = 0
    cutoff_min = - regression_filter
    cutoff_max =  regression_filter

    return max_value, cutoff_min, cutoff_max

