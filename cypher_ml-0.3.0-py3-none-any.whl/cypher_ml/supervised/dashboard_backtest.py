#from databricks.sdk.runtime import *
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import calendar
import matplotlib.gridspec as gridspec
from scipy.stats import linregress

import warnings

warnings.filterwarnings("ignore", category=FutureWarning)


# Funções para calcular as métricas
def calculate_total_return(cum_returns):
    return cum_returns.iloc[-1] - 1


def calculate_cagr(cum_returns, days):
    return (((cum_returns.iloc[-1])**(365.0 / days)) - 1)


def calculate_annual_volatility(df):
    returns = df['DAILY_RETURN']
    return returns.std() * np.sqrt(365)


def calculate_annual_volatility_bh(df):
    returns = df['DAILY_RETURN_BH']
    return returns.std() * np.sqrt(365)


def calculate_sharpe_ratio(df, days, rf_rate=0):
    # returns = df['DAILY_RETURN']
    cagr = calculate_cagr(df['CUM_RET_STRAT_WITH_COST'], days)
    anual_volatiliy = calculate_annual_volatility(df)
    return cagr / anual_volatiliy


def calculate_sharpe_ratio_bh(df, days, rf_rate=0):
    # returns = df['DAILY_RETURN']
    cagr = calculate_cagr(df['CUMMUL_RETURNS_BH'], days)
    anual_volatiliy = calculate_annual_volatility_bh(df)
    return cagr / anual_volatiliy


def calculate_sortino_ratio(df, days, rf_rate=0):
    df_negative_returns = df[df['DAILY_RETURN'] <0]['DAILY_RETURN']
    cagr = calculate_cagr(df['CUM_RET_STRAT_WITH_COST'], days)
    negative_anual_volatiliy = df_negative_returns.std() * np.sqrt(365) * 100
    return cagr / negative_anual_volatiliy


def calculate_sortino_ratio_bh(df, days, rf_rate=0):
    df_negative_returns = df[df['DAILY_RETURN_BH'] <0]['DAILY_RETURN_BH']
    cagr = calculate_cagr(df['CUMMUL_RETURNS_BH'], days)
    negative_anual_volatiliy = df_negative_returns.std() * np.sqrt(365) * 100
    return cagr / negative_anual_volatiliy


def calculate_r_squared(log_returns, benchmark_returns):
    slope, intercept, r_value, p_value, std_err = linregress(benchmark_returns, log_returns)
    return r_value ** 2


def calculate_max_drawdown(max_drawdown):
    max_drawdown = max_drawdown.max()
    return max_drawdown


def calculate_calmar_ratio(cum_returns, max_drawndow, days):
    cagr = calculate_cagr(cum_returns, days)
    max_drawdown = calculate_max_drawdown(max_drawndow)
    if max_drawdown == 0:
        return float('inf')  # Retorna infinito se o drawdown máximo for 0
    return cagr / abs(max_drawdown)


def calculate_max_drawdown_duration(data):
    """
    Calculate the maximum drawdown duration in days.

    Args:
        data (pd.DataFrame): DataFrame with 'DRAWDOWN' column.

    Returns:
        int: The maximum drawdown duration in days.
    """
    # Converter a coluna 'DRAWDOWN' para booleano: True para drawdown, False caso contrário
    is_drawdown = data['DRAWDOWN'] > 0

    # Identificar inícios e fins dos períodos de drawdown
    drawdown_starts = is_drawdown & (~is_drawdown.shift(1).fillna(False))
    drawdown_ends = ~is_drawdown & (is_drawdown.shift(1).fillna(False))

    # Inicializar variáveis
    max_duration = 0
    start_date = None

    # Iterar sobre o DataFrame para calcular a duração de cada drawdown
    for timestamp in data.index:
        if drawdown_starts[timestamp].any():
            start_date = timestamp
        elif drawdown_ends[timestamp].any() and start_date is not None:
            duration = (timestamp - start_date).days
            max_duration = max(max_duration, duration)
            start_date = None

    return max_duration


def calculate_max_drawdown_duration_bh(data):
    """
    Calculate the maximum drawdown duration in days.

    Args:
        data (pd.DataFrame): DataFrame with 'DRAWDOWN' column.

    Returns:
        int: The maximum drawdown duration in days.
    """
    # Converter a coluna 'DRAWDOWN' para booleano: True para drawdown, False caso contrário
    is_drawdown = data['DRAWDOWN_BH'] > 0

    # Identificar inícios e fins dos períodos de drawdown
    drawdown_starts = is_drawdown & (~is_drawdown.shift(1).fillna(False))
    drawdown_ends = ~is_drawdown & (is_drawdown.shift(1).fillna(False))

    # Inicializar variáveis
    max_duration = 0
    start_date = None

    # Iterar sobre o DataFrame para calcular a duração de cada drawdown
    for timestamp in data.index:
        if drawdown_starts[timestamp].any():
            start_date = timestamp
        elif drawdown_ends[timestamp].any() and start_date is not None:
            duration = (timestamp - start_date).days
            max_duration = max(max_duration, duration)
            start_date = None

    return max_duration


def run_dashboard(df, strategy_type):

    df_backtest = df
    df_backtest = df_backtest.reset_index()
    df_backtest.columns = df_backtest.columns.str.upper()

    # Modelagem para gráficos e algumas métricas como retorno total e CAGR:
    df_backtest['TIMESTAMP'] = pd.to_datetime(df_backtest['TIMESTAMP'])
    df_backtest['STRATEGY'] = df_backtest['SIGNAL'] * df_backtest['RETURN']
    df_backtest['GROUP_SIGNAL'] = df_backtest['SIGNAL'].ne(df_backtest['SIGNAL'].shift()).cumsum()
    df_backtest['DRAWDOWN_BH'] = (df_backtest['CUMMUL_RETURNS_BH'].cummax() - df_backtest['CUMMUL_RETURNS_BH']) / df_backtest['CUMMUL_RETURNS_BH'].cummax()
    df_backtest['MAX_DRAWDOWN_BH'] = df_backtest['DRAWDOWN_BH'].cummax()
    df_backtest['DATE'] = df_backtest['TIMESTAMP'].dt.date
    df_backtest['DATE'] = df_backtest['DATE'].apply(lambda x: x.strftime('%Y-%m-%d'))

    # Modelagem para cálculo das métricas de volatilidade anual, sharpe rate, sortino rate e máximo drawdown:
    df_metricas = df_backtest.copy()
    df_metricas["STRATEGY_WITH_COST"] = (df_metricas['SIGNAL'] * df_metricas["STRATEGY"]) - (df_metricas["TRADE"] * 0.0005)
    df_metricas['TIMESTAMP'] = pd.to_datetime(df_metricas['TIMESTAMP'])
    df_metricas['DATE_LAG'] = df_metricas['DATE'].shift(1)
    df_metricas = df_metricas[df_metricas['DATE_LAG']!=df_metricas['DATE']]
    df_metricas.loc[:, 'DAILY_RETURN'] = (df_metricas['CUM_RET_STRAT_WITH_COST']/df_metricas['CUM_RET_STRAT_WITH_COST'].shift(1)) - 1
    df_metricas.loc[:, 'DAILY_RETURN_BH'] = (df_metricas['CUMMUL_RETURNS_BH']/df_metricas['CUMMUL_RETURNS_BH'].shift(1)) - 1

    # Modelagem para calcular as métricas da tabela de trades:
    df_metricas_2 = df_backtest.groupby('GROUP_SIGNAL').first().reset_index().sort_values('TIMESTAMP')
    df_metricas_2 = pd.concat([df_metricas_2, df_backtest.iloc[-1:].reset_index(drop=True)], ignore_index=True)
    df_metricas_2['STRATEGY'] = (df_metricas_2['CUM_RET_STRAT_WITH_COST'].shift(-1)/df_metricas_2['CUM_RET_STRAT_WITH_COST'])-1

    # Dataframe com a coluna TIMESTAMP recuperada para cálculo da duração máxima do drawdown:
    df_backtest_2 = df_backtest.copy()
    df_backtest_2 = df_backtest.set_index("TIMESTAMP")

    # Criar o primeiro gráfico do desempenho da estratégia
    plt.figure(figsize=(24, 7))
    plt.plot(df_backtest['TIMESTAMP'], df_backtest['CUMMUL_RETURNS_BH'], label='Buy n Hold', color='blue', linewidth=0.8, alpha=0.7)
    plt.plot(df_backtest['TIMESTAMP'], df_backtest['CUMMUL_RETURNS_STRAT'], label='Strategy without Cost', color='orange', linewidth=0.8, linestyle='--', alpha=0.7)
    plt.plot(df_backtest['TIMESTAMP'], df_backtest['CUM_RET_STRAT_WITH_COST'], label='Strategy with Cost', color='green', linewidth=0.8, alpha=0.7)

    # Adicionando títulos e rótulos
    plt.suptitle(f"BACKTEST: {df_backtest['TICKER'].iloc[0]}", fontsize=18)
    plt.ylabel("Cumulative Returns")
    plt.xlabel("Date")
    plt.legend()
    plt.grid(alpha=0.4)

    # Criar o gráfico de Drawdown
    df_backtest['DRAWDOWN_2'] = (df_backtest['DRAWDOWN'] * -1) * 100
    plt.figure(figsize=(24, 4))
    plt.fill_between(df_backtest['TIMESTAMP'], df_backtest['DRAWDOWN_2'], step="pre", color='red', alpha=0.5)
    plt.title('Drawdown (%)')
    plt.ylabel('Drawdown (%)')
    plt.xlabel('Date')
    plt.grid(alpha=0.4)

    # Cálculo dos retornos mensais
    df_backtest['Year'] = df_backtest['TIMESTAMP'].dt.year
    df_backtest['Month'] = df_backtest['TIMESTAMP'].dt.month

    # Agrupar por ano e mês e pegar o último valor de cada mês para retornos
    monthly_last = df_backtest.groupby(['Year', 'Month']).last()

    # Agrupar por ano e mês e pegar o primeiro valor de cada mês para retornos
    monthly_first = df_backtest.groupby(['Year', 'Month']).first()

    # Calcular os retornos mensais
    monthly_returns = (monthly_last['CUM_RET_STRAT_WITH_COST'] / monthly_first['CUM_RET_STRAT_WITH_COST']) - 1

    # Reestruturar para a tabela de retornos mensais
    monthly_returns_table = monthly_returns.unstack(level=-1) * 100  # Convertendo para percentual

    # Mapeando os números dos meses para seus nomes abreviados
    monthly_returns_table.columns = [calendar.month_abbr[month] for month in monthly_returns_table.columns]

    # Cálculo da quantidade de trades por mês
    monthly_trades = df_backtest.groupby(['Year', 'Month'])['TRADE'].sum()/2

    # Reestruturar para a tabela de trades mensais
    monthly_trades_table = monthly_trades.unstack(level=-1)

    # Mapeando os números dos meses para seus nomes abreviados para trades
    monthly_trades_table.columns = [calendar.month_abbr[month] for month in monthly_trades_table.columns]

    # Cálculo dos retornos anuais
    annual_returns = df_backtest.groupby('Year')['CUM_RET_STRAT_WITH_COST'].last() / df_backtest.groupby('Year')['CUM_RET_STRAT_WITH_COST'].first() - 1
    annual_returns = annual_returns.dropna() * 100

    # Início da plotagem
    fig = plt.figure(figsize=(24, 6))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1], width_ratios=[0.65, 0.35], hspace=0.02)  # Ajuste dos ratios e espaçamento

    # Cores para as células das tabelas
    red_light = "#ffcccc"
    green_light = "#ccffcc"

    # Primeira subtrama para a tabela de retornos mensais
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.axis('off')  # Ocultar os eixos
    ax1.text(0.5, 1.1, 'Monthly Returns', ha='center', va='bottom', transform=ax1.transAxes, fontsize=16)

    # Configuração da primeira tabela (retornos mensais)
    cell_colours_returns = np.empty_like(monthly_returns_table.values, dtype=object)
    for i, row in enumerate(monthly_returns_table.values):
        for j, val in enumerate(row):
            if np.isnan(val):
                cell_colours_returns[i, j] = 'white'  # Cor de fundo para valores NaN
            else:
                cell_colours_returns[i, j] = green_light if val > 0 else red_light

    table_returns = ax1.table(cellText=monthly_returns_table.round(2).fillna('').values,
                              rowLabels=monthly_returns_table.index,
                              colLabels=monthly_returns_table.columns,
                              cellLoc='center',
                              loc='upper center',
                              colColours=['lightgray'] * len(monthly_returns_table.columns),
                              cellColours=cell_colours_returns)

    table_returns.auto_set_font_size(False)
    table_returns.set_fontsize(14)
    table_returns.scale(1, 2)

    # Criação da matriz de cores para a tabela de trades mensais
    cell_colours_trades = np.empty_like(monthly_trades_table.values, dtype=object)
    for i, row in enumerate(monthly_trades_table.values):
        for j, val in enumerate(row):
            if val > 0:
                cell_colours_trades[i, j] = green_light  # Cor para valores maiores que zero
            else:
                cell_colours_trades[i, j] = 'white'  # Cor padrão para os outros valores


    # Segunda subtrama para a tabela de trades mensais
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.axis('off')  # Ocultar os eixos
    ax3.text(0.5, 1.1, 'Monthly Trades', ha='center', va='bottom', transform=ax3.transAxes, fontsize=16)

    # Configuração da segunda tabela (trades mensais)
    table_trades = ax3.table(cellText=monthly_trades_table.fillna('').values,
                            rowLabels=monthly_trades_table.index,
                            colLabels=monthly_trades_table.columns,
                            cellLoc='center',
                            loc='upper center',
                            cellColours=cell_colours_trades,
                            colColours=['lightgray'] * len(monthly_trades_table.columns))

    table_trades.auto_set_font_size(False)
    table_trades.set_fontsize(14)
    table_trades.scale(1, 2)

    # Subtrama para o gráfico de barras de retornos anuais
    ax2 = fig.add_subplot(gs[:, 1])

    # Configuração do gráfico de barras (retornos anuais)
    x_labels = annual_returns.index.astype(int).tolist()
    x_labels.extend([min(x_labels) - 1, max(x_labels) + 1])
    x_labels = sorted(set(x_labels))

    x_pos = range(len(x_labels))
    plot_values = [annual_returns[y] if y in annual_returns.index else 0 for y in x_labels]
    facecolors = ['green' if value > 0 else 'red' for value in plot_values]

    bars = ax2.bar(x_pos, plot_values, color=facecolors, edgecolor=facecolors, alpha=0.5)

    for bar, value in zip(bars, plot_values):
        height = bar.get_height()
        # Increase font size to, e.g., 12 and make it bold
        ax2.text(bar.get_x() + bar.get_width() / 2, height, f'{value:.2f}%', ha='center', va='bottom', fontsize=12)

    ax2.grid(alpha=0.4)
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels(x_labels, fontweight='bold', fontsize=12)  # Bold and increase font size for xticklabels too
    ax2.set_title("Annual Returns", fontweight='bold', fontsize=14)  # Make title bold and slightly larger
    ax2.set_xlabel("Year", fontweight='bold', fontsize=12)  # Bold and increase font size for x-axis label
    ax2.set_ylabel("Returns (%)", fontweight='bold', fontsize=12)  # Bold and increase font size for y-axis label
    ax2.set_ylim(bottom=-110)

    # Preparando os dados para cálculo das métricas
    days = df_backtest['DATE'].nunique()

    # Calculando as métricas para a primeira tabela
    metrics_curve_benchmark = {
        "Metric": ["Total Return", "CAGR","Annual Volatility","Sharpe Ratio","Sortino Ratio","Max Drawdown", "Max Drawdown Duration"],
        "Buy and Hold": [
            f"{calculate_total_return(df_backtest['CUMMUL_RETURNS_BH']) * 100:.2f}%",
            f"{calculate_cagr(df_backtest['CUMMUL_RETURNS_BH'], days) * 100:.2f}%",
            f"{calculate_annual_volatility_bh(df_metricas) * 100:.2f}%",
            f"{calculate_sharpe_ratio_bh(df_metricas, days):.2f}",
            f"{calculate_sortino_ratio_bh(df_metricas, days) * 100:.2f}",
            f"{calculate_max_drawdown(df_metricas['MAX_DRAWDOWN_BH']) * 100:.2f}%",
            f"{calculate_max_drawdown_duration_bh(df_backtest_2)}"
        ],
        "Strategy with Cost": [
            f"{calculate_total_return(df_backtest['CUM_RET_STRAT_WITH_COST']) * 100:.2f}%",
            f"{calculate_cagr(df_backtest['CUM_RET_STRAT_WITH_COST'], days) * 100:.2f}%",
            f"{calculate_annual_volatility(df_metricas) * 100:.2f}%",
            f"{calculate_sharpe_ratio(df_metricas, days):.2f}",
            f"{calculate_sortino_ratio(df_metricas, days) * 100:.2f}",
            f"{calculate_max_drawdown(df_metricas['MAX_DRAWDOWN']) * 100:.2f}%",
            f"{calculate_max_drawdown_duration(df_backtest_2)}"
        ]
    }

    calmar_ratio_bh = calculate_calmar_ratio(df_metricas['CUMMUL_RETURNS_BH'], df_metricas['MAX_DRAWDOWN_BH'], days)
    calmar_ratio_strat_with_cost = calculate_calmar_ratio(df_metricas['CUM_RET_STRAT_WITH_COST'], df_metricas['MAX_DRAWDOWN'], days)

    metrics_curve_benchmark["Metric"].append("Calmar Ratio")
    metrics_curve_benchmark["Buy and Hold"].append(f"{calmar_ratio_bh :.2f}")
    metrics_curve_benchmark["Strategy with Cost"].append(f"{calmar_ratio_strat_with_cost :.2f}")

    # Convertendo para DataFrame
    df_curve_benchmark = pd.DataFrame(metrics_curve_benchmark)

    if (strategy_type == 'long_and_short') or (strategy_type == 'long_or_short'):
        # Calculando as métricas para a tabela "Trade"
        # Identificando trades vencedores e perdedores
        trades_return = df_metricas_2['STRATEGY']
        quantidade_trades = df_metricas_2['TRADE'].sum()/2
        total_return = df_backtest['CUM_RET_STRAT_WITH_COST'].iloc[-1]-1
        winning_trades_return = trades_return[trades_return > 0]
        losing_trades_return = trades_return[trades_return < 0]

        # Calculando as métricas
        trade_winning_percent = len(winning_trades_return) / len(trades_return) * 100 if len(trades_return) > 0 else 0
        average_trade_percent = (total_return / quantidade_trades) * 100 if quantidade_trades > 0 else 0
        average_win_percent = winning_trades_return.mean() if len(winning_trades_return) > 0 else 0
        average_loss_percent = losing_trades_return.mean() if len(losing_trades_return) > 0 else 0
        best_trade_percent = trades_return.max() * 100
        worst_trade_percent = trades_return.min() * 100
        total_trades = df_metricas_2[(df_metricas_2['SIGNAL'] != df_metricas_2['SIGNAL'].shift(1)) & (df_metricas_2['SIGNAL'] != 0)].shape[0]# df_metricas_2['TRADE'].shape[0]

        # Organizando os resultados em um dicionário para criar o DatNãoaFrame
        metrics_trade = {
            "Metric": ["Trade Winning %", "Average Trade %", "Average Win %", "Average Loss %",
                    "Best Trade %", "Worst Trade %","Total Trades"],
            "Result": [f"{trade_winning_percent:.2f}%", f"{average_trade_percent:.2f}%", f"{average_win_percent * 100:.2f}%", f"{average_loss_percent * 100:.2f}%",
                    f"{best_trade_percent:.2f}%", f"{worst_trade_percent:.2f}%",f"{total_trades:.0f}"]
        }

        # Convertendo para DataFrame
        df_trade = pd.DataFrame(metrics_trade)

    if 'long' in strategy_type:

        # Calculando as métricas para a tabela "Trade_Longs"
        df_trades_long = df_backtest[df_backtest['SIGNAL'] != df_backtest['SIGNAL'].shift(1)].copy()
        df_trades_long['RETURN_LONG'] = np.where(df_trades_long['SIGNAL']==1, ((df_trades_long['CLOSE'].shift(-1)/df_trades_long['CLOSE'])-1)-0.001,0)
        df_trades_long = df_trades_long[df_trades_long['SIGNAL'] == 1]

        trades_return_long =  df_trades_long['STRATEGY']
        # quantidade_trades_long = df_trades_long['TRADE'].sum()/2
        # total_return_long = df_trades_long['CUM_RET_STRAT_WITH_COST'].iloc[-1]-1
        # winning_trades_return_long = trades_return_long[trades_return_long > 0]
        # losing_trades_return_long = trades_return_long[trades_return_long < 0]

        # Calculando as métricas
        long_trade_winning_percent = df_trades_long[df_trades_long['RETURN_LONG']>0].shape[0]/df_trades_long.shape[0] * 100 if df_trades_long.shape[0] > 0 else 0
        long_average_trade_percent = df_trades_long['RETURN_LONG'].mean()*100
        long_average_win_percent = df_trades_long[df_trades_long['RETURN_LONG']>0]['RETURN_LONG'].mean()*100
        long_average_loss_percent = df_trades_long[df_trades_long['RETURN_LONG']<0]['RETURN_LONG'].mean()*100
        long_best_trade_percent = df_trades_long[df_trades_long['RETURN_LONG']>0]['RETURN_LONG'].max() * 100
        long_worst_trade_percent = df_trades_long[df_trades_long['RETURN_LONG']<0]['RETURN_LONG'].min() * 100
        long_total_trades = df_trades_long['TRADE'].shape[0]

        # Organizando os resultados em um dicionário para criar o DatNãoaFrame
        Long_metrics_trade = {
            "Metric": ["Long Trade Winning %", "Long Average Trade %", "Long Average Win %", "Long Average Loss %",
                    "Long Best Trade %", "Long Worst Trade %","Long Total Trades"],
            "Result": [f"{long_trade_winning_percent:.2f}%", f"{long_average_trade_percent:.2f}%", f"{long_average_win_percent:.2f}%", f"{long_average_loss_percent:.2f}%",
                    f"{long_best_trade_percent:.2f}%", f"{long_worst_trade_percent:.2f}%",f"{long_total_trades:.0f}"]
        }

        # Convertendo para DataFrame
        df_trade_long = pd.DataFrame(Long_metrics_trade)

    if 'short' in strategy_type:
        # Calculando as métricas para a tabela "Trade_Short"
        df_trades_short = df_backtest[df_backtest['SIGNAL'] != df_backtest['SIGNAL'].shift(1)].copy()
        df_trades_short['RETURN_SHORT'] = np.where(df_trades_short['SIGNAL']==-1, ((df_trades_short['CLOSE']/df_trades_short['CLOSE'].shift(-1))-0.001)-1,0)
        df_trades_short = df_trades_short[df_trades_short['SIGNAL'] == -1]

        # trades_return_short =  df_trades_short['STRATEGY']
        # quantidade_trades_short = df_trades_short['TRADE'].sum()/2
        # total_return_short = df_trades_short['CUM_RET_STRAT_WITH_COST'].iloc[-1]-1
        # winning_trades_return_short = trades_return_short[trades_return_short > 0]
        # losing_trades_return_short = trades_return_short[trades_return_short < 0]

        # Calculando as métricas
        short_trade_winning_percent = df_trades_short[df_trades_short['RETURN_SHORT']>0].shape[0]/df_trades_short.shape[0] * 100 if df_trades_short.shape[0] > 0 else 0
        short_average_trade_percent = df_trades_short['RETURN_SHORT'].mean()*100
        short_average_win_percent = df_trades_short[df_trades_short['RETURN_SHORT']>0]['RETURN_SHORT'].mean()*100
        short_average_loss_percent = df_trades_short[df_trades_short['RETURN_SHORT']<0]['RETURN_SHORT'].mean()*100
        short_best_trade_percent = df_trades_short[df_trades_short['RETURN_SHORT']>0]['RETURN_SHORT'].max() * 100
        short_worst_trade_percent = df_trades_short[df_trades_short['RETURN_SHORT']<0]['RETURN_SHORT'].min() * 100
        # short_total_trades = total_trades-long_total_trades #
        short_total_trades = df_trades_short['TRADE'].shape[0]

        # Organizando os resultados em um dicionário para criar o DatNãoaFrame
        short_metrics_trade = {
            "Metric": ["Short Trade Winning %", "Short Average Trade %", "Short Average Win %", "Short Average Loss %",
                    "Short Best Trade %", "Short Worst Trade %","Short Total Trades"],
            "Result": [f"{short_trade_winning_percent:.2f}%", f"{short_average_trade_percent:.2f}%", f"{short_average_win_percent:.2f}%", f"{short_average_loss_percent:.2f}%",
                    f"{short_best_trade_percent:.2f}%", f"{short_worst_trade_percent:.2f}%",f"{short_total_trades:.0f}"]
        }

        # Convertendo para DataFrame
        df_trade_short = pd.DataFrame(short_metrics_trade)

    #### Calculando as métricas para a tabela "Time"

    # Definindo 'TIMESTAMP' como índice do DataFrame para realizar os cálculos
    df_backtest.set_index('TIMESTAMP', inplace=True)

    # Recalculando os retornos mensais e anuais
    monthly_cum_returns_time = df_backtest['CUM_RET_STRAT_WITH_COST'].resample('M').agg(['first', 'last'])
    monthly_returns_time = (monthly_cum_returns_time['last'] / monthly_cum_returns_time['first'] - 1) * 100

    yearly_cum_returns_time = df_backtest['CUM_RET_STRAT_WITH_COST'].resample('Y').agg(['first', 'last'])
    yearly_returns_time = (yearly_cum_returns_time['last'] / yearly_cum_returns_time['first'] - 1) * 100

    # Recalculando as métricas com os retornos corrigidos
    winning_months_time = monthly_returns_time[monthly_returns_time > 0]
    losing_months_time = monthly_returns_time[monthly_returns_time < 0]
    winning_months_percent_time = len(winning_months_time) / len(monthly_returns_time) * 100 if len(monthly_returns_time) > 0 else 0
    average_winning_months_percent_time = winning_months_time.mean() if len(winning_months_time) > 0 else 0
    average_losing_month_percent_time = losing_months_time.mean() if len(losing_months_time) > 0 else 0
    best_month_percent_time = monthly_returns_time.max()
    worst_month_percent_time = monthly_returns_time.min()

    winning_years_time = yearly_returns_time[yearly_returns_time > 0]
    winning_years_percent_time = len(winning_years_time) / len(yearly_returns_time) * 100 if len(yearly_returns_time) > 0 else 0
    best_year_percent_time = yearly_returns_time.max()
    worst_year_percent_time = yearly_returns_time.min()

    # Organizando os resultados corrigidos em um dicionário para criar o DataFrame
    metrics_time_corrected = {
        "Metric": ["Winning Months %", "Average Winning Months %", "Average Losing Month %",
                "Best Month %", "Worst Month %", "Winning Years %", "Best Year %", "Worst Year %"],
        "Result": [f"{winning_months_percent_time:.3f}%", f"{average_winning_months_percent_time:.3f}%", f"{average_losing_month_percent_time:.3f}%",
                f"{best_month_percent_time:.3f}%", f"{worst_month_percent_time:.3f}%", f"{winning_years_percent_time:.3f}%", f"{best_year_percent_time:.3f}%", f"{worst_year_percent_time:.3f}%"]
    }

    # Convertendo para DataFrame
    df_time_corrected = pd.DataFrame(metrics_time_corrected)
    if (strategy_type == 'long_and_short') or (strategy_type == 'long_or_short'):
        dfs = [df_curve_benchmark, df_time_corrected, df_trade, df_trade_long, df_trade_short]
        titles = ['Curve vs. Benchmark', 'Time', 'Trade', 'Trade Long', 'Trade Short']
    elif (strategy_type == 'long_only'):
        dfs = [df_curve_benchmark, df_time_corrected, df_trade_long]
        titles = ['Curve vs. Benchmark', 'Time', 'Trade Long']
    elif (strategy_type == 'short_only'):
        dfs = [df_curve_benchmark, df_time_corrected,  df_trade_short]
        titles = ['Curve vs. Benchmark', 'Time', 'Trade Short']
    else:
        raise ValueError("Strategy Type not Implemented!")

    # Configurando o layout do subplot principal
    fig = plt.figure(figsize=(24, 9), constrained_layout=True)
    gs_main = gridspec.GridSpec(2, 1, figure=fig)  # 2 linhas, 1 coluna para o layout principal

    # Configuração da primeira linha com 2 tabelas
    gs_row1 = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs_main[0], wspace=0.3)  # 1 linha, 2 colunas para a primeira linha
    for i in range(2):
        ax = fig.add_subplot(gs_row1[i])
        ax.axis('off')
        ax.set_title(titles[i], fontsize=25, fontweight='bold', pad=10)

        table = ax.table(cellText=dfs[i].values, colLabels=dfs[i].columns, cellLoc='center', loc='upper center')
        table.auto_set_font_size(False)
        table.set_fontsize(16.5)
        table.scale(1.82, 1.5)

        for key, cell in table.get_celld().items():
            if key[0] == 0:
                cell.set_text_props(fontweight='bold', color='white')
                cell.set_facecolor('blue')
            else:
                cell.set_linewidth(0)

    if (strategy_type == 'long_and_short') or (strategy_type == 'long_or_short'):

        # Configuração da segunda linha com 3 tabelas
        gs_row2 = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=gs_main[1], wspace=0.1)  # 1 linha, 3 colunas para a segunda linha
        for i in range(3):
            ax = fig.add_subplot(gs_row2[i])
            ax.axis('off')
            ax.set_title(titles[i + 2], fontsize=25, fontweight='bold', pad=10)

            table = ax.table(cellText=dfs[i + 2].values, colLabels=dfs[i + 2].columns, cellLoc='center', loc='upper center')
            table.auto_set_font_size(False)
            table.set_fontsize(16.5)
            table.scale(1.6, 1.5)

            for key, cell in table.get_celld().items():
                if key[0] == 0:
                    cell.set_text_props(fontweight='bold', color='white')
                    cell.set_facecolor('blue')
                else:
                    cell.set_linewidth(0)
    elif 'only' in strategy_type:

        # Configuração da segunda linha com 3 tabelas
        gs_row2 = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs_main[1], wspace=0.1)  # 1 linha, 3 colunas para a segunda linha
        for i in range(2):
            ax = fig.add_subplot(gs_row2[i])
            ax.axis('off')
            ax.set_title(titles[i + 1], fontsize=25, fontweight='bold', pad=10)

            table = ax.table(cellText=dfs[i + 1].values, colLabels=dfs[i + 1].columns, cellLoc='center', loc='upper center')
            table.auto_set_font_size(False)
            table.set_fontsize(16.5)
            table.scale(1.6, 1.5)

            for key, cell in table.get_celld().items():
                if key[0] == 0:
                    cell.set_text_props(fontweight='bold', color='white')
                    cell.set_facecolor('blue')
                else:
                    cell.set_linewidth(0)

    else:
        raise ValueError("Strategy Type not Implemented!")

    plt.show()


def plot_temporal_predict(df_bkt, model_type):
    # n_quantiles=1000
    plt.style.use("default")
    plt.figure(figsize=(16, 8))

    percentil = [0.01, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.50]
    if model_type=='clf':
        metric = "PROBABILITY"
    else:
        metric = "PREDICT"
    df_bkt[metric].plot(grid=True)
    for i in percentil:
        column_percentil_down = metric+"_"+str(i)
        column_percentil_up = metric+"_"+str(1-i)
        column_min = metric+"_MIN"
        column_max = metric+"_MAX"
        df_bkt[column_percentil_down] = df_bkt[metric].quantile(i)
        df_bkt[column_percentil_down].plot(label=f"Percentil Down - {i*100}%", lw=2, grid=True)

        df_bkt[column_percentil_up] = df_bkt[metric].quantile((1-i))
        df_bkt[column_percentil_up].plot(label=f"Percentil Up - {(1-i)*100}%", lw=2, grid=True)

    df_bkt[column_max].plot(label=f"{metric}_MAX", lw=5, grid=True)
    df_bkt[column_min].plot(label=f"{metric}_MIN", lw=5, grid=True)

    plt.ylabel("P(t)")
    plt.title(f'{metric} VS Time')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=8)
    plt.show()


def plot_histogram_predict(df_bkt, model_type):
    plt.figure(figsize=(16, 8))
    if model_type == 'clf':
        metric = "PROBABILITY"
    else:
        metric = "PREDICT"
    df_bkt[metric].plot(kind="hist", bins="fd", density=True, alpha=0.5, grid=True)
    plt.xlabel(metric)
    plt.title(f"{metric} HISTOGRAM")
    plt.show()


def plot_trades_return(df):

    df_trades_return = df.copy()
    df_trades_return = df_trades_return[df_trades_return['SIGNAL']!=df_trades_return['SIGNAL'].shift(1)][['CLOSE', 'SIGNAL']]
    df_trades_return['RETURN'] = np.where(df_trades_return['SIGNAL'] > 0,
                            df_trades_return['CLOSE'].shift(-1) / df_trades_return['CLOSE'] - 1,
                            np.where(df_trades_return['SIGNAL'] < 0,
                                    df_trades_return['CLOSE'] / df_trades_return['CLOSE'].shift(-1) - 1,
                                    0))*100

    # Assign colors based on 'RETURN' values
    colors = ['green' if x > 0 else 'red' for x in df_trades_return['RETURN']]

    plt.figure(figsize=(16, 5))
    # Creating the bar plot
    plt.bar(df_trades_return.index, df_trades_return['RETURN'], color=colors)
    plt.xlabel('Index')  # Assuming you want the index on the x-axis
    plt.ylabel('Return (%)')
    plt.title('Returns by Trade')
    plt.axhline(0, color='black', linewidth=1)

    # Display the plot
    plt.show()
