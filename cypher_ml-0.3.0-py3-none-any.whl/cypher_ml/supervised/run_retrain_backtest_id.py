import os
import time
import logging
import gc
# NOTE: It seems assynchronous use of cuda can rise error for BCE loss
# but a better investigation is necessary. If use BCE change cuda to
# synchronous cuda operations.
# os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
import pandas as pd
import numpy as np
import mlflow
from sklearn.preprocessing import OneHotEncoder
from trainer import Trainer
from tuner import Tuner
from utils import *
from constants import DataColums
from backtest import Backtest
from dashboard_backtest import *
from optimize_cutoff import *
from dlhandler import DeltaLakeHandler
from logger_config import setup_logger

DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR

LEVEL = DEBUG

logger = setup_logger(level=LEVEL)


def main():
    logger.info("Starting Retrain ...")

    # Get total number of CPUs
    app_name = "RunRetrain"
    total_cpus = os.cpu_count()

    # Azure Blob Storage account information
    storage_account_name = "dlcypherus"
    container_name = "silver"
    storage_account_key = "Eubzuzb612QyIQN9lS9FA17b2LpiJQ9+RQtJJhV0LJcLRlurgd+iEbvfQ6qNUJYPToTE5uXAc+CH+AStPSZiwA=="

    # Check if the directory already exists
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Create the Spark session with custom memory parameters
    logger.info("Starting spark session ...")
    spark = create_spark_session(app_name,
                                 total_cpus,
                                 storage_account_name,
                                 storage_account_key,
                                 executor_memory="8G",
                                 driver_memory="64G",
                                 max_result_size="32g")

    dl_handler = DeltaLakeHandler(spark)

    backtest_ids_list = ['']

    if not backtest_ids_list:
        raise ValueError("At least one backtest id should be provided!!!")

    logger.info(f"Running the btids: {backtest_ids_list}")

    bt_ids = backtest_ids_list                      # Set backtest ids (list)
    is_plot = False                                  # Plot dashboard
    is_retrain_deploy = False                       # Retrain from deploy
    is_save = False                                 # Save backtest
    bt_ids_start_date = "2024-09-03 00:00:00"
    bt_ids_end_date = "2024-12-31 23:59:59"

    if not is_retrain_deploy and not isinstance(bt_ids, list):
        raise ValueError("bt_ids should be a list of strings.")

    # Get backtest id from active strategies if backtest_id_train is empty
    if is_retrain_deploy:
        model_ids = dl_handler.get_model_ids_from_active_strategies(storage_account_name, env='sandbox') # default is sandbox

        bt_ids = dl_handler.get_backtest_ids_from_metadata_train_deploy(model_ids, storage_account_name)
        is_retrain_deploy = True
        # Load backtest id configuration from retrain
        logger.info("Loading table metadata_retrain")
        sdf_metadata_backtest = dl_handler.get_metadata_retrain(backtest_id_train, storage_account_name)
    else:
        # Load backtest id configuration from multi/single crypto
        logger.info("Loading table metadata_train")
        delta_table_path_meta_ret = "wasbs://gold@dlcypherus.blob.core.windows.net/metadata_train_v2"
        sdf_metadata_backtest = spark.read.format("delta").load(delta_table_path_meta_ret)

        logger.info(f"Filtering metadata_train by datetime [{bt_ids_start_date},{bt_ids_end_date}]")
        results_filters = (sdf_metadata_backtest['DATETIME'] >= bt_ids_start_date) & (sdf_metadata_backtest['DATETIME'] <= bt_ids_end_date)
        df_filtered = sdf_metadata_backtest.filter(results_filters)

    df_metadata_backtest = df_filtered.toPandas()

    ts_df_fund = time.time()
    logger.info("Processing df_funding ...")
    df_funding = read_funding_cost(spark,
                                   container_name,
                                   storage_account_name)
    logger.info(f"The df_funding computation spent: {time.time()-ts_df_fund}s")

    for bt_id in bt_ids:
        # Define backtest id to get metadata
        backtest_id_train = bt_id
        logger.info("Converting metadata_train filtered to pandas")

        try:
            # NOTE: If backtest id is the same, config is equal ? I think the only difference is the dataframes columns
            config_str = df_metadata_backtest[df_metadata_backtest['BACKTEST_ID'] == backtest_id_train].CONFIG
            config = json.loads(config_str.iloc[0])
        except Exception as error:
            logger.error(f"Config was not founded raising: {error}")
            continue

        if is_save:
            config['backtest']['is_save'] = is_save

        # Get basic configuration information
        ticker = config['backtest']['ticker']
        timeframe = config['backtest']['timeframe']
        position_size = config['backtest']['position_size']
        is_tune = config['info']['is_tune']
        model_name = config['info']['model_name']
        output_dir = config['info']['output_dir']
        framework = config['info']['framework']
        table_key = config['info']['table_key']
        is_multiclass = config['info']['is_multiclass']
        risk = config['info']['risk']
        pct_change_th = config['info']['pct_change_th']
        trust_factor = config['info']['trust_factor']
        model_type = config['info']['model_type']
        output_name = config['info']['output_name']
        optimize_method = config['info']['optimize_method']
        is_multi_crypto_df = config['info']['is_multi_crypto_df']
        is_one_crypto_feats = config['info']['is_one_crypto_feats']
        strategy_type = config['info']['strategy_type']
        is_checkpoint = config.get('checkpoint', None)

        if model_type == 'reg' and config['params'].get('class_weight') is not None:
            logger.info("Regression should not have class weight, removing it from config!!!")
            del config['params']['class_weight']

        if validate_timeframe(timeframe):
                indicator_table_name = f"full_indicators_{timeframe}"
                logger.info(f"Running table {indicator_table_name}")
        else:
            raise ValueError("Timeframe not valid!!!")


        # Check if timeframe is correct
        timeframe = process_timeframe(timeframe)

        # Get dataframe columns configuration
        SELECTION = config['info']['selection']
        TIMESTAMP = DataColums.TIMESTAMP
        START_TRAIN_DATE = DataColums.START_TRAIN_DATE
        END_TEST_DATE = DataColums.END_TEST_DATE
        END_TRAIN_DATE = DataColums.END_TRAIN_DATE
        TARGET = DataColums.TARGET
        DF_ = DataColums.DF_
        TIMEFRAME = DataColums.TIMEFRAME
        TICKER = DataColums.TICKER
        CLOSE = DataColums.CLOSE
        KEY = DataColums.KEY
        PROBLEM_TYPE = DataColums.PROBLEM_TYPE
        INGESTION_TIMESTAMP = DataColums.INGESTION_TIMESTAMP
        SCALE_INFO = DataColums.SCALE_INFO

        df_backtest = init_backtest()

        # Trainer and tuning
        if is_tune:
            tuner = Tuner(config)
        else:
            tuner = None

        probability = []
        list_of_kelly = []

        historical_metrics_all_dfs = pd.DataFrame()

        optim_methods = [optimize_method]

        cutoff_min = {method: [] for method in optim_methods}
        cutoff_max = {method: [] for method in optim_methods}

        logger.info("Loading table_meatadata_features...")
        sdf_metadata_features = dl_handler.read_table_with_spark(spark,
                                                                 container_name,
                                                                 storage_account_name,
                                                                 table_name='metadata_features')

        # Filter dataframe metadata info
        logger.info(f"Filtering meatadata_features by ticker:{ticker}, key:{table_key}, timeframe:{timeframe}, problem_type:{model_type}")
        criterion = (sdf_metadata_features[TICKER] == ticker) & \
                    (sdf_metadata_features[KEY] == table_key) & \
                    (sdf_metadata_features[TIMEFRAME] == timeframe) & \
                    (sdf_metadata_features[PROBLEM_TYPE] == model_type)

        sdf_meta_fea_fil = sdf_metadata_features.filter(criterion)

        if sdf_meta_fea_fil.isEmpty():
                logger.error("Metadata features returned empty after filtering. A common cause of" +
                               "this can be when bad combinations are generated. Moving to next combination... \n")
                continue

        logger.info("Converting/Sorting meatadata_features to pandas ...")
        pdf_meta_fea_fil_ord = sdf_meta_fea_fil.toPandas().sort_values(by=INGESTION_TIMESTAMP, ascending=True)

        # table_metadata_features_filtered = table_metadata_features.filter_by(ticker, timeframe, framework, model_type, feature_key)
        logger.info("Reading indicator table...")
        df_indicators = dl_handler.read_table_with_spark(spark,
                                                        container_name,
                                                        storage_account_name,
                                                        table_name=indicator_table_name,
                                                        folder_name='indicators_full')

        logger.info("Converting indicator table to pandas...")
        df_indicators = df_indicators.toPandas().sort_values(by=TIMESTAMP, ascending=True)

        df_indicators[TIMESTAMP] = pd.to_datetime(df_indicators[TIMESTAMP])

        n_dfs = len(pdf_meta_fea_fil_ord)
        df_end_idx = n_dfs-1

        close_column = f'CLOSE-{ticker}'

        # Create unique ids
        run_name_id = generate_alpha_numeric_key()
        backtest_id = generate_alpha_numeric_key()

        if is_retrain_deploy:
            logger.info(f"Old backtest_id_retrain:{backtest_id_train}")
            logger.info(f"New backtest_id_retrain:{backtest_id}")
        else:
            logger.info(f"Multicrypto backtest_id:{backtest_id_train}")
            logger.info(f"New backtest_id_retrain:{backtest_id}")

        # Start checkpoint from broken dataframe
        checkpoint_path = output_dir + output_name
        if os.path.exists(checkpoint_path):
            # Get start index of a given dataframe
            df_start_idx = int(output_name.split('.')[0].split('_')[2])
        else:
            df_start_idx = 0

        df_funding_filtered = filter_funding_cost(config, df_funding)

        logger.info("Processing dataframes ...")

        for i in range(df_start_idx, df_end_idx):
            df_id = DF_ + f"{i:03d}"

            logger.info(f'-------------------------DATAFRAME = {df_id}-------total = {n_dfs}----------------------------------------')

            logger.info("Filtering indicators by features metadata ...")
            # Filtering indicators by dataframe
            start_train_date = pdf_meta_fea_fil_ord.iloc[i][START_TRAIN_DATE]
            end_train_date = pdf_meta_fea_fil_ord.iloc[i][END_TRAIN_DATE]
            end_test_date = pdf_meta_fea_fil_ord.iloc[i][END_TEST_DATE]
            features = pdf_meta_fea_fil_ord.iloc[i][SELECTION]
            scaler_info = ast.literal_eval(pdf_meta_fea_fil_ord.iloc[i][SCALE_INFO])

            # Data slicing logic -> [start_train_date, end_test_date)
            df_ind = df_indicators[
                (df_indicators[TIMESTAMP] >= start_train_date) &
                (df_indicators[TIMESTAMP] < end_test_date) &
                (df_indicators[TIMEFRAME] == timeframe)].copy()

            # Add ticker
            df_ind[TICKER] = ticker

            if is_multi_crypto_df:
                df_ind[CLOSE] = df_ind[close_column]

            if model_type == 'reg':
                df_ind[TARGET] = (df_ind[CLOSE].shift(-1)/df_ind[CLOSE])-1
            else:
                df_ind[TARGET] = np.where(df_ind[CLOSE].shift(-1) > df_ind[CLOSE], 1, 0)

            ticker_close_0 = df_ind[CLOSE].iloc[0]

            if ticker_close_0 > 0:
                if is_multiclass:
                    df_ind['PERCENT_CHANGE'] = df_ind.CLOSE.pct_change().shift(-1)

                    # Apply classification to each row
                    df_ind[TARGET] = df_ind['PERCENT_CHANGE'].apply(classify_pct_change,
                                                                    args=(pct_change_th,
                                                                            trust_factor,
                                                                            risk))
                logger.info(f'Creating train and test dataset')
                X_train, X_test, y_train, y_test = windowing(df_ind,
                                                             features,
                                                             end_train_date,
                                                             end_test_date,
                                                             TIMESTAMP,
                                                             TARGET)

                logger.info(f'Scaling datasets.')
                X_train, X_test, _ = scaling(scaler_info, X_train, X_test)

                # Use only crypto features
                if is_one_crypto_feats:
                    cols = [col for col in df_ind.columns if ticker in col]
                    X_train = X_train[[cols]]
                    X_test = X_test[[cols]]

                if model_type == 'clf':
                    if framework == 'lgbm' or framework == 'torch':
                        class_weight = calculate_class_weight(y_train)
                        config['params']['class_weight'] = class_weight

                if framework == 'torch':
                    if CLOSE in X_train:
                        X_train[CLOSE] = 0.0
                        X_test[CLOSE] = 0.0

                    config['params']['input_size'] = len(X_train.columns)

                    if is_multiclass:
                        # Convert integer class labels into one-hot vectors for torch models
                        onehot_encoder = OneHotEncoder(sparse_output=False)  # Avoid sparse data structure
                        y_train = onehot_encoder.fit_transform(y_train.values.reshape(-1, 1))
                        y_test = onehot_encoder.fit_transform(y_test.values.reshape(-1, 1))

                df_timestamp = get_timestamp_data(df_ind, end_train_date, TIMESTAMP)

                if not os.path.exists(checkpoint_path):
                    run_name = f"{model_name}_{df_id}_{run_name_id}"
                else:
                    run_name = output_name.split('.')[0]
                    run_name_id = run_name.split('_')[-1]

                config['info']['output_name'] = run_name

                date_time = current_time().replace(" ", "-")
                log_name = f"./{log_dir}/{date_time}_{run_name}"
                config['info']['log_name'] = log_name

                if tuner:
                    tuner.run_name = run_name
                    best_parameter = tuner.fit(X_train, y_train)
                    logger.info(f"Best Parameters: {best_parameter}")
                    config['params'].update(best_parameter)

                    # Check if data type is supported by json
                    for k, v in config['params'].items():
                        # If not, cast to int32
                        if isinstance(v, np.int64):
                            config['params'][k] = int(v)

                with mlflow.start_run(run_name=run_name):
                    # turn off tuning flag to save best model
                    if is_tune:
                        config['info']['is_tune'] = False

                    # Train model
                    trainer = Trainer(config)
                    trainer.fit(X_train, y_train)
                    historical_metrics_all_dfs = pd.concat([historical_metrics_all_dfs,
                                                            trainer.strategy.historical_metrics_df],
                                                            ignore_index=True)

                    if framework in ["lgbm", "xgboost"]:
                        trainer = Trainer(config)
                        trainer.fit_final_model(X_train, y_train)

                    mlflow.end_run()

                    # reset flag to original value
                    config['info']['is_tune'] = is_tune

                    # Configure the global logger to save logs to a file
                    logger.debug(config)

                # Load best model
                best_model_path = output_dir + run_name
                if os.path.exists(best_model_path):
                    trainer.load(best_model_path)

                # Compute the signal for backtest
                logger.info("Generating test signal")
                signal = trainer.predict(X_test)

                if position_size == 'kelly_critery':
                    train_signal = trainer.predict(X_train).tolist()
                    kelly = df_kelly(df_ind, df_id, train_signal)
                    list_of_kelly.extend([kelly] * X_test.shape[0])

                logger.info("Extending probabilities")
                if model_type == 'clf':
                    if framework == 'torch':
                        probability.extend(trainer.predict_proba(X_test).tolist())
                    else:
                        probability.extend(trainer.predict_proba(X_test)[:, 1].tolist())

                logger.info("Creating backtest signal")
                df_timestamp = get_timestamp_data(df_ind, end_train_date, TIMESTAMP)
                df_signal = create_backtest_signal(df_timestamp, signal)

                # Align columns of df_signal with df_backtest
                logger.info("Reindexing signal to backtet")
                df_signal = df_signal.reindex(columns=df_backtest.columns, fill_value=0)

                # Create backtest outputs for each window data from best models
                df_backtest = pd.concat([df_backtest, df_signal])

                # Create the checkpoint path based on dfs of windowing
                if is_checkpoint:
                    output_name = f'{model_name}_{i+1}_{run_name_id}' + '.ckp'
                else:
                    if framework == 'torch':
                        output_name = f'{model_name}_{i+1}_{run_name_id}' + '.pt'
                    else:
                        output_name = f'{model_name}_{i+1}_{run_name_id}' + '.pkl'

                checkpoint_path = output_dir + output_name

                # Start time
                start_time = time.time()

                logger.info(f"Calculating optmize method {optimize_method}")
                cutoff_min, cutoff_max = reg_class_optimize_method(optim_methods,
                                                                   cutoff_min,
                                                                   cutoff_max,
                                                                   config,
                                                                   df_ind,
                                                                   X_train,
                                                                   trainer,
                                                                   framework,
                                                                   df_funding_filtered,
                                                                   model_type,
                                                                   X_test)

                # Calculate the total time spent
                time_spent = time.time() - start_time
                logger.info(f"Time spent optimize cuttoff: {time_spent} seconds")

        # Save model metadata
        if is_save:
            logger.info("Saving metadata retrain")
            dl_handler.save_metadata_retrain(df_start_idx,
                                             df_end_idx,
                                             backtest_id_train,
                                             backtest_id,
                                             config,
                                             storage_account_name)

        logger.info("Assign signal to predict column")
        if model_type == 'clf':
            df_backtest['PROBABILITY'] = probability
            df_backtest['PREDICT'] = 0
        else:
            df_backtest['PREDICT'] = df_backtest['SIGNAL']
            df_backtest['PROBABILITY'] = 0
            df_backtest['PROBABILITY_MIN'] = 0
            df_backtest['PROBABILITY_MAX'] = 0

        if position_size == 'kelly_critery':
            df_backtest['KELLY'] = list_of_kelly[0:df_backtest.shape[0]]

        logger.info("Generate signal based on cuttoffs")
        df_backtest = generate_signal(df_backtest,
                                      is_multiclass,
                                      risk,
                                      cutoff_min,
                                      cutoff_max,
                                      optimize_method,
                                      model_type)

        df_backtest = df_backtest.dropna()

        if position_size == 'kelly_critery':
            df_backtest['KELLY'] = list_of_kelly[0:df_backtest.shape[0]]

        # Shift data by one given that features represents (t) and the prediction (t+1)
        logger.info("Shifting predict signal to match with features")
        df_backtest_shifted = df_backtest.copy()
        df_backtest_shifted[DataColums.SIGNAL] = df_backtest_shifted[DataColums.SIGNAL].shift(1)
        df_backtest_shifted = df_backtest_shifted.dropna()

        # Get backtest information from configuration file
        logger.info("Calculating backtest")
        bkt_obj = Backtest(backtest_id,
                           df_backtest_shifted,
                           config,
                           df_funding_filtered,
                           storage_account_name,
                           is_save=is_save,
                           is_plot=is_plot)

        logger.info("Plotting metrics")
        if is_plot:
            df = bkt_obj.result_df_test_strategy

            run_dashboard(df, strategy_type)

            plot_temporal_predict(df, model_type)

            plot_histogram_predict(df, model_type)

            plot_trades_return(df)

            if model_type == 'clf':
                plot_train_metrics(historical_metrics_all_dfs)

        i += 1

        del bkt_obj, df_ind, X_train, X_test, historical_metrics_all_dfs, df_signal, df_backtest
        gc.collect()

    logger.info("----------Retrain finished !!!----------")


if __name__ == "__main__":
    main()
