import os
import json
import joblib
import logging
from abc import ABC, abstractmethod
from typing import Any, List, Union, Optional
from copy import deepcopy
from contextlib import contextmanager

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import mlflow
import xgboost
import lightgbm

from torch.utils.data import DataLoader
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score,
                             roc_auc_score,
                             precision_score,
                             recall_score,
                             confusion_matrix,
                             f1_score,
                             r2_score,
                             log_loss)

from mlflow.models.signature import infer_signature
from sklearn.model_selection import train_test_split, TimeSeriesSplit
from dataset import *
from models.transformer_encoder import *
from models.xgboost import *
from models.lgbm import *
from models.random_forest import *
from models.logistic_regression import *
from models.lstm import *
from constants import CypherModel, CypherTrainer

logger = logging.getLogger('logger')


class BasicTrainer(ABC):
    """
    BasicTrainer is an abstract base class that defines a standard interface for model trainers.

    Methods to be implemented:
        fit: Fit the model to the training data.
        predict: Predict using the model on given data.
        save: Save the model to a specified file path.
        load: Load the model from a specified file path.
    """
    @abstractmethod
    def __init__(self):
        """Initialize the trainer."""
        raise NotImplementedError

    @abstractmethod
    def fit(self, X: Any, y: Any):
        """
        Fit the model to the training data.

        Parameters:
            X (Any): The input data to fit.
            y (Any): The target labels or values to fit against.
        """
        raise NotImplementedError

    @abstractmethod
    def predict(self, X: Any) -> Any:
        """
        Predict using the model on the provided data.

        Parameters:
            X (Any): The input data for making predictions.

        Returns:
            Any: The predicted values or labels.
        """
        raise NotImplementedError

    @abstractmethod
    def save(self):
        """
        Save the model to the specified file path.

        Parameters:
            file_path (str): The path to save the model file.
        """
        raise NotImplementedError

    @abstractmethod
    def load(self, file_path: str):
        """
        Load the model from the specified file path.

        Parameters:
            file_path (str): The path to load the model file from.
        """
        raise NotImplementedError


class Basic(BasicTrainer):
    def __init__(self, config):
        self.config = config

    def _extract_metrics(self, metrics):
        _metrics = {}
        for metric in metrics:
            for key, value in metric.items():
                _metrics[key] = value

        return _metrics

    def _set_save_criteria_flags(self):
        # Select flag combination based on the save criteria
        if self.save_criteria == 'all':
            self.is_tune = True
            self.is_upload = True
        elif self.save_criteria == 'best':
            self.is_upload = not self.is_tune
        elif self.save_criteria == 'none':
            self.is_tune = False
            self.is_upload = False
        else:
            raise Exception("The save criteria choosed was not implemented!")

    def _build_metrics(self, y_true: np.ndarray, pred: np.ndarray) -> dict:
        """
        Calculates and returns a dictionary of metrics based on the model type.

        Parameters:
            y_true: The true labels or values.
            pred: The predicted labels or values from the model.

        Returns:
            dict: A dictionary containing the calculated metrics.

        Raises:
            ValueError: If the model type is neither 'clf' (classification) nor 'reg' (regression).

        Note:
            Ensure that self.model_type is defined as either 'clf' for classification or 'reg' for regression.
        """
        metrics = {}
        # Classification metrics
        if self.model_type == 'clf':
            # Compute various classification metrics and store them in the dictionary
            metrics['accuracy'] = accuracy_score(y_true, pred)
            metrics['precision'] = precision_score(y_true, pred, average="macro", zero_division=0)
            metrics['recall'] = recall_score(y_true, pred, average="macro", zero_division=0)
            metrics['fscore'] = f1_score(y_true, pred, average="macro", zero_division=0)
            metrics['precision_by_class'] = precision_score(y_true, pred, average=None, zero_division=0)
            metrics['recall_by_class'] = recall_score(y_true, pred, average=None, zero_division=0)
            metrics['fscore_by_class'] = f1_score(y_true, pred, average=None, zero_division=0)

            # Only for binary problems
            if not self.is_multiclass:
                metrics['auc'] = roc_auc_score(y_true, pred)  # AUC might require probability estimates

            metrics['cm'] = confusion_matrix(y_true, pred)
        # Regression metrics
        elif self.model_type == 'reg':
            # Compute the regression metric and store it in the dictionary
            metrics['r2'] = r2_score(y_true, pred)
        else:
            # Handling unsupported model types
            raise ValueError("[ERROR] Metric not implemented!")

        return metrics

    def _print_metrics_and_losses(self,
                                  avg_train_loss: float,
                                  avg_val_loss: float,
                                  metrics: dict) -> None:
        """
        Logs losses and calculated metrics based on the model type.

        Parameters:
            avg_train_loss: Average training loss.
            avg_val_loss: Average validation loss.
            metrics: Dictionary with clf or reg metrics
        """
        for idx, metric in enumerate(metrics):
            if idx == 0:
                logger.info('--------------------TRAIN--------------------')
            else:
                logger.info('--------------------VALID--------------------')

            # Log metrics based on model type
            if self.model_type == 'clf':
                logger.info(f"Accuracy: {metric['accuracy']:.4f}, "
                                f"Precision: {metric['precision']:.4f}, "
                                f"Recall: {metric['recall']:.4f}, "
                                f"F1-Score: {metric['fscore']:.4f}")
                if 'auc' in metric:
                    logger.info(f"AUC: {metric['auc']:.4f}")
                logger.info(f"Confusion Matrix:\n{metric['cm']}")
            elif self.model_type == 'reg':
                logger.info(f"R2 Score: {metric['r2']:.4f}")
            else:
                logger.info("[ERROR] Unsupported model type!")

        logger.info(f"loss (avg): {avg_train_loss:.8f} (train), {avg_val_loss:.8f} (val)")

    def _compute_positive_weight(self, y_train: np.ndarray) -> torch.Tensor:
        """
        Compute the weight for the positive class to address class imbalance.

        This function calculates the ratio of the number of negative samples to the number of positive samples
        in the training data. This weight can be used to balance the loss function during training.

        Parameters:
        - y_train (np.ndarray): The array of ground truth labels for the training data.

        Returns:
        - torch.Tensor: A tensor containing the single value of the positive class weight,
                        moved to the same device as the model.
        """
        # Count the occurrences of each class in the training data
        unique, counts = np.unique(y_train, return_counts=True)
        class_counts = dict(zip(unique, counts))

        # Ensure counts for both classes are retrieved, defaulting to 0 if a class is missing
        # NOTE: This only only work for binary classes
        count_class_0 = class_counts.get(0, 0)
        count_class_1 = class_counts.get(1, 0)

        # Calculate the ratio of negative to positive samples as the positive weight
        # Avoid division by zero by adding a small epsilon to the denominator
        epsilon = 1e-6
        pos_weight = (count_class_0 / (count_class_1 + epsilon))

        return pos_weight

    def _log_model_framework(self, signature):
        if self.framework == CypherTrainer.SKLEARN:
            if hasattr(self.model, 'clf'):
                mlflow.sklearn.log_model(self.model.clf, self.model_name, signature=signature)
            elif hasattr(self.model, 'reg'):
                mlflow.sklearn.log_model(self.model.reg, self.model_name, signature=signature)
            else:
                raise ValueError("Unsupported model type, this version only supports clf or reg")
        elif self.framework == CypherTrainer.XGBOOST:
            if hasattr(self.model, 'clf'):
                mlflow.xgboost.log_model(self.model.clf, self.model_name, signature=signature)
            elif hasattr(self.model, 'reg'):
                mlflow.xgboost.log_model(self.model.reg, self.model_name, signature=signature)
            else:
                raise ValueError("Unsupported model type, this version only supports clf or reg")
        elif self.framework == CypherTrainer.LGBM:
            if hasattr(self.model, 'clf'):
                mlflow.lightgbm.log_model(self.model.clf, self.model_name, signature=signature)
            elif hasattr(self.model, 'reg'):
                mlflow.lightgbm.log_model(self.model.reg, self.model_name, signature=signature)
            else:
                raise ValueError("Unsupported model type, this version only supports clf or reg")
        elif self.framework == CypherTrainer.TORCH:
            mlflow.pytorch.log_model(self.model, self.model_name, signature=signature)
        # Add more frameworks here as needed
        else:
            raise ValueError(f"Unsupported framework: {self.framework}")

    def _mkdir(self, folder_path):
        # Check if output folder exist
        if not os.path.exists(folder_path):
            logger.info(f"Folder '{folder_path}' created.")
            os.makedirs(folder_path)

    def log_mlflow(self,
                   X_train,
                   X_val,
                   y_val,
                   avg_val_loss,
                   best_val_loss,
                   train_loss,
                   val_loss):

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            if not self.is_deploy:
                if self.is_tune:
                    # save all
                    if self.is_upload:
                        # Save model
                        signature = infer_signature(X_train, self.predict(X_train))
                        self._log_model_framework(signature)

                        # Save loss metrics
                        for step, (t_loss, v_loss) in enumerate(zip(train_loss, val_loss)):
                            mlflow.log_metric("train_loss", t_loss, step=step)
                            mlflow.log_metric("val_loss", v_loss, step=step)

                        # Save track metrics
                        metrics = self.evaluate(X_val, y_val)
                        if metrics:
                            for key, val in metrics.items():
                                if key in self.config['track'].keys():
                                    mlflow.log_metric(key, val)

                        # Save parameters
                        for key, val in self.config['params'].items():
                            mlflow.log_param(key, val)

                        # Save model locally
                        self.save()
                else:
                    # save only best
                    if self.is_upload:
                        # Save model
                        signature = infer_signature(X_train, self.predict(X_train))
                        self._log_model_framework(signature)

                        # Save loss metrics
                        for step, (t_loss, v_loss) in enumerate(zip(train_loss, val_loss)):
                            mlflow.log_metric("train_loss", t_loss, step=step)
                            mlflow.log_metric("val_loss", v_loss, step=step)

                        # Save track metrics
                        metrics = self.evaluate(X_val, y_val)
                        if metrics:
                            for key, val in metrics.items():
                                if key in self.config['track'].keys():
                                    mlflow.log_metric(key, val)

                        # Save parameters
                        for key, val in self.config['params'].items():
                            mlflow.log_param(key, val)

                        # Save model locally (repo) or storage
                        self.save()

        return best_val_loss

    def save(self) -> None:
        # Check if data type is supported by json
        for k, v in self.config['params'].items():
            # If not, cast to int32
            if isinstance(v, np.int64):
                self.config['params'][k] = int(v)

        # Save configuration parameters if not tuning
        if not self.is_tune:
            # Specify the file path where you want to save the JSON file
            file_path = self.output_dir + self.output_name.split('.')[0] + "_all_parameters.json"

            # Open the file in write mode and save the dictionary as JSON
            with open(file_path, "w") as json_file:
                json.dump(self.config, json_file)

            logger.info(f"All parameters used in this train were saved as JSON in '{file_path}'")

        # Implement saving logic
        if self.model is not None:
            file_path = self.output_dir + self.output_name.split('.')[0] + ".pkl"
            joblib.dump(self.model, file_path)
            logger.info(f"The model was saved as pkl in '{file_path}'")

        else:
            raise Exception("No model to save. Train the model first.")

    def load(self, file_path: str) -> None:
        """
        Loads a model from the specified file path.

        Args:
            file_path (str): Path from which to load the model.
        """
        # Implement loading logic
        file_path = file_path + '.pkl'
        self.model = joblib.load(file_path)

    def hyper_opt_functions(self, X_val, best_val_loss):

        val_signal = self.predict(X_val).tolist()

        data = {
            'CLOSE': X_val['CLOSE'],
            'SIGNAL': val_signal
        }

        # Create the DataFrame
        df = pd.DataFrame(data)
        df = df.reset_index(drop=True)
        df['SIGNAL'] = df['SIGNAL'].shift(1)
        df['RETURN'] = (df['CLOSE']/df['CLOSE'].shift(1))-1

        if self.config['info']['strategy_type'] == 'long_and_short':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
        elif self.config['info']['strategy_type'] == 'long_only':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == -1 else x)
        elif self.config['info']['strategy_type'] == 'short_only':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == 1 else x)
        elif self.config['info']['strategy_type'] == 'long_or_short':
            pass
        else:
            raise ValueError("Setup a valid strategy: 'long_or_short', 'long_only', 'short_only', 'long_and_short'")

        df.fillna(method='ffill', inplace=True)
        df.dropna(inplace=True)

        # Calculating strategy performance
        df["strategy"] = df['SIGNAL'] * df["RETURN"]
        # Cumulative returns and drawdown calculation
        df["cummul_returns_strat"] = (df["strategy"]+1).cumprod()
        df["drawdown"] = (df["cummul_returns_strat"].cummax() - df["cummul_returns_strat"]) / df["cummul_returns_strat"].cummax()
        df["max_drawdown"] = df["drawdown"].cummax()

        cumm_ret = df['cummul_returns_strat'].tail(1).iloc[0]
        cumm_ret_drawdown = cumm_ret / df['max_drawdown'].tail(1).iloc[0]

        if self.config['tune']['tune_loss_function'] == 'cumm_ret_drawdown':
            loss_function = -cumm_ret_drawdown
        elif self.config['tune']['tune_loss_function'] == 'cumm_return':
            loss_function = -cumm_ret
        else:
            pass

        if loss_function < best_val_loss:
            best_val_loss = loss_function

            if not self.is_deploy:
                if self.is_upload or self.is_tune:
                    self.save()

        return best_val_loss

    def cummulative_return_loss_function(self, X_val):
        val_signal = self.predict(X_val).tolist()

        data = {
            'CLOSE': X_val['CLOSE'],
            'SIGNAL': val_signal
        }

        # Create the DataFrame
        df = pd.DataFrame(data)
        df = df.reset_index(drop=True)
        df['SIGNAL'] = df['SIGNAL'].shift(1)
        df['RETURN'] = (df['CLOSE']/df['CLOSE'].shift(1))-1

        if self.config['info']['strategy_type'] == 'long_and_short':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
        elif self.config['info']['strategy_type'] == 'long_only':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == -1 else x)
        elif self.config['info']['strategy_type'] == 'short_only':
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
            df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == 1 else x)
        elif self.config['info']['strategy_type'] == 'long_or_short':
            pass
        else:
            raise ValueError("Setup a valid strategy: 'long_or_short', 'long_only', 'short_only', 'long_and_short'")

        df.fillna(method='ffill', inplace=True)
        df.dropna(inplace=True)

        # Calculating strategy performance
        df["strategy"] = df['SIGNAL'] * df["RETURN"]
        # Cumulative returns and drawdown calculation
        df["cummul_returns_strat"] = (df["strategy"]+1).cumprod()
        df["drawdown"] = (df["cummul_returns_strat"].cummax() - df["cummul_returns_strat"]) / df["cummul_returns_strat"].cummax()
        df["max_drawdown"] = df["drawdown"].cummax()

        cumm_ret = df['cummul_returns_strat'].tail(1).iloc[0]
        cumm_ret_drawdown = cumm_ret / df['max_drawdown'].tail(1).iloc[0]

        if self.config['tune']['tune_loss_function'] == 'cumm_ret_drawdown':
            loss_function = -cumm_ret_drawdown
        elif self.config['tune']['tune_loss_function'] == 'cumm_return':
            loss_function = -cumm_ret
        else:
            pass

        if not self.is_deploy:
            if self.is_upload or self.is_tune:
                self.save()

        return loss_function

    def cummulative_return_loss_function_cv(self, X_val_list, models_list):
        loss_functions = []  # Initialize an empty list to store loss_function values

        for X_val, model in zip(X_val_list, models_list):
            if self.model_type == 'clf':
                val_signal = model.clf.predict(X_val).tolist()
            else:
                val_signal = model.reg.predict(X_val).tolist()

            data = {
                'CLOSE': X_val['CLOSE'],
                'SIGNAL': val_signal
            }

            # Create the DataFrame
            df = pd.DataFrame(data)
            df = df.reset_index(drop=True)
            df['SIGNAL'] = df['SIGNAL'].shift(1)
            df['RETURN'] = (df['CLOSE']/df['CLOSE'].shift(1))-1

            strategy_type = self.config['info']['strategy_type']
            if strategy_type == 'long_and_short':
                df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
            elif strategy_type == 'long_only':
                df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == -1 else x)
            elif strategy_type == 'short_only':
                df['SIGNAL'] = df['SIGNAL'].apply(lambda x: -1 if x == 0 else x)
                df['SIGNAL'] = df['SIGNAL'].apply(lambda x: 0 if x == 1 else x)
            elif strategy_type == 'long_or_short':
                pass
            else:
                raise ValueError("Setup a valid strategy: 'long_or_short', 'long_only', 'short_only', 'long_and_short'")

            df.fillna(method='ffill', inplace=True)
            df.dropna(inplace=True)

            # Calculating strategy performance
            df["strategy"] = df['SIGNAL'] * df["RETURN"]
            df["cummul_returns_strat"] = (df["strategy"]+1).cumprod()
            df["drawdown"] = (df["cummul_returns_strat"].cummax() - df["cummul_returns_strat"]) / df["cummul_returns_strat"].cummax()
            df["max_drawdown"] = df["drawdown"].cummax()

            cumm_ret = df['cummul_returns_strat'].tail(1).iloc[0]
            cumm_ret_drawdown = cumm_ret / df['max_drawdown'].tail(1).iloc[0]

            tune_loss_function = self.config['tune']['tune_loss_function']
            if tune_loss_function == 'cumm_ret_drawdown':
                loss_function = -cumm_ret_drawdown
            elif tune_loss_function == 'cumm_return':
                loss_function = -cumm_ret
            else:
                loss_function = 0

            loss_functions.append(loss_function)

        avg_loss_function = np.mean(loss_functions) if loss_functions else 0

        return avg_loss_function

    @contextmanager
    def temporary_model(self, new_model):
        original_model = deepcopy(self.model)
        self.model = new_model
        try:
            yield  # run evaluation metrics
        finally:
            self.model = original_model


class PyTorchTrainer(Basic):
    """
    Trainer class for training models using PyTorch.

    Attributes:
        config (dict): Configuration parameters for training.
        model_type (str): Type of the model ('clf' for classifier, 'reg' for regressor).
        output_dir (str): Directory for saving output files.
        is_tune (bool): Flag to indicate if tuning is being performed.
        output_name (str): Name of the output file for saving the model.
        model (nn.Module): PyTorch model to be trained.
        device (str): Device to run the model on ('cuda' or 'cpu').
        dataset (str): Name of the dataset being used.
        batch_size (int): Batch size for training.
        shuffle (bool): Whether to shuffle the data.
        num_workers (int): Number of workers for data loading.
        epochs (int): Number of training epochs.
        lr (float): Learning rate.
        l2_reg (float): L2 regularization factor.
        scheduler_name (str): Name of the learning rate scheduler.
        criterion (nn.Module): Loss criterion.
        optimizer (optim.Optimizer): Optimizer for training.
        scheduler (optim.lr_scheduler): Learning rate scheduler.
    """
    def __init__(self,
                 model: nn.Module,
                 config: dict):
        """
        Initializes the PyTorchTrainer with the given arguments, model, and configuration.

        Parameters:
            model (nn.Module): PyTorch model to be trained.
            config (dict): Configuration parameters for training.
        """
        # Set seed for reproducibility
        seed = config['params']['seed']  # Default seed is 42 if not specified
        torch.manual_seed(seed)
        np.random.seed(seed)

        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        # Set basic configuration
        self.config = config
        self.model = model

        self.output_dir = config['info']['output_dir']
        self.is_tune = config['info']['is_tune']
        self.save_criteria = config['info']['save_criteria']
        self.output_name = config['info']['output_name']
        self.checkpoint_path = self.output_dir + self.output_name.split('.')[0] + "_ckp.pt"
        self.model_type = config['info']['model_type']
        self.is_unbalanced = config['info']['is_unbalanced']
        self.is_cross_validation = config['info']['is_cross_validation']
        self.n_splits = config['info']['n_splits']
        self.model_name = config['info']['model_name']
        self.framework = config['info']['framework']
        self.is_multiclass = config['info']['is_multiclass']
        self.is_deploy = config['info']['is_deploy']
        self.class_weights = config['params']['class_weight']
        self.early_stopping_rounds = config['info']['early_stopping_rounds']

        if self.is_deploy:
            self.log_name = None
        else:
            self.log_name = config['info']['log_name']

        self.is_block_cv = config['info']['is_block_cv']
        self.tune_loss_function = config['tune']['tune_loss_function']

        self._set_save_criteria_flags()
        self.historical_metrics = {}

        # Set to device
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model.to(self.device)

        # Get loader configuration
        config_params = config['params']

        # Dataloader
        self.dataset = config_params['dataset']
        self.batch_size = config_params['batch_size']
        self.shuffle = config_params['shuffle']
        self.num_workers = config_params['num_workers']
        self.timestep = config_params['timestep']

        # Train
        self.epochs = config_params['epochs']
        self.lr = config_params['learning_rate']
        self.l2_reg = config_params['l2_reg']
        self.scheduler_name = config_params['scheduler_name']
        self.wait = config_params['wait']
        self.checkpoint_steps = config_params['checkpoint_steps']
        self.print_freq = config_params['print_freq']

        if self.scheduler_name == 'step':
            self.step_size = config_params['step_size']
            self.gamma = config_params['gamma']
        elif self.scheduler_name == 'reduce':
            self.lr_patience_decay = config_params['lr_patience_decay']
        else:
            raise ValueError("Scheduler not implemented.")

        # Criterion
        self.loss_name = config_params['loss_name']
        self.criterion = self._build_criterion()

        # Optimizer
        self.opt_name = config_params['opt_name']
        self.optimizer = self._build_optimizer()

        # Scheduler
        self.scheduler = self._build_scheduler()

        if not self.is_deploy:
            self._mkdir(self.output_dir)

        # Point to checkpoint model
        self.is_checkpoint = config['info']['is_checkpoint']
        if self.is_checkpoint and self.is_tune:
            raise ValueError("Checkpoint and tune can not be used together.")
        elif self.is_checkpoint and not self.is_tune:
            # Check if checkpoint file exist
            if os.path.exists(self.checkpoint_path):
                self._load_checkpoint()
            else:
                logger.info(f"No checkpoint file founded in '{self.checkpoint_path}' folder, new training will start.")
                self.is_checkpoint = False
        else:
            logger.info("Starting pytorch model without checkpoint.")

    def _batch_generator(self, data: np.ndarray, batch_size: int) -> np.ndarray:
        """
        Generates batches of data.

        Parameters:
            data (np.ndarray): The dataset to be batched.
            batch_size (int): The size of each batch.

        Yields:
            np.ndarray: An iterator over batches of the dataset (lazy load).
        """
        for i in range(0, len(data), batch_size):
            yield data[i:i + batch_size]

    def _build_criterion(self) -> nn.modules.loss._Loss:
        """
        Constructs and returns a PyTorch loss function based on the provided loss name.

        Loss function to use. Supported values are 'bce' for Binary Cross Entropy,
        'mse' for Mean Squared Error, 'huber' for Huber Loss and 'bce_logit' for
        Binary Cross Entropy logit loss.

        Returns:
            nn.modules.loss._Loss: The corresponding PyTorch loss function.

        Raises:
            ValueError: If the loss_name is not recognized (i.e., not implemented).
        """
        # Selecting the loss function based on the loss_name argument
        if self.loss_name == 'bce':
            return nn.BCELoss()  # Binary classification
        elif self.loss_name == 'mse':
            return nn.MSELoss()   # Classification or Regression
        elif self.loss_name == 'huber':
            return torch.nn.HuberLoss()   # Classification or Regression
        elif self.loss_name == "bce_logit":
            return nn.BCEWithLogitsLoss()  # Binary classification
        elif self.loss_name == "cross_entropy":
            max_class = max(self.class_weights.keys())
            weights_tensor = torch.zeros(max_class + 1, dtype=torch.float32).to(self.device)
            for k, v in self.class_weights.items():
                weights_tensor[k] = v
            return nn.CrossEntropyLoss(weight=weights_tensor)
        else:
            # Error handling for unrecognized loss function
            raise ValueError(f"[ERROR] Loss {self.loss_name} not implemented.")

    def _build_dataloader(self,
                          X: np.ndarray,
                          y: Optional[np.ndarray] = None) -> DataLoader:
        """
        Builds a dataloader for the dataset.

        Parameters:
            X (np.ndarray): The input features for the model.
            y Optional[np.ndarray]: The target labels (values) for the model. If `None`, only `X` will be used,
            suitable for prediction.
            mode (str): The mode of operation, either 'train' or 'eval' to handle X and y; 'prediction' to
            handle only X.

        Returns:
            DataLoader: The constructed data loader.

        Raises:
            ValueError: If the mode is not 'train' or 'test', or if the dataset type is unknown.
        """
        # DataLoader configuration
        if y is not None:
            # Dataset selection
            if self.dataset == 'simple':
                dataset = Simple(X, y)  # Static preprocessed lag
            elif self.dataset == 'timeseries':
                dataset = TimeSeries(X, y, self.timestep)  # Static preprocessed lag with dynamic option
            else:
                raise ValueError("[ERROR] This dataset was not implemented.")

            # Typically, shuffle is False for train/test/validation loader for time series but it can be
            # applied to features such sentiment analysis
            loader = DataLoader(dataset=dataset,
                                batch_size=self.batch_size,
                                shuffle=self.shuffle,
                                num_workers=self.num_workers)
        else:
            # Dataset selection
            if self.dataset == 'simple':
                dataset = SimplePrediction(X)  # Static preprocessed lag
            elif self.dataset == 'timeseries':
                dataset = TimeSeriesPrediction(X, self.timestep)  # Pre processed with inloco lag
            else:
                raise ValueError("[ERROR] This dataset was not implemented.")

            loader = DataLoader(dataset=dataset,
                                batch_size=1,  # It seems that prediction will always be one sample at time
                                shuffle=False,
                                num_workers=self.num_workers)

        return loader

    def _build_optimizer(self) -> optim.Optimizer:
        """
        Creates and returns a PyTorch optimizer for the model based on the provided optimizer name.

        Supported optimizers are 'sgd', 'adam', 'adadelta', 'rms', and 'adagrad'.

        Returns:
            optim.Optimizer: The constructed optimizer for the model.

        Raises:
            ValueError: If the opt_name is not recognized (i.e., not implemented).

        Note:
            Ensure self.model, self.lr, and self.l2_reg are defined with the appropriate values
            before calling this function.
        """
        # Creating the optimizer based on the opt_name argument
        if self.opt_name == 'sgd':
            return optim.SGD(self.model.parameters(), lr=self.lr, weight_decay=self.l2_reg)
        elif self.opt_name == 'adam':
            return optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.l2_reg)
        elif self.opt_name == 'adadelta':
            return optim.Adadelta(self.model.parameters(), lr=self.lr, weight_decay=self.l2_reg)
        elif self.opt_name == 'rms':
            return optim.RMSprop(self.model.parameters(), lr=self.lr, weight_decay=self.l2_reg)
        elif self.opt_name == 'adagrad':
            return optim.Adagrad(self.model.parameters(), lr=self.lr, weight_decay=self.l2_reg)
        else:
            # Creating the optimizer based on the opt_name argument
            raise ValueError(f"[ERROR] Optimizer {self.opt_name} not implemented!")

    def _build_scheduler(self,
                         mode: str = 'min',
                         verbose: bool = True,
                         factor: float = 0.2) -> optim.lr_scheduler._LRScheduler:
        """
        Creates and returns a learning rate scheduler based on the specified parameters.
        This scheduler adjusts the learning rate based on the evolution of a metric during
        training, which can help in optimizing the training process by reducing the learning
        rate when a metric has stopped improving.

        Parameters:
        -----------
        mode (str, optional): Specifies the condition for reducing the learning rate.
            'min' indicates that the learning rate will be reduced when the monitored metric
            stops decreasing; 'max' indicates reduction when the monitored metric stops increasing.
            Default is 'min'.

        verbose (bool, optional): If True, prints a message to stdout for each update of the
            learning rate. Default is True.

        factor (float, optional): Factor by which the learning rate will be reduced.
            new_lr = lr * factor. Default is 0.2.

        Returns:
        --------
        optim.lr_scheduler._LRScheduler: An instance of a learning rate scheduler.

        Example:
        --------
        # Assuming `self.optimizer` is an initialized optimizer for a model
        scheduler = self._build_scheduler(mode='min', verbose=True, factor=0.1)
        # This scheduler can then be used during model training to adjust the learning rate
        """
        # Creating the scheduler based on the scheduler_name argument
        if self.scheduler_name == 'step':
            # StepLR decays the learning rate of each parameter group by gamma every step_size epochs
            return optim.lr_scheduler.StepLR(optimizer=self.optimizer,
                                             step_size=self.step_size,
                                             gamma=self.gamma)
        elif self.scheduler_name == 'reduce':
            # ReduceLROnPlateau reduces learning rate when a metric has stopped improving
            return optim.lr_scheduler.ReduceLROnPlateau(
                optimizer=self.optimizer,
                mode=mode,
                patience=self.lr_patience_decay,  # number of epochs with no improvement after which learning rate will be reduced
                verbose=verbose,  # if True, prints a message to stdout for each update
                factor=factor)  # factor by which the learning rate will be reduced: new_lr = lr * factor
        else:
            # Handling unsupported scheduler names
            raise ValueError(f"[ERROR] Scheduler {self.scheduler_name} not implemented!")

    def _train_one_epoch(self,
                         model,
                         loader: DataLoader,
                         criterion: nn.Module,
                         optimizer: optim.Optimizer) -> List[float]:
        """
        Trains the model for one epoch.

        Parameters:
            loader (DataLoader): DataLoader for the training data.
            criterion (nn.Module): Loss criterion to be used.
            optimizer (optim.Optimizer): Optimizer for the training.

        Returns:
            List[float]: List of loss values for each batch in the epoch.
        """
        run_loss = []  # Initialize a list to keep track of loss values
        size = len(loader.dataset)  # Total size of the dataset
        model.train()  # Set the model to training mode

        # Iterate over the DataLoader for training data
        for B, (X, y) in enumerate(loader):
            # Move the input and target data to the same device as the model
            src, tgt = X.to(self.device), y.to(self.device)

            # Zero the gradients before running the backward pass.
            optimizer.zero_grad()

            # Forward pass: Compute predicted y by passing X to the model
            pred = model(src)

            # Compute and print loss
            loss = criterion(pred, tgt)

            # Backward pass: compute gradient of the loss with respect to model parameters
            loss.backward()

            # If tuning is enabled, clip gradients to help stabilize training
            if self.is_tune:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

            # Calling the step function on an Optimizer makes an update to its parameters
            optimizer.step()

            # Print loss every 100 batches
            if B % self.print_freq == 0:
                loss, current = loss.item(), (B + 1) * len(X)
                logger.info(f"loss: {loss:>7f} [{current:>5d}/{size:>5d}]")

            # Append the loss to the list of losses for this epoch
            run_loss.append(loss)  # Ensure to call loss.item() to get the scalar value

        return run_loss

    def _val_one_epoch(self,
                       model,
                       loader: DataLoader,
                       criterion: nn.Module) -> List[float]:
        """
        Validates the model for one epoch, running it against a validation set.

        Parameters:
            loader (DataLoader): DataLoader for the validation data.
            criterion (nn.Module): Loss criterion to evaluate loss.

        Returns:
            List[float]: List of loss values for each batch in the validation set.
        """

        run_loss = []  # List to store loss for each batch

        model.eval()  # Set the model to evaluation mode
        # No gradient calculations needed for validation
        with torch.no_grad():  # Temporarily set all gradients to be disable
            for X, y in loader:
                # Move the input and target validation data to the same device as the model
                src, tgt = X.to(self.device), y.to(self.device)
                # Forward pass: compute predicted y by passing X to the model
                pred = model(src)
                # Compute loss
                loss = criterion(pred, tgt)

            # statistics
            run_loss.append(loss.item())

        return run_loss

    def _save_checkpoint(self, epoch: int, loss: float) -> None:
        """
        Saves the current state of the model, optimizer, and other relevant training information as a checkpoint.

        Parameters:
            epoch (int): The current epoch number at the time of saving.
            loss (float): The loss value at the time of saving.

        Returns:
            None
        """
        # Creating a dictionary of all important data to save
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),  # Saving model state
            'optimizer_state_dict': self.optimizer.state_dict(),  # Saving optimizer state
            'loss': loss,  # Saving the last loss value
        }
        # Saving the checkpoint to the given file path
        torch.save(checkpoint, self.checkpoint_path)
        logger.info(f"Checkpoint saved at {self.checkpoint_path} \n")

    def _load_checkpoint(self):
        """
        Loads a training checkpoint from the specified file path.

        This method updates the model and optimizer state to reflect the state saved
        in the checkpoint. It also updates the `epochs` and `loss` attributes of the
        class to continue training or evaluation from the point saved.

        The checkpoint is expected to be a dictionary with at least the following keys:
        - 'model_state_dict': the state dictionary for the model.
        - 'optimizer_state_dict': the state dictionary for the optimizer.
        - 'epoch': the epoch at which the checkpoint was saved.
        - 'loss': the loss value at the checkpoint.

        Raises:
            FileNotFoundError: If the checkpoint file does not exist at `self.checkpoint_path`.
            KeyError: If the checkpoint does not contain the expected keys.
        """
        checkpoint = torch.load(self.checkpoint_path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.epochs = checkpoint['epoch'] + 1
        self.loss = checkpoint['loss']

    def _convert_tensor_to_array(self, preds: torch.Tensor) -> np.ndarray:
        """
        Converts PyTorch tensors to a NumPy array., handling differently based on
        the model type ('reg' or 'clf'). For 'reg', it directly converts tensors to arrays.
        For 'clf', it converts probabilities to binary (0 or 1) before conversion.

        Parameters:
            preds (List[torch.Tensor]): List of prediction tensors.

        Returns:
            np.ndarray: Converted NumPy array of predictions or binary classifications.

        Raises:
            ValueError: If the model type is neither 'reg' nor 'clf'.
        """
        return np.array(preds)

    def _convert_and_reshape_data(self, data: Union[pd.DataFrame, pd.Series, np.ndarray]):
        """
        Converts pandas DataFrame or Series inputs to numpy arrays, reshaping them to 2D if necessary.

        Parameters:
            X : Union[pd.DataFrame, pd.Series, np.ndarray]
                Input features, reshaped to 2D if one-dimensional.
            y : Union[pd.Series, np.ndarray]
                Target values, reshaped to 2D if one-dimensional.

        Returns:
            Tuple[np.ndarray, np.ndarray] The transformed `X` and `y` as numpy arrays.
        """
        if isinstance(data, (pd.DataFrame, pd.Series)):
            data = data.to_numpy().astype(np.float32)

            if len(data.shape) == 1:
                data = data.reshape(-1, 1)

        return data

    def _compute_positive_weight(self, y_train: np.ndarray) -> torch.Tensor:
        """
        Compute the weight for the positive class to address class imbalance.

        This function calculates the ratio of the number of negative samples to the number of positive samples
        in the training data. This weight can be used to balance the loss function during training.

        Parameters:
        - y_train (np.ndarray): The array of ground truth labels for the training data.

        Returns:
        - torch.Tensor: A tensor containing the single value of the positive class weight,
                        moved to the same device as the model.
        """
        # Count the occurrences of each class in the training data
        unique, counts = np.unique(y_train, return_counts=True)
        class_counts = dict(zip(unique, counts))

        # Ensure counts for both classes are retrieved, defaulting to 0 if a class is missing
        # NOTE: This only only work for binary classes
        count_class_0 = class_counts.get(0, 0)
        count_class_1 = class_counts.get(1, 0)

        # Calculate the ratio of negative to positive samples as the positive weight
        # Avoid division by zero by adding a small epsilon to the denominator
        epsilon = 1e-6
        pos_weight = (count_class_0 / (count_class_1 + epsilon))

        # Convert the positive weight to a PyTorch tensor and move it to the model's device
        pos_weight_t = torch.tensor([pos_weight], dtype=torch.float).to(self.device)

        return pos_weight_t

    def _fit_once(self, model, X_train, X_val, y_train, y_val, best_val_loss):
        # NOTE: Mlflow need to be reviewed since we are not using databricks that automatically
        # created the tracking of trained models.
        # Keep track of x_train array for mlflow signature compatibility
        #X_train_np = X_train.copy()

        # Converting numpy arrays to tensors and ensuring type is float
        X_train = torch.from_numpy(X_train).float()
        y_train = torch.from_numpy(y_train).float()
        X_val = torch.from_numpy(X_val).float()
        y_val = torch.from_numpy(y_val).float()

        # Building dataloaders for training and validation sets
        train_loader = self._build_dataloader(X_train, y_train)
        val_loader = self._build_dataloader(X_val, y_val)

        # Initialize early stopping and wait parameters
        is_stop = False
        early_stop_counter = 0

        train_loss_list = []
        val_loss_list = []

        # Main training loop
        for epoch in range(self.epochs):
            logger.info(f"Epoch {epoch+1}\n-------------------------------")

            if self.is_unbalanced:
                pos_weight_t = self._compute_positive_weight(y_train)

                if self.loss_name == 'bce_logit' or self.loss_name == 'cross_entropy':
                    self.criterion.pos_weight = pos_weight_t
                else:
                    raise ValueError(f"The {self.loss_name} does not support unbalanced data.")

            train_loss = self._train_one_epoch(model, train_loader, self.criterion, self.optimizer)
            val_loss = self._val_one_epoch(model, val_loader, self.criterion)

            # Calculating average losses
            avg_train_loss = torch.mean(torch.tensor(train_loss).float())
            avg_val_loss = torch.mean(torch.tensor(val_loss).float())

            train_loss_list.append(avg_train_loss)
            val_loss_list.append(avg_val_loss)

            # Scheduler step
            if self.scheduler_name == 'reduce':
                self.scheduler.step(avg_val_loss)
            else:
                self.scheduler.step()

            metric_train = self.evaluate(X_train, y_train)
            metric_val = self.evaluate(X_val, y_val)

            metrics = [metric_train, metric_val]

            # Record best model
            if (avg_val_loss < best_val_loss) and (epoch >= self.wait):
                best_val_loss = avg_val_loss
                early_stop_counter = 0  # Reset early stopping counter
                if not self.is_deploy:
                    if self.is_tune and self.is_upload:
                        self.save()
                    else:
                        # save only best
                        if self.is_upload:
                            self.save()
            else:
                early_stop_counter += 1
                if early_stop_counter > self.early_stopping_rounds:
                    is_stop = True

            logger.info("-------------------------------------------------")

            self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

            # Early stopping or NaN detection
            if is_stop or torch.isnan(avg_val_loss).any():
                logger.info("Stopping training due to early stopping or NaN detected.")
                break

            # Save checkpoint every 10 epochs
            if epoch % self.checkpoint_steps == 0 and not self.is_tune and epoch > self.wait:
                self._save_checkpoint(epoch, avg_val_loss)

            avg_train_loss = np.mean(train_loss_list)
            avg_val_loss = np.mean(val_loss_list)

        return avg_train_loss, avg_val_loss, train_loss_list, val_loss_list

    def fit_cv(self,
               X: Union[np.ndarray, pd.DataFrame, Any],
               y: Union[np.ndarray, pd.DataFrame, Any]) -> float:

        # Convert data and reshape to 2D if 1D
        X = self._convert_and_reshape_data(X)
        y = self._convert_and_reshape_data(y)

        if self.is_checkpoint:
            best_val_loss = self.loss
        else:
            best_val_loss = torch.tensor(float('+inf'))

        tscv = TimeSeriesSplit(n_splits=self.n_splits)

        avg_val_loss_list = []
        cv_X_val = []
        cv_models = []
        cv_acc_val = []
        cv_fscore_val = []
        cv_r2_val = []

        for fold, (train_index, val_index) in enumerate(tscv.split(X)):
            model_k = deepcopy(self.model)

            logger.info(f"Training on fold {fold+1}/{self.n_splits}...")

            if isinstance(X, np.ndarray):
                for fold, (train_index, val_index) in enumerate(tscv.split(X)):
                    logger.info(f"Training on fold {fold+1}/{self.n_splits}...")
                    X_train, X_val = X[train_index], X[val_index]
                    y_train, y_val = y[train_index], y[val_index]
            elif isinstance(X, pd.DataFrame):
                for fold, (train_index, val_index) in enumerate(tscv.split(X)):
                    logger.info(f"Training on fold {fold+1}/{self.n_splits}...")
                    X_train, X_val = X.iloc[train_index], X.iloc[val_index]
                    y_train, y_val = y.iloc[train_index], y.iloc[val_index]
            else:
                raise ValueError("Data should be ndarray or dataframe!!!")

            avg_train_loss, avg_val_loss, _, _ = self._fit_once(self.model,
                                                                X_train,
                                                                X_val,
                                                                y_train,
                                                                y_val,
                                                                best_val_loss)

            avg_val_loss_list.append(avg_val_loss)  # Store avg val loss for each k models
            cv_X_val.append(X_val)
            cv_models.append(model_k)

            with self.temporary_model(model_k):
                metric_train = self.evaluate(X_train, y_train)
                metric_val = self.evaluate(X_val, y_val)

                metrics = [metric_train, metric_val]

                self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

                if self.model_type == 'clf':
                    cv_acc_val.append(metric_val['accuracy'])
                    cv_fscore_val.append(metric_val['fscore'])
                else:
                    cv_r2_val.append(metric_val['r2'])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = np.mean(avg_val_loss_list)
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -np.mean(cv_acc_val)
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -np.mean(cv_fscore_val)
            else:
                best_val_loss = self.cummulative_return_loss_function_cv(cv_X_val, cv_models)
        else:
            best_val_loss = -np.mean(cv_r2_val)

        return best_val_loss

    def fit(self,
            X: Union[np.ndarray, pd.DataFrame, Any],
            y: Union[np.ndarray, pd.DataFrame, Any]) -> float:
        """
        Fits the model to the provided data.

        Parameters:
            X (np.ndarray): The input features for the model.
            y (np.ndarray): The target labels or values for the model.

        Returns:
            float: The best validation loss achieved during training.
        """
        # Convert data and reshape to 2D if 1D
        X = self._convert_and_reshape_data(X)
        y = self._convert_and_reshape_data(y)

        if self.is_checkpoint:
            best_val_loss = self.loss
        else:
            best_val_loss = torch.tensor(float('+inf'))

        X_train, X_val, y_train, y_val = train_test_split(X,
                                                          y,
                                                          test_size=0.2,
                                                          shuffle=False)

        avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(self.model,
                                                                            X_train,
                                                                            X_val,
                                                                            y_train,
                                                                            y_val,
                                                                            best_val_loss)

        metric_train = self.evaluate(X_train, y_train)
        metric_val = self.evaluate(X_val, y_val)

        if self.model_type == 'clf':
            acc_val = metric_val['accuracy']
            fscore_val = metric_val['fscore']
        else:
            r2 = metric_val['r2']

        metric_train['train_loss'] = train_loss
        metric_val['val_loss'] = val_loss

        metrics = [metric_train, metric_val]

        self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

        self.historical_metrics = self._extract_metrics(metrics)

        self.historical_metrics_df = pd.DataFrame([self.historical_metrics])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = avg_val_loss  # average val loss
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -acc_val
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -fscore_val
            else:
                best_val_loss = self.cummulative_return_loss_function(X_val)
        else:
            best_val_loss = -r2

        return best_val_loss

    def evaluate(self, X: np.ndarray, y: np.ndarray) -> Any:
        """
        Evaluates the model on the given data and returns the computed metrics.

        Parameters:
            X (np.ndarray): The input features for evaluation.
            y (np.ndarray): The true labels or values for evaluation.

        Returns:
            Any: The evaluation metrics as returned by _build_metrics method.
        """
        # Convert data and reshape to 2D if 1D
        X = self._convert_and_reshape_data(X)
        y = self._convert_and_reshape_data(y)

        # Convert data to DataLoader for batch processing
        loader = self._build_dataloader(X, y)

        p_list, y_list = [], []
        with torch.no_grad():  # No gradients needed for evaluation
            for X, y in loader:
                src = X.float().to(self.device)
                preds = self.model(src)

                if self.loss_name == 'bce_logit':
                    # Calculate the prob
                    probs = torch.sigmoid(preds)
                    y_p = (probs >= 0.5).float()
                    y_t = y
                elif self.loss_name == 'cross_entropy':
                    # Get labels
                    probs = nn.functional.softmax(preds, dim=1)
                    y_p = torch.argmax(probs, dim=1).to(self.device)
                    y_t = torch.argmax(y, dim=1).to(self.device)
                else:
                    y_p = (preds >= 0.5).float()
                    y_t = y

                # Flatten the predictions and append
                p_list.append(y_p.cpu().numpy())
                y_list.append(y_t.cpu().numpy())

            label_preds = np.concatenate(p_list, axis=0)
            label_target = np.concatenate(y_list, axis=0)

        return self._build_metrics(label_target, label_preds)

    def predict(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Predicts outputs for the given input data.

        Parameters:
            X (np.ndarray): The input features for prediction.
            batch_size (int): The number of samples per batch in prediction. Default is 1.

        Returns:
            np.ndarray: Predicted values or classes.
        """
        X = self._convert_and_reshape_data(X)
        loader = self._build_dataloader(X)
        p_list = []
        with torch.no_grad():
            for X in loader:
                # Move the batch to the same device as the model
                X = X.to(self.device)

                # Get model predictions for the batch
                preds = self.model(X)

                if self.loss_name == 'bce_logit':
                    # Calculate the prob
                    probs = torch.sigmoid(preds)
                    y_p = (probs >= 0.5).float()
                elif self.loss_name == 'cross_entropy':
                    # Get labels
                    probs = nn.functional.softmax(preds, dim=1)
                    y_p = torch.argmax(probs, dim=1).to(self.device)
                elif self.loss_name == "mse":
                    y_p = preds.float()
                else:
                    y_p = (preds >= 0.5).float()

                p_list.append(y_p.cpu().numpy().flatten())

            preds = np.concatenate(p_list, axis=0)

        return preds

    def predict_proba(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Predicts outputs for the given input data.

        Parameters:
            X (np.ndarray): The input features for prediction.
            batch_size (int): The number of samples per batch in prediction. Default is 1.

        Returns:
            np.ndarray: Predicted values or classes.
        """
        X = self._convert_and_reshape_data(X)

        loader = self._build_dataloader(X)
        preds_list = []
        with torch.no_grad():
            for X in loader:
                # Move the batch to the same device as the model
                X = X.to(self.device)

                # Get model predictions for the batch
                preds = self.model(X)

                # Apply sigmoid to convert logits to probabilities
                if self.loss_name == 'bce_logit':
                    preds = torch.sigmoid(preds)
                elif self.loss_name == 'cross_entropy':
                    # Get labels
                    probs = nn.functional.softmax(preds, dim=1)
                    preds, _ = torch.max(probs, dim=1)


                # Flatten the predictions and append
                preds_list.append(preds.cpu().numpy().flatten())

            preds = np.concatenate(preds_list)

        return preds

    def save(self) -> None:
        """
        Saves the model's state to a file.
        """
        if not self.is_tune:
            # Specify the file path where you want to save the JSON file
            file_path = self.output_dir + self.output_name.split('.')[0] + "_all_parameters.json"

            # Open the file in write mode and save the dictionary as JSON
            with open(file_path, "w") as json_file:
                json.dump(self.config, json_file)

            logger.info(f"All parameters used in this train were saved as JSON in '{file_path}'")

        # Saving model
        if self.model is not None:
            model_path = self.output_dir + self.output_name.split('.')[0] + ".pt"
            torch.save(self.model.state_dict(), model_path)
            logger.info(f"\nNEW BEST MODEL SAVED TO {model_path}\n")

    def load(self, file_path: str) -> None:
        """
        Loads the model's state from a file.

        Parameters:
            file_path (str): The path to load the model state from.
        """
        file_path = file_path + '.pt'
        self.model.load_state_dict(torch.load(file_path, self.device))
        logger.info(f"Model loaded from {file_path}")


class XGBoostTrainer(Basic):
    """
    A training class for XGBoost models, supporting both classifiers and regressors.

    This class handles the complete lifecycle of XGBoost models, including fitting, evaluation, prediction, saving,
    and loading.

    Attributes:
        model (Union[XGBoostClf, XGBoostReg]): The XGBoost model instance set for training.
        model_type (str): Specifies the type of model, either 'clf' for classifier or 'reg' for regressor.
        output_dir (str): Path to the directory where model outputs are saved.
        output_name (str): Filename for the saved model output.
        is_tune (bool): Indicates if hyperparameter tuning is enabled.
        save_criteria (str): Criteria for saving the model (e.g., best model by accuracy, loss, etc.).
        is_unbalanced (bool): Flag indicating if the training data is unbalanced, to adjust training parameters accordingly.
        is_cross_validation (bool): Determines whether cross-validation is used during model training.
        n_splits (int): Number of folds for cross-validation.
        model_name (str): Custom name for the model, primarily for saving and identification purposes.
        framework (str): The machine learning framework being used ('xgboost').
        is_multiclass (bool): Indicates if the model is a multiclass classifier.
        is_deploy (bool): Flag to indicate if the model is intended for deployment.
        log_name (str, optional): The name of the log file if logging is enabled.
        is_block_cv (bool): Flag indicating if block cross-validation is applied.
        tune_loss_function (str): The loss function used for hyperparameter tuning.
    """
    def __init__(self, config: dict, model: Union[XGBoostClf, XGBoostReg]):
        """
        Initializes the XGBoostTrainer with the provided arguments and model.

        Args:
            config (dict): Configuration parameters for training.
            model (Union[XGBoostClf, XGBoostReg]): The XGBoost model instance for training.
        """
        # Set basic configuration
        self.config = config
        self.model = model

        self.model_type = config['info']['model_type']
        self.is_tune = config['info']['is_tune']
        self.save_criteria = config['info']['save_criteria']
        self.output_dir = config['info']['output_dir']
        self.output_name = config['info']['output_name']
        self.is_unbalanced = config['info']['is_unbalanced']
        self.is_cross_validation = config['info']['is_cross_validation']
        self.n_splits = config['info']['n_splits']
        self.model_name = config['info']['model_name']
        self.framework = config['info']['framework']
        self.is_multiclass = config['info']['is_multiclass']
        self.is_deploy = config['info']['is_deploy']
        self.early_stopping_rounds = config['info']['early_stopping_rounds']

        if self.is_deploy:
            self.log_name = None
        else:
            self.log_name = config['info']['log_name']

        self.is_block_cv = config['info']['is_block_cv']
        self.tune_loss_function = config['tune']['tune_loss_function']

        self._set_save_criteria_flags()
        self.historical_metrics = {}

        if not self.is_deploy:
            self._mkdir(self.output_dir)

    def _fit_once(self, model, X_train, X_val, y_train, y_val):
        # NOTE: This is different from lgbm, so it needs to take a more general
        # approach since the class weight for lgbm is computed on train scripts.
        # Calculate weight for positive class
        if self.is_unbalanced:
            scale_pos_weight = self._compute_positive_weight(y_train)
            model.clf.scale_pos_weight = scale_pos_weight

        if self.model_type == 'clf':
            if self.is_multiclass:
                metric = 'mlogloss'
            else:
                metric = 'logloss'
        else:
            metric = 'rmse'

        if self.model_type == 'clf':
            if self.early_stopping_rounds:
                model.clf.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              early_stopping_rounds=self.early_stopping_rounds,
                              eval_metric=metric)
            else:
                model.clf.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric)

            results = model.clf.evals_result()

            train_loss = results['validation_0'][metric]
            val_loss = results['validation_1'][metric]

            avg_val_loss = np.mean(val_loss)
            avg_train_loss = np.mean(train_loss)

        else:
            if self.early_stopping_rounds:
                model.reg.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              early_stopping_rounds=self.early_stopping_rounds,
                              eval_metric=metric)
            else:
                model.reg.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric)

            results = model.reg.evals_result()

            train_loss = results['validation_0'][metric]
            val_loss = results['validation_1'][metric]

            avg_val_loss = -np.mean(val_loss)
            avg_train_loss = -np.mean(train_loss)

        return avg_train_loss, avg_val_loss, train_loss, val_loss

    def fit_cv(self,
               X: Union[np.ndarray, pd.DataFrame, Any],
               y: Union[np.ndarray, pd.DataFrame, Any]) -> Union[XGBoostClf, XGBoostReg]:

        tscv = TimeSeriesSplit(n_splits=self.n_splits)

        avg_val_loss_list = []
        cv_X_val = []
        cv_models = []
        cv_acc_val = []
        cv_fscore_val = []
        cv_r2_val = []

        for fold, (train_index, val_index) in enumerate(tscv.split(X)):
            model_k = deepcopy(self.model)

            logger.info(f"Training on fold {fold+1}/{self.n_splits}...")

            if isinstance(X, np.ndarray):
                if self.is_block_cv:
                    X_train, X_val = X[train_index[fold:]], X[val_index[fold:]]
                    y_train, y_val = y[train_index[fold:]], y[val_index[fold:]]
                else:
                    X_train, X_val = X[train_index], X[val_index]
                    y_train, y_val = y[train_index], y[val_index]
            elif isinstance(X, pd.DataFrame):
                if self.is_block_cv:
                    X_train, X_val = X.iloc[train_index[fold:]], X.iloc[val_index[fold:]]
                    y_train, y_val = y.iloc[train_index[fold:]], y.iloc[val_index[fold:]]
                else:
                    X_train, X_val = X.iloc[train_index], X.iloc[val_index]
                    y_train, y_val = y.iloc[train_index], y.iloc[val_index]
            else:
                raise ValueError("Data should be ndarray or dataframe!!!")

            avg_train_loss, avg_val_loss, _, _ = self._fit_once(model_k,
                                                                X_train,
                                                                X_val,
                                                                y_train,
                                                                y_val)

            avg_val_loss_list.append(avg_val_loss)
            cv_X_val.append(X_val)
            cv_models.append(model_k)

            with self.temporary_model(model_k):
                metric_train = self.evaluate(X_train, y_train)
                metric_val = self.evaluate(X_val, y_val)

                metrics = [metric_train, metric_val]

                self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

                if self.model_type == 'clf':
                    cv_acc_val.append(metric_val['accuracy'])
                    cv_fscore_val.append(metric_val['fscore'])
                else:
                    cv_r2_val.append(metric_val['r2'])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = np.mean(avg_val_loss_list)  # average val loss
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -np.mean(cv_acc_val)
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -np.mean(cv_fscore_val)
            else:
                best_val_loss = self.cummulative_return_loss_function_cv(cv_X_val, cv_models)
        else:
            best_val_loss = -np.mean(cv_r2_val)

        return best_val_loss

    def fit(self, X: np.ndarray, y: np.ndarray) -> Union[LgbmClf, LgbmReg]:
        """
        Fits the Lgbm model to the provided dataset.

        Args:
            X (np.ndarray): The input features.
            y (np.ndarray): The target values.
        """
        X_train, X_val, y_train, y_val = train_test_split(X,
                                                          y,
                                                          test_size=0.2,
                                                          shuffle=False)

        avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(self.model,
                                                                            X_train,
                                                                            X_val,
                                                                            y_train,
                                                                            y_val)

        metric_train = self.evaluate(X_train, y_train)
        metric_val = self.evaluate(X_val, y_val)

        if self.model_type == 'clf':
            acc_val = metric_val['accuracy']
            fscore_val = metric_val['fscore']
        else:
            r2 = metric_val['r2']

        metric_train['train_loss'] = train_loss
        metric_val['val_loss'] = val_loss

        metrics = [metric_train, metric_val]

        self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

        self.historical_metrics = self._extract_metrics(metrics)

        self.historical_metrics_df = pd.DataFrame([self.historical_metrics])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = avg_val_loss  # average val loss
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -acc_val
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -fscore_val
            else:
                best_val_loss = self.cummulative_return_loss_function(X_val)
        else:
            best_val_loss = -r2

        return best_val_loss

    def evaluate(self, X: np.ndarray, y: np.ndarray) -> dict:
        """
        Evaluates the model on the given dataset and returns evaluation metrics.

        Args:
            X (np.ndarray): The input features for evaluation.
            y (np.ndarray): The actual target values for comparison.

        Returns:
            Any: The evaluation metrics.
        """
        pred = self.predict(X)
        return self._build_metrics(y, pred)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predictions using the trained model on the provided dataset.

        Args:
            X (Any): The input features for making predictions.

        Returns:
            Any: The predicted values.
        """
        # Implement prediction logic
        if self.model is not None:
            if self.model_type == 'clf':
                return self.model.clf.predict(X)
            else:
                return self.model.reg.predict(X)
        else:
            raise Exception("Model not trained yet. Call fit first.")

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predict_proba using the trained model on the provided dataset.

        Args:
            X (Any): The input features for making predict_proba.

        Returns:
            Any: The predict_proba values.
        """
        # Implement predict_proba logic
        if self.model is not None:
            if self.model_type == 'clf':
                probabilities = self.model.clf.predict_proba(X)
                return probabilities
            else:
                probabilities = self.model.reg.predict_proba(X)
                return probabilities
        else:
            raise Exception("Model not trained yet. Call fit first.")

    def fit_final_model(self, X, y):
        """
        Train the model on the entire dataset with the best parameters found.

        Args:
            X (np.ndarray): The input features for the entire dataset.
            y (np.ndarray): The target values for the entire dataset.
            best_params (dict): The best parameters found during tuning.
        """

        if self.model is not None:
            if self.model_type == 'clf':
                self.model.clf.fit(X, y)
            else:
                self.model.reg.fit(X, y)

        if not self.is_deploy and self.is_upload:
            self.save()


class LgbmTrainer(Basic):
    """
    A training class for LightGBM models, supporting both classifiers and regressors.

    This class handles the entire lifecycle of a LightGBM model, including fitting, evaluation,
    prediction, saving, and loading. It offers flexibility for both classification and regression tasks,
    and supports additional features such as hyperparameter tuning, cross-validation, and deployment readiness.

    Attributes:
        config (dict): Configuration dictionary containing various settings and parameters for the training process.
        model (Union[LgbmClf, LgbmReg]): The LightGBM model to be trained, which can be either a classifier or a regressor.
        model_type (str): Specifies the type of model ('clf' for classifier, 'reg' for regressor).
        is_tune (bool): Indicates whether hyperparameter tuning is enabled.
        save_criteria (str): Criteria used to determine the best model for saving.
        output_dir (str): Directory path where model outputs, including logs and artifacts, will be saved.
        output_name (str): The base name for saved output files (e.g., model checkpoints).
        is_unbalanced (bool): Indicates whether the data is unbalanced, which may trigger specific training techniques.
        is_cross_validation (bool): Specifies whether cross-validation is to be used.
        n_splits (int): Number of splits for cross-validation.
        model_name (str): The name assigned to the model for identification purposes.
        framework (str): The framework or toolset used for model training (e.g., 'LightGBM').
        is_multiclass (bool): Indicates whether the classification task is multiclass.
        is_deploy (bool): Specifies if the model is being prepared for deployment, affecting logging and saving behaviors.
        log_name (str or None): The name of the log file, if applicable. Set to None if deployment mode is enabled.
        is_block_cv (bool): Specifies whether block cross-validation is being used, which may apply in time-series scenarios.
        tune_loss_function (str): Loss function used during hyperparameter tuning.
        logger (Logger): Logger instance for capturing training logs.
        historical_metrics (dict): A dictionary to store historical metrics for model evaluation and comparison.
    """
    def __init__(self, config: dict, model: Union[LgbmClf, LgbmReg]):
        """
        Initializes the LgbmTrainer with the provided arguments and model.

        Args:
            config (dict): Configuration parameters for training.
            model (Union[LgbmClf, LgbmReg]): The Lgbm model instance for training.
        """
        # Set basic configuration
        self.config = config
        self.model = model

        self.model_type = config['info']['model_type']
        self.is_tune = config['info']['is_tune']
        self.save_criteria = config['info']['save_criteria']
        self.output_dir = config['info']['output_dir']
        self.output_name = config['info']['output_name']
        self.is_unbalanced = config['info']['is_unbalanced']
        self.is_cross_validation = config['info']['is_cross_validation']
        self.n_splits = config['info']['n_splits']
        self.model_name = config['info']['model_name']
        self.framework = config['info']['framework']
        self.is_multiclass = config['info']['is_multiclass']
        self.is_deploy = config['info']['is_deploy']
        self.early_stopping_rounds = config['info']['early_stopping_rounds']

        if self.is_deploy:
            self.log_name = None
        else:
            self.log_name = config['info']['log_name']

        self.is_block_cv = config['info']['is_block_cv']
        self.tune_loss_function = config['tune']['tune_loss_function']

        self._set_save_criteria_flags()
        self.historical_metrics = {}

        if not self.is_deploy:
            self._mkdir(self.output_dir)

    def _fit_once(self, model, X_train, X_val, y_train, y_val):
        if self.model_type == 'clf':
            if self.is_multiclass:
                metric = 'multi_logloss'
            else:
                metric = 'binary_logloss'
        else:
            metric = 'rmse'

        if self.model_type == 'clf':
            # Define a callback to stop training if validation loss do not improve after n rounds
            if self.early_stopping_rounds:
                early_stopping_cb = lightgbm.early_stopping(stopping_rounds=self.early_stopping_rounds)

                model.clf.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric,
                              callbacks=[early_stopping_cb])
            else:
                model.clf.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric)

            results = model.clf.evals_result_

            historical_train_loss = results['training'][metric]
            historical_val_loss = results['valid_1'][metric]

            avg_train_loss = np.mean(historical_train_loss)
            avg_val_loss = np.mean(historical_val_loss)
        else:
            if self.early_stopping_rounds:
                early_stopping_cb = lightgbm.early_stopping(stopping_rounds=self.early_stopping_rounds)

                model.reg.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric,
                              callbacks=[early_stopping_cb])
            else:
                model.reg.fit(X_train,
                              y_train,
                              eval_set=[(X_train, y_train), (X_val, y_val)],
                              eval_metric=metric)

            results = model.reg.evals_result_

            historical_train_loss = results['training'][metric]
            historical_val_loss = results['valid_1'][metric]

            avg_train_loss = -np.mean(historical_train_loss)
            avg_val_loss = -np.mean(historical_val_loss)

        return avg_train_loss, avg_val_loss, historical_train_loss, historical_val_loss

    def fit_cv(self,
               X: Union[np.ndarray, pd.DataFrame, Any],
               y: Union[np.ndarray, pd.DataFrame, Any]) -> Union[LgbmClf, LgbmReg]:

        tscv = TimeSeriesSplit(n_splits=self.n_splits)

        avg_val_loss_list = []
        cv_X_val = []
        cv_models = []
        cv_acc_val = []
        cv_fscore_val = []
        cv_r2_val = []

        for fold, (train_index, val_index) in enumerate(tscv.split(X)):
            model_k = deepcopy(self.model)

            logger.info(f"Training on fold {fold+1}/{self.n_splits}...")

            if isinstance(X, np.ndarray):
                if self.is_block_cv:
                    X_train, X_val = X[train_index[fold:]], X[val_index[fold:]]
                    y_train, y_val = y[train_index[fold:]], y[val_index[fold:]]
                else:
                    X_train, X_val = X[train_index], X[val_index]
                    y_train, y_val = y[train_index], y[val_index]
            elif isinstance(X, pd.DataFrame):
                if self.is_block_cv:
                    X_train, X_val = X.iloc[train_index[fold:]], X.iloc[val_index[fold:]]
                    y_train, y_val = y.iloc[train_index[fold:]], y.iloc[val_index[fold:]]
                else:
                    X_train, X_val = X.iloc[train_index], X.iloc[val_index]
                    y_train, y_val = y.iloc[train_index], y.iloc[val_index]
            else:
                raise ValueError("Data should be ndarray or dataframe!!!")

            avg_train_loss, avg_val_loss, _, _ = self._fit_once(model_k,
                                                                X_train,
                                                                X_val,
                                                                y_train,
                                                                y_val)

            avg_val_loss_list.append(avg_val_loss)
            cv_X_val.append(X_val)
            cv_models.append(model_k)

            with self.temporary_model(model_k):
                metric_train = self.evaluate(X_train, y_train)
                metric_val = self.evaluate(X_val, y_val)

                metrics = [metric_train, metric_val]

                self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

                if self.model_type == 'clf':
                    cv_acc_val.append(metric_val['accuracy'])
                    cv_fscore_val.append(metric_val['fscore'])
                else:
                    cv_r2_val.append(metric_val['r2'])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = np.mean(avg_val_loss_list)  # average val loss
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -np.mean(cv_acc_val)
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -np.mean(cv_fscore_val)
            else:
                best_val_loss = self.cummulative_return_loss_function_cv(cv_X_val, cv_models)
        else:
            best_val_loss = -np.mean(cv_r2_val)

        return best_val_loss

    def fit(self, X: np.ndarray, y: np.ndarray) -> Union[LgbmClf, LgbmReg]:
        """
        Fits the Lgbm model to the provided dataset.

        Args:
            X (np.ndarray): The input features.
            y (np.ndarray): The target values.
        """
        X_train, X_val, y_train, y_val = train_test_split(X,
                                                          y,
                                                          test_size=0.2,
                                                          shuffle=False)

        avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(self.model,
                                                                            X_train,
                                                                            X_val,
                                                                            y_train,
                                                                            y_val)

        metric_train = self.evaluate(X_train, y_train)
        metric_val = self.evaluate(X_val, y_val)

        if self.model_type == 'clf':
            acc_val = metric_val['accuracy']
            fscore_val = metric_val['fscore']
        else:
            r2 = metric_val['r2']

        metric_train['train_loss'] = train_loss
        metric_val['val_loss'] = val_loss

        metrics = [metric_train, metric_val]

        self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

        self.historical_metrics = self._extract_metrics(metrics)

        self.historical_metrics_df = pd.DataFrame([self.historical_metrics])

        if self.model_type == 'clf':
            if (self.tune_loss_function == 'default'):
                best_val_loss = avg_val_loss  # average val loss
            elif (self.tune_loss_function == 'acc'):
                best_val_loss = -acc_val
            elif (self.tune_loss_function == 'fscore'):
                best_val_loss = -fscore_val
            else:
                best_val_loss = self.cummulative_return_loss_function(X_val)
        else:
            best_val_loss = -r2

        return best_val_loss

    def evaluate(self, X: np.ndarray, y: np.ndarray) -> dict:
        """
        Evaluates the model on the given dataset and returns evaluation metrics.

        Args:
            X (np.ndarray): The input features for evaluation.
            y (np.ndarray): The actual target values for comparison.

        Returns:
            Any: The evaluation metrics.
        """
        pred = self.predict(X)

        return self._build_metrics(y, pred)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predictions using the trained model on the provided dataset.

        Args:
            X (Any): The input features for making predictions.

        Returns:
            Any: The predicted values.
        """
        # Implement prediction logic
        if self.model is not None:
            if self.model_type == 'clf':
                return self.model.clf.predict(X)
            else:
                return self.model.reg.predict(X)
        else:
            raise Exception("Model not trained yet. Call fit first.")

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predict_proba using the trained model on the provided dataset.

        Args:
            X (Any): The input features for making predict_proba.

        Returns:
            Any: The predict_proba values.
        """
        # Implement predict_proba logic
        if self.model is not None:
            if self.model_type == 'clf':
                probabilities = self.model.clf.predict_proba(X)
                return probabilities
        else:
            raise Exception("Model not trained yet. Call fit first.")

    def fit_final_model(self, X, y):
        """
        Train the model on the entire dataset with the best parameters found.

        Args:
            X (np.ndarray): The input features for the entire dataset.
            y (np.ndarray): The target values for the entire dataset.
            best_params (dict): The best parameters found during tuning.
        """
        if self.model is not None:
            if self.model_type == 'clf':
                self.model.clf.fit(X, y)
            else:
                self.model.reg.fit(X, y)

        if not self.is_deploy and self.is_upload:
            self.save()

        logger.info("Model retrained on the entire dataset.")


# NOTE: Need to be updated. Do not use.
class SkTrainer(Basic):
    """
    A training class for sklearn models, such as RF and LR supporting both classifiers and regressors.
    This class handles fitting, evaluation, prediction, saving, and loading of RF and LR models.
    Attributes:
        model (Union[RfClf, RfReg]): The Rf model to be trained.
        model_type (str): Type of the model ('clf' for classifier, 'reg' for regressor).
        is_tune (bool): Flag for tunning option. (Not implemented for this method yet)
        output_dir (str): Directory for saving model outputs.
        output_name (str): Name for the output file.
    """
    def __init__(self, config: dict, model: Union[RfClf, RfReg, LrClf]):
        """
        Initializes the RfTrainer with the provided arguments and model.
        Args:
            config (dict): Configuration parameters for training.
            model (Union[RfClf, RfReg, LrClf]): The RF model instance for training.
        """
        # Set basic configuration
        self.config = config
        self.model = model

        self.model_type = config['info']['model_type']
        self.is_tune = config['info']['is_tune']
        self.save_criteria = config['info']['save_criteria']
        self.output_dir = config['info']['output_dir']
        self.output_name = config['info']['output_name']
        self.is_unbalanced = config['info']['is_unbalanced']
        self.is_cross_validation = config['info']['is_cross_validation']
        self.n_splits = config['info']['n_splits']
        self.model_name = config['info']['model_name']
        self.framework = config['info']['framework']
        self.is_multiclass = config['info']['is_multiclass']
        self.is_deploy = config['info']['is_deploy']
        self.log_name = config['info']['log_name']

        self._set_save_criteria_flags()

        if not self.is_deploy:
            self._mkdir(self.output_dir)

    def _fit_once(self, X_train, X_val, y_train, y_val):
        # Calculate weight for positive class
        scale_pos_weight = self._compute_positive_weight(y_train)

        if self.model_type == 'clf':
            if self.is_unbalanced:
                self.model.clf.scale_pos_weight = scale_pos_weight

            self.model.clf.fit(X_train,
                               y_train)
        else:
            self.model.reg.fit(X_train,
                               y_train)

        # Predict probabilities for training and validation sets
        y_train_pred_prob = self.predict_proba(X_train)
        y_val_pred_prob = self.predict_proba(X_val)

        # sklearn does not keep track of historical loss
        # to avoid framework incompatibility the val and train loss
        # are returned as list
        train_loss = []
        train_loss.append(log_loss(y_train, y_train_pred_prob))

        val_loss = []
        val_loss.append(log_loss(y_val, y_val_pred_prob))

        if self.model_type == 'clf':
            avg_train_loss = np.mean(train_loss)
            avg_val_loss = np.mean(val_loss)
        else:
            avg_train_loss = -np.mean(train_loss)
            avg_val_loss = -np.mean(val_loss)

        return avg_train_loss, avg_val_loss, train_loss, val_loss

    def fit(self, X: np.ndarray, y: np.ndarray) -> Union[RfClf, RfReg, LrClf]:
        """
        Fits a sklearn model to the provided dataset.
        Args:
            X (np.ndarray): The input features.
            y (np.ndarray): The target values.
        """
        best_val_loss = float('inf')

        if self.is_cross_validation:
            tscv = TimeSeriesSplit(n_splits=self.n_splits)

            if isinstance(X, np.ndarray):
                for fold, (train_index, val_index) in enumerate(tscv.split(X)):
                    logger.info(f"Training on fold {fold+1}/{self.n_splits}...")
                    X_train, X_val = X[train_index], X[val_index]
                    y_train, y_val = y[train_index], y[val_index]

                    avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(X_train,
                                                                                        X_val,
                                                                                        y_train,
                                                                                        y_val)

                    metric_train = self.evaluate(X_train, y_train)
                    metric_val = self.evaluate(X_val, y_val)

                    metrics = [metric_train, metric_val]
                    self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

                    best_val_loss = self.log_mlflow(X_train,
                                                    X_val,
                                                    y_val,
                                                    avg_val_loss,
                                                    best_val_loss,
                                                    train_loss,
                                                    val_loss)
            elif isinstance(X, pd.DataFrame):
                for fold, (train_index, val_index) in enumerate(tscv.split(X)):
                    logger.info(f"Training on fold {fold+1}/{self.n_splits}...")
                    X_train, X_val = X.iloc[train_index], X.iloc[val_index]
                    y_train, y_val = y.iloc[train_index], y.iloc[val_index]

                    avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(X_train,
                                                                                        X_val,
                                                                                        y_train,
                                                                                        y_val)

                    metric_train = self.evaluate(X_train, y_train)
                    metric_val = self.evaluate(X_val, y_val)

                    metrics = [metric_train, metric_val]
                    self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

                    best_val_loss = self.log_mlflow(X_train,
                                                    X_val,
                                                    y_val,
                                                    avg_val_loss,
                                                    best_val_loss,
                                                    train_loss,
                                                    val_loss)

        else:
            X_train, X_val, y_train, y_val = train_test_split(X,
                                                              y,
                                                              test_size=0.2,
                                                              shuffle=False)

            avg_train_loss, avg_val_loss, train_loss, val_loss = self._fit_once(X_train,
                                                                                X_val,
                                                                                y_train,
                                                                                y_val)

            metric_train = self.evaluate(X_train, y_train)
            metric_val = self.evaluate(X_val, y_val)

            metrics = [metric_train, metric_val]
            self._print_metrics_and_losses(avg_train_loss, avg_val_loss, metrics)

            # Without cross validation the best_val_loss is the avg_val_loss
            best_val_loss = self.log_mlflow(X_train,
                                            X_val,
                                            y_val,
                                            avg_val_loss,
                                            best_val_loss,
                                            train_loss,
                                            val_loss)

        return best_val_loss

    def evaluate(self, X: np.ndarray, y: np.ndarray) -> dict:
        """
        Evaluates the model on the given dataset and returns evaluation metrics.
        Args:
            X (np.ndarray): The input features for evaluation.
            y (np.ndarray): The actual target values for comparison.
        Returns:
            Any: The evaluation metrics.
        """
        pred = self.predict(X)

        return self._build_metrics(y, pred)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predictions using the trained model on the provided dataset.
        Args:
            X (Any): The input features for making predictions.
        Returns:
            Any: The predicted values.
        """
        # Implement prediction logic
        if self.model is not None:
            if self.model_type == 'clf':
                return self.model.clf.predict(X)
            else:
                return self.model.reg.predict(X)
        else:
            raise Exception("Model not trained yet. Call fit first.")

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Makes predict_proba using the trained model on the provided dataset.

        Args:
            X (Any): The input features for making predict_proba.

        Returns:
            Any: The predict_proba values.
        """
        # Implement predict_proba logic
        if self.model is not None:
            if self.model_type == 'clf':
                probabilities = self.model.clf.predict_proba(X)
                return probabilities
            else:
                probabilities = self.model.reg.predict_proba(X)
                return probabilities
        else:
            raise Exception("Model not trained yet. Call fit first.")


class Trainer:
    def __init__(self,
                 config: dict = None):  # Required

        self.config = config
        if self.config is None:
            raise ValueError("[ERROR] Config was not found!")

        self.model = self._get_model()
        if self.model is None:
            raise ValueError("[ERROR] Model was not found check available models {[model.value for model in CypherModel]}.")

        self._select_strategy()
        if self.strategy is None:
            raise ValueError("[Error] Framework was not found check available frameworks {[strategy.value for strategy in CypherTrainer]}.")

    def _get_model(self) -> CypherModel:
        """
        Retrieves the model based on the model name.

        Returns:
            The instantiated model or None if not found.
        """
        model_name = self.config['info']['model_name']

        models = {
            CypherModel.TRANSFORMER_ENCODER_REG: TransformerEncoderReg,
            CypherModel.TRANSFORMER_ENCODER_CLF: TransformerEncoderClf,
            CypherModel.XGBOOST_CLF: XGBoostClf,
            CypherModel.XGBOOST_REG: XGBoostReg,
            CypherModel.LGBM_CLF: LgbmClf,
            CypherModel.LGBM_REG: LgbmReg,
            CypherModel.RF_CLF: RfClf,
            CypherModel.RF_REG: RfReg,
            CypherModel.LR_CLF: LrClf,
            CypherModel.LSTM_REG: LSTMReg,
            CypherModel.LSTM_CLF: LSTMClf
        }

        # Define a mapping from model names to their expected frameworks
        framework_mapping = {
            CypherModel.XGBOOST_CLF: 'xgboost',
            CypherModel.XGBOOST_REG: 'xgboost',
            CypherModel.TRANSFORMER_ENCODER_CLF: 'torch',
            CypherModel.TRANSFORMER_ENCODER_REG: 'torch',
            CypherModel.LSTM_REG: 'torch',
            CypherModel.LSTM_CLF: 'torch',
            CypherModel.LGBM_CLF: 'lgbm',
            CypherModel.LGBM_REG: 'lgbm',
            CypherModel.RF_CLF: 'sklearn',
            CypherModel.RF_REG: 'sklearn',
            CypherModel.LR_CLF: 'sklearn'
        }

        # Check if configuration file is correct
        try:
            framework = self.config['info']['framework']
        except Exception:
            raise ValueError("Configuration file error: set configuration file parameters according to framework, check ./models/config_template folder files.")

        # Check if the model name is in the mapping
        if model_name in framework_mapping:
            # Check if the framework matches the expected framework
            expected_framework = framework_mapping[model_name]
            if framework != expected_framework:
                raise ValueError(f"Configuration file error: the framework for {model_name} must be '{expected_framework}'.")
        else:
            raise ValueError("Framework not implemented!!!")

        # Get config params
        model_params = self.config['params']

        return models[model_name](model_params) if model_name in models else None

    def _select_strategy(self):
        """
        Selects the training strategy based on the model type.
        """
        model_strategy = self._get_model_strategy()

        if model_strategy == CypherTrainer.TORCH:
            self.strategy = PyTorchTrainer(self.model,
                                           self.config)
        elif model_strategy == CypherTrainer.XGBOOST:
            self.strategy = XGBoostTrainer(self.config,
                                           self.model)
        elif model_strategy == CypherTrainer.LGBM:
            self.strategy = LgbmTrainer(self.config,
                                        self.model)
        elif model_strategy == CypherTrainer.SKLEARN:
            self.strategy = SkTrainer(self.config,
                                      self.model)

    def _get_model_strategy(self):
        """
        Determines the model strategy to use based on the model type.

        Returns:
            CypherTrainer: The identified training strategy or None if not found.
        """
        if isinstance(self.model, nn.Module):
            return CypherTrainer.TORCH
        elif (hasattr(self.model, 'clf') and isinstance(self.model.clf, xgboost.XGBClassifier)) or \
             (hasattr(self.model, 'reg') and isinstance(self.model.reg, xgboost.XGBRegressor)):
            # Assuming you have a corresponding trainer for XGBoost models
            return CypherTrainer.XGBOOST
        elif (hasattr(self.model, 'clf') and isinstance(self.model.clf, lightgbm.LGBMClassifier)) or \
             (hasattr(self.model, 'reg') and isinstance(self.model.reg, lightgbm.LGBMRegressor)):
            # Assuming you have a corresponding trainer for LGBM models
            return CypherTrainer.LGBM
        elif (hasattr(self.model, 'clf') and isinstance(self.model.clf, RandomForestClassifier)) or \
             (hasattr(self.model, 'reg') and isinstance(self.model.reg, RandomForestRegressor)):
            # Assuming you have a corresponding trainer for RF models
            return CypherTrainer.SKLEARN
        elif (hasattr(self.model, 'clf') and isinstance(self.model.clf, LogisticRegression)):
            # Assuming you have a corresponding trainer for RF models
            return CypherTrainer.SKLEARN
        else:
            return None

    def fit(self, X: np.ndarray, y: np.ndarray) -> float:
        """
        Fits the model to the provided data.

        Parameters:
            X: The input features.
            y: The target labels or values.

        Returns:
            The result from the strategy's fit method.
        """
        return self.strategy.fit(X, y)

    def fit_final_model(self, X: np.array, y: np.array):
        """
        Fits the last model with all data.

        Parameters:
            X: All input features.
            y: All target labels or values.

        Returns:
            The result from the strategy's fit_final_model method.
        """
        return self.strategy.fit_final_model(X, y)

    def fit_cv(self, X: np.ndarray, y: np.ndarray) -> float:
        """
        Fits using cross validation models.

        Parameters:
            X: All input features.
            y: All target labels or values.

        Returns:
            The result from the strategy's fit_cv method.
        """
        return self.strategy.fit_cv(X, y)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predicts outputs for the given input data.

        Parameters:
            X: The input features for prediction.

        Returns:
            The predicted values or classes.
        """
        return self.strategy.predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predicts outputs for the given input data.

        Parameters:
            X: The input features for prediction.

        Returns:
            The predicted values or classes.
        """
        return self.strategy.predict_proba(X)

    def load(self, file_path: str):
        """
        Loads the model's state from a file.

        Parameters:
            file_path (str): The path to load the model state from.

        Returns:
            Return value from the strategy's load method, typically None or a load confirmation.
        """
        return self.strategy.load(file_path)

    def save(self):
        """
        Saves the current object state using the strategy's save method.

        Returns:
            Return value from the strategy's save method, typically None or a save confirmation.
        """
        return self.strategy.save()
