class CypherModel:
    """
    CypherModel is an enumeration of model types used in the system.
    It currently supports transformer-based models for regression and classification tasks.

    Attributes:
        TRANSFORMER_ENCODER_REG (str): Represents a transformer encoder model for regression.
        TRANSFORMER_ENCODER_CLF (str): Represents a transformer encoder model for classification.
    """
    TRANSFORMER_ENCODER_REG = 'TransformerEncoderReg'
    TRANSFORMER_ENCODER_CLF = 'TransformerEncoderClf'
    XGBOOST_CLF = 'XGBoostClf'
    XGBOOST_REG = 'XGBoostReg'
    LGBM_CLF = 'LgbmClf'
    LGBM_REG = 'LgbmReg'
    RF_CLF = 'RfClf'
    RF_REG = 'RfReg'
    LR_CLF = 'LrClf'
    LSTM_REG = 'LSTMReg'
    LSTM_CLF = 'LSTMClf'


class CypherTrainer:
    TORCH = 'torch'
    XGBOOST = 'xgboost'
    LGBM = 'lgbm'
    SKLEARN = 'sklearn'
    # TODO: Insert new frameworks
    #MLSPARK = 'spark'
    #TF = 'tensorflow'


class DataColums:
    # Data
    TIMESTAMP = 'TIMESTAMP'
    DATAFRAME = 'DATAFRAME'
    SELECTED_FEATURES = 'SELECTED_FEATURES'
    START_TRAIN_DATE = 'START_TRAIN_DATE'
    END_TRAIN_DATE = 'END_TRAIN_DATE'
    END_TEST_DATE = 'END_TEST_DATE'
    TIMEFRAME = 'TIMEFRAME'
    TARGET = 'TARGET'
    SIGNAL = 'SIGNAL'
    TICKER = 'TICKER'
    DF_ = 'df_'
    CLOSE = 'CLOSE'
    INFORMATIONS = 'INFORMATIONS'
    # Scaling
    SCALE_METHOD = 'SCALE_METHOD'
    # Selection
    NONE_METHOD = 'NONE_METHOD'
    PCA = 'PCA'
    INFORMATION_GAIN_PERCENTUAL = 'INFORMATION_GAIN_PERCENTUAL'
    INFORMATION_GAIN_N_FEATURES = 'INFORMATION_GAIN_N_FEATURES'
    RFE = 'RFE'
    RANDOM_FOREST_PERCENTUAL = 'RANDOM_FOREST_PERCENTUAL'
    RANDOM_FOREST_N_FEATURES = 'RANDOM_FOREST_N_FEATURES'
    VARIANCE_CORRELATION_RANK = 'VARIANCE_CORRELATION_RANK'
    LGBM_FEAT_IMPORTANCE = 'LGBM_FEAT_IMPORTANCE'
    CORRELATION = 'CORRELATION'
    KEY = 'KEY'
    PROBLEM_TYPE = 'PROBLEM_TYPE'
    INGESTION_TIMESTAMP = 'INGESTION_TIMESTAMP'
    SCALE_INFO = 'SCALE_INFO'
