# Machine Learning Model Training Framework

This README outlines the steps necessary to configure, train, and utilize a machine learning model within our
framework, specifically using the example of an XGBoost model.

## Getting Started

### 1. Create the Model

- **Location**: Place your model file (e.g., `xgboost.py`) in the `models` folder.

### 2. Configure the Trainer Class

- **Update hub.py**: Add your model name to the `hub.py` file.

- **Modify constant.py**:
  - Add the framework name to the `CypherTrainer` class.
  - Include your model name in the `CypherModel` class.

### 3. Modify Trainer Methods

In the `trainer.py` file:
- Update the `Trainer` class by modifying the following methods to select your model:
  - `_get_model`
  - `_select_strategy`
  - `_get_model_strategy`

### 4. Create the LGBMTrainer Class

- **File**: `trainer.py`
- **Class**: For example, create `XGBoostTrainer` with the following methods:
  - `fit`
  - `predict`
  - `evaluate`
  - `save`
  - `load`

### 5. Create Configuration Template

- Create a template configuration file (e.g., `xgboost.yml`).

### 6. Update Search Space in Tuner

- Modify the `_build_search_space()` method in `tuner.py` to include the search space dictionary, following
hyperopts specifications.

### 7. Update Main Configuration

- Revise the main `config.yml` file to reflect these changes.

### 8. Execute Training

- Run the `run_train.py` script to start the training process.

### 8. Execute Evaluate

- Run the `run_eval.py` script to start the evaluate the model trained.

## Additional Information

For more detailed instructions and troubleshooting, refer to the individual documentation of each file and
method mentioned above.

---

**Note**: This README is specifically tailored for an XGBoost model setup. Adjustments may be required for
other models or framework changes.
