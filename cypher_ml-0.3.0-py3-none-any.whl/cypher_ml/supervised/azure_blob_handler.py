import time
import joblib
import pandas as pd
import logging
from io import BytesIO
from azure.storage.blob import BlobServiceClient, ContainerClient
from typing import List
from constants import CypherModel
from sklearn.preprocessing import MinMaxScaler

logger = logging.getLogger('logger')


class AzureBlobHandler:
    def __init__(self,
                 storage_account_name: str,
                 container_name: str,
                 storage_account_key: str):

        self.connection_dict = self._log_blob_azure(storage_account_name,
                                                    container_name,
                                                    storage_account_key)

    def _log_blob_azure(self,
                        storage_account_name: str,
                        container_name: str,
                        storage_account_key: str) -> dict:

        # Log in Azure
        connection_dict = {
            "storage_account_name": storage_account_name,
            "container_name": container_name,
            "storage_account_key": storage_account_key,
        }

        connection_dict["connect_str"] = (
            f"DefaultEndpointsProtocol=https;AccountName={connection_dict['storage_account_name']};AccountKey={connection_dict['storage_account_key']};EndpointSuffix=core.windows.net"
        )

        connection_dict["relative_path"] = (
            f"wasbs://{connection_dict['container_name']}@{connection_dict['storage_account_name']}.blob.core.windows.net"
        )

        return connection_dict

    def _test_folder_path_is_valid(self, file_path):
        assert isinstance(file_path, str), f"folder_path must be a string, but got{type(file_path).__name__}"
        assert file_path.strip() != '', "folder_path must not be an empty string or contain whitespaces"

    def _create_blob_path(self, folder_name, table_name):
        if not folder_name:
            blob_path = f"/{table_name}/"
        else:
            blob_path = f"/{folder_name}/{table_name}/"

        return blob_path

    def read_parquet_as_pandas(self,
                               file_path) -> pd.DataFrame:
        """
        Reads a Parquet file from Azure Blob Storage into a DataFrame.

        Args:
            table_name (str): The name of the Parquet file in Azure Blob Storage.
            folder_name (str): The name of the folder in Azure Blob Storage.

        Returns:
            pandas.DataFrame: The DataFrame containing the data from the Parquet file.
        """
        start_time = time.time()
        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        #TODO: Need to concat the parquet files
        try:
            blob_client = blob_service_client.get_blob_client(container=self.connection_dict["container_name"],
                                                                blob=file_path)
            download_stream = blob_client.download_blob()

            # Load the Parquet file into a DataFrame
            parquet_buffer = BytesIO(download_stream.readall())
            df = pd.read_parquet(parquet_buffer)

        except Exception as e:
            logger.info(f"An error occurred while reading the Parquet file: {e}")
            return None

        total_time = time.time() - start_time
        table_name = file_path.split("/")[-1]
        logger.debug(f"Parquet file read from Azure Blob Storage: {table_name} in {total_time:.2f}s")

        return df

    def download_feature_from_blob(self, folder_name, table_name, keys):
        blob_path = self._create_blob_path(folder_name, table_name)
        self._test_folder_path_is_valid(blob_path)

        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        for key in keys:
            file_path = f"{blob_path}features_scaler_{key}.txt"
            blob_client = blob_service_client.get_blob_client(container='gold',
                                                              blob=file_path)

            # Download the blob to a local file
            download_file_path = f"./features_scaler_{key}.txt"

            with open(download_file_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())

            print(f"Downloaded blob {file_path} to {download_file_path}")

    def download_scaler_from_blob(self, folder_name, table_name, keys):
        blob_path = self._create_blob_path(folder_name, table_name)
        self._test_folder_path_is_valid(blob_path)

        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        for key in keys:
            file_path = f"{blob_path}scaler_{key}.pkl"
            blob_client = blob_service_client.get_blob_client(container='gold',
                                                              blob=file_path)

            # Download the blob to a local file
            download_file_path = f"./scaler_{key}.pkl"

            with open(download_file_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())

            print(f"Downloaded blob {file_path} to {download_file_path}")

    def download_model_from_blob(self, folder_name, table_name, model_ids):
        blob_path = self._create_blob_path(folder_name, table_name)
        self._test_folder_path_is_valid(blob_path)

        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        for model_id in model_ids:
            file_path = f"{blob_path}model_{model_id}.pkl"
            blob_client = blob_service_client.get_blob_client(container='gold',
                                                              blob=file_path)
            # Download the blob to a local file
            download_file_path = f"./model_{model_id}.pkl"

            with open(download_file_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())

            print(f"Downloaded blob {file_path} to {download_file_path}")

    def list_parquet_files_paths(self,
                                 folder_name,
                                 table_name) -> List[str]:

        """
        Lists all Parquet files in a specified folder within an Azure Blob Storage container.

        Args:
            folder_path (str): The path of the folder within the container to list Parquet files from.

        Returns:
            list: A list of Parquet file paths within the specified folder.
        """
        blob_path = self._create_blob_path(folder_name, table_name)
        self._test_folder_path_is_valid(blob_path)

        # Create the BlobServiceClient object which will be used to create a container client
        container_client = ContainerClient.from_connection_string(
            self.connection_dict["connect_str"],
            self.connection_dict["container_name"]
        )

        blobs = container_client.list_blobs(name_starts_with=blob_path)
        parquet_files = []
        for blob in blobs:
            parquet_files.append(blob["name"])

        return parquet_files

    def save_features(self,
                      features: list,
                      table_key: str,
                      folder_name: str = "dbfs",
                      table_name: str = "scalers"):
        features_scaler = str(features)
        blob_path = self._create_blob_path(folder_name, table_name)

        blob_full_path = f"{blob_path}features_scaler_{table_key}.txt".lstrip('/')

        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        blob_client = blob_service_client.get_blob_client(container='gold',
                                                          blob=blob_full_path)

        try:
            blob_client.upload_blob(features_scaler, overwrite=True)
            logger.info(f"File uploaded successfully to /gold/{folder_name}/{table_name}/features_scaler_{table_key}.txt")
        except Exception as e:
            logger.info(f"Failed to upload file to Azure Blob Storage: {str(e)}")
            print(e)

    def save_model(self,
                   model: CypherModel,
                   model_id: str,
                   folder_name: str = "dbfs",
                   table_name: str = "models"):
        model_buffer = BytesIO()
        joblib.dump(model, model_buffer)
        model_buffer.seek(0)

        blob_path = self._create_blob_path(folder_name, table_name)

        blob_full_path = f"{blob_path}model_{model_id}.pkl".lstrip('/')

        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        blob_client = blob_service_client.get_blob_client(container='gold',
                                                          blob=blob_full_path)

        try:
            blob_client.upload_blob(model_buffer, overwrite=True)
            logger.info(f"File uploaded successfully to /gold/{folder_name}/{table_name}/model_{model_id}.pkl.")
        except Exception as e:
            logger.info(f"Failed to upload model to Azure Blob Storage: {str(e)}")

    def save_scaler(self,
                    scaler: MinMaxScaler,
                    table_key: str,
                    folder_name: str = "dbfs",
                    table_name: str = "scalers"):
        scaler_buffer = BytesIO()
        joblib.dump(scaler, scaler_buffer)
        scaler_buffer.seek(0)

        blob_path = self._create_blob_path(folder_name, table_name)

        blob_full_path = f"{blob_path}scaler_{table_key}.pkl".lstrip('/')

        blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_dict["connect_str"]
        )

        blob_client = blob_service_client.get_blob_client(container='gold',
                                                          blob=blob_full_path)

        try:
            blob_client.upload_blob(scaler_buffer, overwrite=True)
            logger.info(f"File uploaded successfully to /gold/{folder_name}/{table_name}/scaler_{table_key}.pkl.")
        except Exception as e:
            logger.info(f"Failed to upload model to Azure Blob Storage: {str(e)}")
