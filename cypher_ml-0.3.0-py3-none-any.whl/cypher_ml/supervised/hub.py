from typing import List


class CypherHub:
    """
    A class representing a CypherHub with a list of models.
    """

    @property
    def list_models(self) -> List[str]:
        """
        Get a list of available models in CypherHub.

        Returns:
            List[str]: A list of model names.
        """
        _list_models = [
            'TransformerEncoderReg',
            'TransformerEncoderClf',
            'XGBoostClf',
            'XGBoostReg',
            'LgbmClf',
            'LgbmReg',
            'RfClf',
            'RfReg',
            'LrClf',
            'LSTMReg',
            'LSTMClf']

        return _list_models
