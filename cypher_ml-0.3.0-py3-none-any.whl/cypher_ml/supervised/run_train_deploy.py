import traceback
import os
import json
import time
import logging

# NOTE: It seems assynchronous use of cuda can rise error for BCE loss
# but a better investigation is necessary. If use BCE change cuda to
# synchronous cuda operations.
# os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

import numpy as np
import mlflow
from sklearn.preprocessing import OneHotEncoder
from trainer import Trainer
from utils import *
from constants import DataColums
from optimize_cutoff import *
from dlhandler import DeltaLakeHandler
from azure_blob_handler import AzureBlobHandler
from logger_config import setup_logger

DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR

LEVEL = DEBUG

logger = setup_logger(level=LEVEL)

def main():
    logger.info("Starting Train Deploy ...")

    # Get total number of CPUs
    app_name = "RunTrainDeploy"
    total_cpus = os.cpu_count()

    # Azure Blob Storage account information
    storage_account_name = "dlcypherus"
    container_name = "silver"
    storage_account_key = "Eubzuzb612QyIQN9lS9FA17b2LpiJQ9+RQtJJhV0LJcLRlurgd+iEbvfQ6qNUJYPToTE5uXAc+CH+AStPSZiwA=="

    # Set up Spark configuration
    logger.info("Starting spark session ...")
    spark = create_spark_session(app_name,
                                 total_cpus,
                                 storage_account_name,
                                 storage_account_key,
                                 executor_memory="8G",
                                 driver_memory="64G",
                                 max_result_size="32g")

    # Handle delta tables
    dl_handler = DeltaLakeHandler(spark)

    az_handler = AzureBlobHandler(storage_account_name, container_name, storage_account_key)

    # Set environment to deploy
    deploy_env = None    # NOTE: SET INPUT: 'production' or 'sandbox'
    is_save = None       # NOTE: SET INPUT: True or False

    backtest_ids = dl_handler.get_portfolio_btids(storage_account_name, deploy_env)

    logger.info("Loading table_metadata_features...")
    sdf_metadata_features = dl_handler.read_table_with_spark(spark,
                                                             container_name,
                                                             storage_account_name,
                                                             table_name='metadata_features')

    ts_df_fund = time.time()
    logger.info("Processing df_funding ...")
    df_funding = read_funding_cost(spark,
                                   container_name,
                                   storage_account_name)
    logger.info(f"The df_funding computation spent: {time.time()-ts_df_fund}s")

    for backtest_id in backtest_ids:
        # Load backtest id configuration from multi/single crypto
        sdf_metadata_backtest = dl_handler.get_metadata_train(backtest_id, storage_account_name)
        filtered_df = sdf_metadata_backtest.filter(sdf_metadata_backtest['BACKTEST_ID'] == backtest_id)
        #sorted_df = filtered_df.orderBy("DATAFRAME_FINAL", ascending=True)

        try:
            config_str = filtered_df.select("CONFIG").collect()
            config = json.loads(config_str[-1]["CONFIG"])
        except Exception as error:
            logger.error(error)
            continue

        ticker = config['backtest']['ticker']
        timeframe = config['backtest']['timeframe']
        model_name = config['info']['model_name']
        framework = config['info']['framework']
        table_key = config['info']['table_key']
        is_multiclass = config['info']['is_multiclass']
        risk = config['info']['risk']
        pct_change_th = config['info']['pct_change_th']
        trust_factor = config['info']['trust_factor']
        model_type = config['info']['model_type']
        optimize_method = config['info']['optimize_method']
        is_multi_crypto_df = config['info']['is_multi_crypto_df']
        strategy_type = config['info']['strategy_type']
        selection = config['info']['selection']

        optim_methods = [optimize_method]

        if model_type == 'reg' and config['params'].get('class_weight') is not None:
            logger.warning("Regression should not have class weight, removing it from config!!!")
            del config['params']['class_weight']

        if validate_timeframe(timeframe):
                indicator_table_name = f"full_indicators_{timeframe}"
                logger.info(f"Running table {indicator_table_name}")
        else:
            raise ValueError("Timeframe not valid!!!")

        logger.info('----------CONFIG BACKTEST----------\n')
        logger.debug(config)

        # Get dataframe columns configuration
        SELECTION = selection
        TIMESTAMP = DataColums.TIMESTAMP
        START_TRAIN_DATE = DataColums.START_TRAIN_DATE
        END_TRAIN_DATE = DataColums.END_TRAIN_DATE
        TARGET = DataColums.TARGET
        DF_ = DataColums.DF_
        TIMEFRAME = DataColums.TIMEFRAME
        TICKER = DataColums.TICKER
        CLOSE = DataColums.CLOSE
        KEY = DataColums.KEY
        PROBLEM_TYPE = DataColums.PROBLEM_TYPE
        INGESTION_TIMESTAMP = DataColums.INGESTION_TIMESTAMP
        SCALE_INFO = DataColums.SCALE_INFO

        # Update config for deploy
        config_deploy = config.copy()
        config_deploy['info']['is_deploy'] = True

        cutoff_min = {method: [] for method in optim_methods}
        cutoff_max = {method: [] for method in optim_methods}

        df_funding_filtered = filter_funding_cost(config, df_funding)

        # Filter dataframe metadata info
        logger.info(f"Filtering meatadata_features by ticker:{ticker}, key:{table_key}, timeframe:{timeframe}, problem_type:{model_type}")
        criterion = (sdf_metadata_features[TICKER] == ticker) & \
                    (sdf_metadata_features[KEY] == table_key) & \
                    (sdf_metadata_features[TIMEFRAME] == timeframe) & \
                    (sdf_metadata_features[PROBLEM_TYPE] == model_type)

        sdf_meta_fea_fil = sdf_metadata_features.filter(criterion)
        pdf_meta_fea_fil_ord = sdf_meta_fea_fil.toPandas().sort_values(by=INGESTION_TIMESTAMP, ascending=True)

        logger.info("Reading indicator table...")
        df_indicators = dl_handler.read_table_with_spark(spark,
                                                        container_name,
                                                        storage_account_name,
                                                        table_name=indicator_table_name,
                                                        folder_name='indicators_full')

        logger.info("Converting indicator table to pandas...")
        df_indicators = df_indicators.toPandas().sort_values(by=TIMESTAMP, ascending=True)

        df_indicators[TIMESTAMP] = pd.to_datetime(df_indicators[TIMESTAMP])

        # Set hiperparameters for multicriptos
        is_multi_crypto_df = True
        close_column = f'CLOSE-{ticker}'

        # Train over last window of data
        try:
            # Set windowing hiper-parameters
            n_dfs = len(pdf_meta_fea_fil_ord)
            idx_last = n_dfs - 1
            df_id = DF_ + f"{(idx_last):03d}"

            logger.info(f'-------------------------DATAFRAME = {df_id}-------total = {n_dfs}----------------------------------------')

            # Filtering indicators by dataframe
            logger.info("Filtering indicators by features metadata ...")
            start_train_date = pdf_meta_fea_fil_ord.iloc[idx_last][START_TRAIN_DATE]
            end_train_date = pdf_meta_fea_fil_ord.iloc[idx_last][END_TRAIN_DATE]
            features = pdf_meta_fea_fil_ord.iloc[idx_last][SELECTION]
            scaler_info = ast.literal_eval(pdf_meta_fea_fil_ord.iloc[idx_last][SCALE_INFO])

            # Data slicing logic -> [start_train_date, end_test_date)
            df_last = df_indicators[
                (df_indicators[TIMESTAMP] >= start_train_date) &
                (df_indicators[TIMEFRAME] == timeframe)].copy()

            df_last[TICKER] = ticker

            if is_multi_crypto_df:
                df_last[CLOSE] = df_last[close_column]

                df_last = df_last[df_last[close_column] > 0]

            if model_type == 'reg':
                df_last[TARGET] = (df_last[CLOSE].shift(-1)/df_last[CLOSE])-1
            else:
                df_last[TARGET] = np.where(df_last[CLOSE].shift(-1) > df_last[CLOSE], 1, 0)

            df_last = df_last.dropna()

            if is_multiclass:
                df_last['PERCENT_CHANGE'] = df_last.CLOSE.pct_change().shift(-1)
                df_last['TARGET'] = df_last['PERCENT_CHANGE'].apply(classify_pct_change, args=(pct_change_th, trust_factor, risk))

            # Get last window dataframe
            end_test_date = end_train_date
            X_train, _, y_train, _ = windowing(df_last,
                                               features,
                                               end_train_date,
                                               end_test_date,
                                               TIMESTAMP,
                                               TARGET)
            logger.info(f'Scaling datasets.')
            X_train, _, scaler = scaling(scaler_info, X_train)
            X_train = pd.DataFrame(X_train, columns=ast.literal_eval(features))

            if model_type == 'clf':
                if framework in ['lgbm', 'torch']:
                    class_weight = calculate_class_weight(y_train)
                    config['params']['class_weight'] = class_weight

            if framework == 'torch':
                if 'CLOSE' in X_train:
                    X_train['CLOSE'] = 0.0

                config['params']['input_size'] = len(X_train.columns)

                if is_multiclass:
                    # Convert integer class labels into one-hot vectors for torch models
                    onehot_encoder = OneHotEncoder(sparse_output=False)  # Avoid sparse data structure
                    y_train = onehot_encoder.fit_transform(y_train.values.reshape(-1, 1))

            # Generate run id for mlflow tracking
            run_name = f"{model_name}_{df_id}_{generate_alpha_numeric_key()}"

            # Train model for deploy
            with mlflow.start_run(run_name=run_name) as run:
                # Define model key
                model_id = run.info.run_id
                logger.info('---------- MODEL----------')
                logger.info(f'ID: {model_id}')
                config_deploy['info']['output_name'] = f"model_{model_id}"

                logger.info('----------CONFIG DEPLOY----------')
                logger.debug(config_deploy)

                # Save config information into delta
                if is_save:
                    dl_handler.save_metadata_train_deploy(df_id,
                                                          backtest_id,
                                                          model_id,
                                                          config_deploy,
                                                          storage_account_name)

                logger.info('----------TRAINING THE MODEL ----------')
                if framework in ['lgbm', 'xgboost']:
                    trainer = Trainer(config_deploy)
                    # Include validation data to train
                    trainer.fit_final_model(X_train, y_train)
                else:
                    trainer = Trainer(config_deploy)
                    trainer.fit(X_train, y_train)

                mlflow.end_run()

                X_test = X_train.copy()
                min_cutoff, max_cutoff = reg_class_optimize_method(optim_methods,
                                                                   cutoff_min,
                                                                   cutoff_max,
                                                                   config,
                                                                   df_last,
                                                                   X_train,
                                                                   trainer,
                                                                   framework,
                                                                   df_funding_filtered,
                                                                   model_type,
                                                                   X_test)

                min_cutoff = min_cutoff[optimize_method][0]
                max_cutoff = max_cutoff[optimize_method][0]

                logger.info(f'min_cutoff =  {min_cutoff} --- max_cutoff =  {max_cutoff}')
                if is_save:
                    scaler_key = generate_alpha_numeric_key()
                    data_to_save = dl_handler.create_metadata_deploy(**locals())
                    logger.info('----------METADATA TO DEPLOY ----------')
                    logger.debug(data_to_save)
                    # Save metadata train deploy
                    dl_handler.save_metadata_strategy(data_to_save, deploy_env, storage_account_name)

                    # Save files
                    az_handler.save_model(trainer.strategy.model, model_id)
                    az_handler.save_features(features, scaler_key)
                    az_handler.save_scaler(scaler, scaler_key)
                else:
                    logger.warning("Not saved files and metadata !!!")
        except ValueError as ve:
            logger.error(f"Value error: {ve}")
            traceback.print_exc()
        except IOError as ioe:
            logger.error(f"I/O error: {ioe}")
            traceback.print_exc()
        except Exception as ge:
            logger.error(f"General error: {ge}")
            traceback.print_exc()


if __name__ == "__main__":
    main()
